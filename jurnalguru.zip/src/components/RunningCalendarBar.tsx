import React, { useEffect, useMemo, useState } from 'react';
import {
  BellRing,
  CalendarClock,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
} from 'lucide-react';
import {
  AttendanceSession,
  CalendarReminder,
  Classroom,
  LessonNote,
  ScheduleSlot,
} from '../types/journal';
import {
  formatShortDate,
  getDayOfWeekFromIso,
  getTodayIsoDate,
} from '../data/seedData';

interface RunningCalendarBarProps {
  reminders: CalendarReminder[];
  schedules?: ScheduleSlot[];
  classes?: Classroom[];
  attendanceSessions?: AttendanceSession[];
  lessonNotes?: LessonNote[];
  onOpenCalendar?: () => void;
}

interface TickerItem {
  id: string;
  tag: string;
  text: string;
  urgent?: boolean;
}

export function RunningCalendarBar({
  reminders,
  schedules = [],
  classes = [],
  attendanceSessions = [],
  lessonNotes = [],
  onOpenCalendar,
}: RunningCalendarBarProps) {
  const [now, setNow] = useState<Date>(() => new Date());
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const todayIso = getTodayIsoDate();
  const todayDay = getDayOfWeekFromIso(todayIso);

  const tickerItems = useMemo<TickerItem[]>(() => {
    const items: TickerItem[] = [];
    const classMap = new Map(classes.map((c) => [c.id, c.name]));

    // 1. Personal teaching schedule reminders for today
    const todaySlots = schedules
      .filter((s) => s.day === todayDay)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));

    for (const slot of todaySlots) {
      const clsName = classMap.get(slot.classId) ?? 'Kelas';
      const hasAtt = attendanceSessions.some(
        (a) =>
          a.date === todayIso &&
          a.classId === slot.classId &&
          (a.scheduleSlotId === slot.id || a.subject === slot.subject)
      );
      const hasNote = lessonNotes.some(
        (n) =>
          n.date === todayIso &&
          n.classId === slot.classId &&
          (n.scheduleSlotId === slot.id || n.subject === slot.subject)
      );

      if (!hasAtt || !hasNote) {
        const missing =
          !hasAtt && !hasNote
            ? 'presensi & jurnal belum diisi'
            : !hasAtt
            ? 'presensi belum diisi'
            : 'catatan materi belum diisi';
        items.push({
          id: `slot-${slot.id}`,
          tag: `Jadwal ${slot.startTime}–${slot.endTime}`,
          text: `Kelas ${clsName} (${slot.subject}, ${slot.room || 'Ruang kelas'}) — ${missing}`,
          urgent: true,
        });
      } else {
        items.push({
          id: `slot-${slot.id}`,
          tag: `Jadwal ${slot.startTime}–${slot.endTime}`,
          text: `Kelas ${clsName} (${slot.subject}) — presensi dan jurnal hari ini sudah lengkap`,
        });
      }
    }

    // 2. School & personal calendar reminders (today & upcoming)
    const upcoming = [...reminders]
      .filter((r) => r.date >= todayIso)
      .sort((a, b) => a.date.localeCompare(b.date) || (a.time ?? '').localeCompare(b.time ?? ''));

    for (const ev of upcoming) {
      const isToday = ev.date === todayIso;
      const datePrefix = isToday ? 'Hari Ini' : formatShortDate(ev.date);
      const timeStr = ev.time ? ` ${ev.time}` : '';
      items.push({
        id: `ev-${ev.id}`,
        tag: `${ev.category} · ${datePrefix}${timeStr}`,
        text: `${ev.title}${ev.description ? ` — ${ev.description}` : ''}`,
        urgent: isToday,
      });
    }

    if (items.length === 0) {
      items.push({
        id: 'default-reminder',
        tag: 'Pengingat Harian',
        text: 'Selamat mengajar Bapak/Ibu Guru SMA Negeri 1 Pagerbarang. Jangan lupa mencatat presensi dan jurnal pertemuan.',
      });
    }

    return items;
  }, [
    reminders,
    schedules,
    classes,
    attendanceSessions,
    lessonNotes,
    todayIso,
    todayDay,
  ]);

  useEffect(() => {
    if (activeIndex >= tickerItems.length) {
      setActiveIndex(0);
    }
  }, [tickerItems.length, activeIndex]);

  useEffect(() => {
    if (paused || tickerItems.length <= 1) return;
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) return;

    const interval = window.setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % tickerItems.length);
    }, 5500);
    return () => window.clearInterval(interval);
  }, [paused, tickerItems.length]);

  const currentItem = tickerItems[activeIndex] ?? tickerItems[0];

  const liveDateStr = new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(now);

  const liveTimeStr = now.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div
      className="bg-slate-900 text-slate-100 border-b border-slate-800 no-print"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8 py-2 flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-3 shrink-0">
          <div className="inline-flex items-center gap-1.5 font-medium text-white whitespace-nowrap">
            <CalendarClock className="h-3.5 w-3.5 text-sky-400 shrink-0" />
            <span>{liveDateStr}</span>
          </div>
          <span className="text-slate-600" aria-hidden="true">
            ·
          </span>
          <span className="font-mono text-sky-300 tabular-nums whitespace-nowrap">
            {liveTimeStr}
          </span>
        </div>

        <div className="flex items-center gap-2 min-w-0 flex-1 md:px-4">
          <BellRing
            className={`h-3.5 w-3.5 shrink-0 ${
              currentItem.urgent ? 'text-amber-400' : 'text-slate-400'
            }`}
          />
          {onOpenCalendar ? (
            <button
              type="button"
              onClick={onOpenCalendar}
              className="text-left min-w-0 flex-1 truncate hover:text-white transition-colors"
              title={`${currentItem.tag}: ${currentItem.text}`}
            >
              <span
                className={`font-semibold mr-2 ${
                  currentItem.urgent ? 'text-amber-300' : 'text-sky-300'
                }`}
              >
                {currentItem.tag}:
              </span>
              <span className="text-slate-200">{currentItem.text}</span>
            </button>
          ) : (
            <p
              className="min-w-0 flex-1 truncate"
              title={`${currentItem.tag}: ${currentItem.text}`}
            >
              <span
                className={`font-semibold mr-2 ${
                  currentItem.urgent ? 'text-amber-300' : 'text-sky-300'
                }`}
              >
                {currentItem.tag}:
              </span>
              <span className="text-slate-200">{currentItem.text}</span>
            </p>
          )}
        </div>

        <div className="flex items-center gap-1.5 shrink-0 self-end md:self-auto">
          <span className="font-mono text-[11px] text-slate-400 tabular-nums mr-1">
            {activeIndex + 1}/{tickerItems.length}
          </span>
          <button
            type="button"
            onClick={() =>
              setActiveIndex(
                (prev) => (prev - 1 + tickerItems.length) % tickerItems.length
              )
            }
            aria-label="Pengingat sebelumnya"
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <ChevronLeft className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setPaused((p) => !p)}
            aria-label={paused ? 'Lanjutkan pengingat berjalan' : 'Jeda pengingat berjalan'}
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            {paused ? (
              <Play className="h-3 w-3" />
            ) : (
              <Pause className="h-3 w-3" />
            )}
          </button>
          <button
            type="button"
            onClick={() =>
              setActiveIndex((prev) => (prev + 1) % tickerItems.length)
            }
            aria-label="Pengingat berikutnya"
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
