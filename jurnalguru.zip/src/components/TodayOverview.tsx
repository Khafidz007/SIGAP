import React from 'react';
import {
  ArrowRight,
  CheckCircle2,
  ClipboardCheck,
  BookOpenText,
  CalendarPlus,
} from 'lucide-react';
import {
  AtpItem,
  AttendanceSession,
  Classroom,
  LessonNote,
  ScheduleSlot,
} from '../types/journal';
import {
  formatIndonesianDate,
  formatShortDate,
  getDayOfWeekFromIso,
  getTodayIsoDate,
} from '../data/seedData';

interface TodayOverviewProps {
  classes: Classroom[];
  schedules: ScheduleSlot[];
  atpItems: AtpItem[];
  attendanceSessions: AttendanceSession[];
  lessonNotes: LessonNote[];
  onOpenAttendanceForSlot: (slot: ScheduleSlot, date: string) => void;
  onOpenNoteForSlot: (slot: ScheduleSlot, date: string) => void;
  onNavigateSchedule: () => void;
  onNavigateHistory: () => void;
  onNavigateAtp: () => void;
}

export function TodayOverview({
  classes,
  schedules,
  atpItems,
  attendanceSessions,
  lessonNotes,
  onOpenAttendanceForSlot,
  onOpenNoteForSlot,
  onNavigateSchedule,
  onNavigateHistory,
  onNavigateAtp,
}: TodayOverviewProps) {
  const todayIso = getTodayIsoDate();
  const todayDay = getDayOfWeekFromIso(todayIso);
  const formattedToday = formatIndonesianDate(todayIso);

  const classMap = new Map(classes.map((c) => [c.id, c]));

  const todaySlots = schedules
    .filter((s) => s.day === todayDay)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const totalStudents = classes.reduce((acc, c) => acc + c.students.length, 0);
  const completedAttendanceToday = todaySlots.filter((slot) =>
    attendanceSessions.some(
      (a) =>
        a.date === todayIso &&
        a.classId === slot.classId &&
        (a.scheduleSlotId === slot.id || a.subject === slot.subject)
    )
  ).length;

  const completedNotesToday = todaySlots.filter((slot) =>
    lessonNotes.some(
      (n) =>
        n.date === todayIso &&
        n.classId === slot.classId &&
        (n.scheduleSlotId === slot.id || n.subject === slot.subject)
    )
  ).length;

  const achievedAtp = atpItems.filter((a) => a.status === 'Tercapai').length;

  const recentNotes = [...lessonNotes]
    .sort((a, b) => b.date.localeCompare(a.date) || b.updatedAt.localeCompare(a.updatedAt))
    .slice(0, 4);

  return (
    <div className="space-y-8">
      <div className="bg-white border border-slate-200 rounded-xl">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              Jadwal Mengajar Hari Ini
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{formattedToday}</p>
          </div>
          <button
            type="button"
            onClick={onNavigateSchedule}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 hover:text-blue-800 whitespace-nowrap shrink-0 self-start sm:self-auto"
          >
            Lihat jadwal penuh
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-200 border-b border-slate-200">
          <div className="px-6 py-4">
            <p className="text-xs text-slate-500">Sesi Hari Ini</p>
            <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
              {todaySlots.length} <span className="text-sm font-normal text-slate-500">kelas</span>
            </p>
          </div>
          <div className="px-6 py-4 border-l border-slate-200 lg:border-l-0">
            <p className="text-xs text-slate-500">Presensi Tercatat</p>
            <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
              {completedAttendanceToday}
              <span className="text-sm font-normal text-slate-500">
                /{todaySlots.length} sesi
              </span>
            </p>
          </div>
          <div className="px-6 py-4">
            <p className="text-xs text-slate-500">Jurnal Hari Ini</p>
            <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
              {completedNotesToday}
              <span className="text-sm font-normal text-slate-500">
                /{todaySlots.length} sesi
              </span>
            </p>
          </div>
          <div className="px-6 py-4 border-l border-slate-200 lg:border-l-0">
            <p className="text-xs text-slate-500">Ketercapaian ATP</p>
            <button
              type="button"
              onClick={onNavigateAtp}
              className="mt-1 text-left group"
            >
              <p className="font-display text-2xl font-semibold text-slate-900 group-hover:text-blue-700 tabular-nums">
                {achievedAtp}
                <span className="text-sm font-normal text-slate-500">
                  /{atpItems.length} TP · {totalStudents} siswa
                </span>
              </p>
            </button>
          </div>
        </div>

        {todaySlots.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <p className="text-sm font-medium text-slate-900">
              Tidak ada jadwal mengajar pada hari {todayDay}.
            </p>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              Tambahkan slot jadwal mengajar untuk hari ini atau buka menu Jadwal Mengajar untuk mengatur jam mengajar mingguan.
            </p>
            <button
              type="button"
              onClick={onNavigateSchedule}
              className="mt-4 inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              <CalendarPlus className="h-3.5 w-3.5" />
              Atur Jadwal Mengajar
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {todaySlots.map((slot) => {
              const cls = classMap.get(slot.classId);
              const attSession = attendanceSessions.find(
                (a) =>
                  a.date === todayIso &&
                  a.classId === slot.classId &&
                  (a.scheduleSlotId === slot.id || a.subject === slot.subject)
              );
              const noteEntry = lessonNotes.find(
                (n) =>
                  n.date === todayIso &&
                  n.classId === slot.classId &&
                  (n.scheduleSlotId === slot.id || n.subject === slot.subject)
              );

              const studentCount = cls?.students.length ?? 0;
              let presentCount = 0;
              if (attSession && cls) {
                presentCount = cls.students.filter(
                  (st) => attSession.records[st.id]?.status === 'H'
                ).length;
              }

              return (
                <div
                  key={slot.id}
                  className="px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/70 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-5 min-w-0">
                    <div className="font-mono text-sm font-medium text-slate-900 tabular-nums shrink-0">
                      {slot.startTime} – {slot.endTime}
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                        <span className="font-display text-sm font-semibold text-slate-900">
                          {cls?.name ?? 'Kelas'}
                        </span>
                        <span className="text-slate-300" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-sm font-medium text-slate-700">
                          {slot.subject}
                        </span>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500">
                        <span>{slot.room || cls?.room || 'Ruang kelas'}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{slot.lessonHours} JP</span>
                        <span aria-hidden="true">·</span>
                        {attSession ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-medium tabular-nums">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Presensi {presentCount}/{studentCount} hadir
                          </span>
                        ) : (
                          <span className="text-amber-700 font-medium">
                            Presensi belum diisi
                          </span>
                        )}
                        <span aria-hidden="true">·</span>
                        {noteEntry ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Jurnal tercatat ({noteEntry.status})
                          </span>
                        ) : (
                          <span className="text-slate-500">
                            Jurnal materi belum diisi
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onOpenAttendanceForSlot(slot, todayIso)}
                      className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                        attSession
                          ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          : 'bg-blue-700 border-blue-700 text-white hover:bg-blue-800'
                      }`}
                    >
                      <ClipboardCheck className="h-3.5 w-3.5" />
                      {attSession ? 'Ubah Presensi' : 'Isi Presensi'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenNoteForSlot(slot, todayIso)}
                      className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                        noteEntry
                          ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-100'
                      }`}
                    >
                      <BookOpenText className="h-3.5 w-3.5" />
                      {noteEntry ? 'Edit Jurnal' : 'Catat Materi'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              Riwayat Jurnal Terakhir
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Ringkasan progres materi lintas kelas sebagai acuan pertemuan berikutnya
            </p>
          </div>
          <button
            type="button"
            onClick={onNavigateHistory}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 hover:text-blue-800 whitespace-nowrap shrink-0"
          >
            Lihat semua riwayat
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        {recentNotes.length === 0 ? (
          <div className="px-6 py-10 text-center">
            <p className="text-sm font-medium text-slate-900">
              Belum ada riwayat jurnal tersimpan.
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Catatan materi yang Anda buat dari jadwal hari ini atau menu Riwayat Jurnal akan muncul di sini.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {recentNotes.map((note) => {
              const cls = classMap.get(note.classId);
              const statusColor =
                note.status === 'Tuntas'
                  ? 'text-emerald-700'
                  : note.status === 'Berlanjut'
                  ? 'text-blue-700'
                  : 'text-amber-700';

              return (
                <div key={note.id} className="px-6 py-4 space-y-1.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                      <span className="font-semibold text-slate-800">
                        {cls?.name ?? 'Kelas'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{note.subject}</span>
                      {note.atpCode && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono font-semibold text-blue-700">
                            {note.atpCode}
                          </span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        Pertemuan ke-{note.meetingNumber}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{formatShortDate(note.date)}</span>
                    </div>
                    <span className={`text-xs font-semibold ${statusColor}`}>
                      {note.status}
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-slate-900">
                    {note.topic}
                  </p>
                  {note.reflection && (
                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                      Tindak lanjut: {note.reflection}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
