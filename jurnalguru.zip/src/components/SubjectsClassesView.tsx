import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  UserPlus,
  Users,
  BookMarked,
  GraduationCap,
  FileSpreadsheet,
  Upload,
  Download,
  CheckCircle2,
  AlertCircle,
  X,
} from 'lucide-react';
import {
  AtpItem,
  Classroom,
  ScheduleSlot,
  Student,
  Subject,
} from '../types/journal';
import {
  ImportSubjectsAndClassesPayload,
  ImportSubjectsAndClassesSummary,
} from '../hooks/useJournalStore';
import {
  downloadExcelTemplate,
  ExcelParseResult,
  exportSubjectsClassesToExcel,
  parseExcelWorkbook,
} from '../utils/excelImport';

interface SubjectsClassesViewProps {
  subjects: Subject[];
  classes: Classroom[];
  schedules: ScheduleSlot[];
  atpItems: AtpItem[];
  onAddSubject: (payload: Omit<Subject, 'id'>) => string;
  onUpdateSubject: (id: string, patch: Partial<Omit<Subject, 'id'>>) => void;
  onDeleteSubject: (id: string) => void;
  onAddClass: (payload: Omit<Classroom, 'id' | 'students'>) => string;
  onUpdateClass: (id: string, patch: Partial<Omit<Classroom, 'id'>>) => void;
  onDeleteClass: (id: string) => void;
  onAddStudent: (classId: string, student: Omit<Student, 'id'>) => void;
  onAddStudentsBulk: (classId: string, students: Omit<Student, 'id'>[]) => void;
  onUpdateStudent: (
    classId: string,
    studentId: string,
    patch: Partial<Omit<Student, 'id'>>
  ) => void;
  onDeleteStudent: (classId: string, studentId: string) => void;
  onImportExcelBulk: (
    payload: ImportSubjectsAndClassesPayload
  ) => ImportSubjectsAndClassesSummary;
}

export function SubjectsClassesView({
  subjects,
  classes,
  schedules,
  atpItems,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject,
  onAddClass,
  onUpdateClass,
  onDeleteClass,
  onAddStudent,
  onAddStudentsBulk,
  onUpdateStudent,
  onDeleteStudent,
  onImportExcelBulk,
}: SubjectsClassesViewProps) {
  const [activeTab, setActiveTab] = useState<'pelajaran' | 'kelas'>('pelajaran');

  // Subject states
  const [subjectModalOpen, setSubjectModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [confirmDeleteSubjectId, setConfirmDeleteSubjectId] = useState<string | null>(
    null
  );
  const [subjectForm, setSubjectForm] = useState<Omit<Subject, 'id'>>({
    code: '',
    name: '',
    gradeLevel: 'X (Fase E)',
    kktp: 75,
    weeklyHours: 2,
    description: '',
  });

  // Class & student states
  const [selectedClassId, setSelectedClassId] = useState<string>(
    classes[0]?.id ?? ''
  );
  const [classModalOpen, setClassModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<Classroom | null>(null);
  const [classForm, setClassForm] = useState({
    name: '',
    grade: 'X',
    major: 'Umum',
    room: '',
    homeroomTeacher: '',
  });

  const [studentModalOpen, setStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [studentForm, setStudentForm] = useState<{
    nis: string;
    name: string;
    gender: 'L' | 'P';
  }>({ nis: '', name: '', gender: 'L' });

  const [bulkModalOpen, setBulkModalOpen] = useState(false);
  const [bulkText, setBulkText] = useState('');
  const [confirmDeleteClassId, setConfirmDeleteClassId] = useState<string | null>(
    null
  );

  // Excel import modal states
  const [excelModalOpen, setExcelModalOpen] = useState(false);
  const [excelParsing, setExcelParsing] = useState(false);
  const [excelError, setExcelError] = useState<string | null>(null);
  const [excelPreview, setExcelPreview] = useState<ExcelParseResult | null>(null);
  const [excelPreviewTab, setExcelPreviewTab] = useState<'pelajaran' | 'kelas'>(
    'pelajaran'
  );
  const [excelMode, setExcelMode] = useState<'merge' | 'replace'>('merge');
  const [unassignedClassName, setUnassignedClassName] = useState<string>('');
  const [dragActive, setDragActive] = useState(false);
  const [importFeedback, setImportFeedback] = useState<string | null>(null);
  const excelInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!classes.some((c) => c.id === selectedClassId)) {
      setSelectedClassId(classes[0]?.id ?? '');
    }
  }, [classes, selectedClassId]);

  const activeClass = useMemo(
    () => classes.find((c) => c.id === selectedClassId),
    [classes, selectedClassId]
  );

  const totalStudentsAll = useMemo(
    () => classes.reduce((sum, c) => sum + c.students.length, 0),
    [classes]
  );

  // Subject Handlers
  const openAddSubject = () => {
    setEditingSubject(null);
    setSubjectForm({
      code: '',
      name: '',
      gradeLevel: 'X (Fase E)',
      kktp: 75,
      weeklyHours: 2,
      description: '',
    });
    setSubjectModalOpen(true);
  };

  const openEditSubject = (subj: Subject) => {
    setEditingSubject(subj);
    setSubjectForm({
      code: subj.code,
      name: subj.name,
      gradeLevel: subj.gradeLevel,
      kktp: subj.kktp,
      weeklyHours: subj.weeklyHours,
      description: subj.description,
    });
    setSubjectModalOpen(true);
  };

  const handleSaveSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectForm.name.trim() || !subjectForm.code.trim()) return;
    if (editingSubject) {
      onUpdateSubject(editingSubject.id, subjectForm);
    } else {
      onAddSubject(subjectForm);
    }
    setSubjectModalOpen(false);
  };

  // Class Handlers
  const openAddClass = () => {
    setEditingClass(null);
    setClassForm({
      name: '',
      grade: 'X',
      major: 'Umum',
      room: '',
      homeroomTeacher: '',
    });
    setClassModalOpen(true);
  };

  const openEditClass = (cls: Classroom) => {
    setEditingClass(cls);
    setClassForm({
      name: cls.name,
      grade: cls.grade,
      major: cls.major,
      room: cls.room,
      homeroomTeacher: cls.homeroomTeacher ?? '',
    });
    setClassModalOpen(true);
  };

  const handleSaveClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!classForm.name.trim()) return;
    if (editingClass) {
      onUpdateClass(editingClass.id, classForm);
    } else {
      const newId = onAddClass(classForm);
      setSelectedClassId(newId);
    }
    setClassModalOpen(false);
  };

  // Student Handlers
  const openAddStudent = () => {
    setEditingStudent(null);
    const nextNum = (activeClass?.students.length ?? 0) + 1;
    setStudentForm({
      nis: String(260000 + nextNum),
      name: '',
      gender: 'L',
    });
    setStudentModalOpen(true);
  };

  const openEditStudent = (st: Student) => {
    setEditingStudent(st);
    setStudentForm({ nis: st.nis, name: st.name, gender: st.gender });
    setStudentModalOpen(true);
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeClass || !studentForm.name.trim()) return;
    if (editingStudent) {
      onUpdateStudent(activeClass.id, editingStudent.id, studentForm);
    } else {
      onAddStudent(activeClass.id, studentForm);
    }
    setStudentModalOpen(false);
  };

  const handleSaveBulk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeClass) return;
    const lines = bulkText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);
    if (lines.length === 0) return;

    const baseNis = 261000 + activeClass.students.length + 1;
    const parsed: Omit<Student, 'id'>[] = lines.map((line, idx) => {
      const parts = line.split(/[\t,;]+/).map((p) => p.trim());
      if (parts.length >= 2 && /^\d+$/.test(parts[0])) {
        const g = parts[2]?.toUpperCase() === 'P' ? 'P' : 'L';
        return {
          nis: parts[0],
          name: parts[1],
          gender: g,
        };
      }
      const g = parts[1]?.toUpperCase() === 'P' ? 'P' : 'L';
      return {
        nis: String(baseNis + idx),
        name: parts[0],
        gender: g,
      };
    });

    onAddStudentsBulk(activeClass.id, parsed);
    setBulkText('');
    setBulkModalOpen(false);
  };

  const openExcelModal = () => {
    setExcelError(null);
    setExcelPreview(null);
    setExcelMode('merge');
    setUnassignedClassName(activeClass?.name ?? classes[0]?.name ?? 'X-1');
    setExcelModalOpen(true);
  };

  const handleExcelFileSelected = async (file: File | undefined) => {
    if (!file) return;
    setExcelParsing(true);
    setExcelError(null);
    try {
      const parsed = await parseExcelWorkbook(file);
      if (
        parsed.subjects.length === 0 &&
        parsed.classes.length === 0 &&
        parsed.unassignedStudents.length === 0
      ) {
        setExcelError(
          'Tidak ditemukan data Mata Pelajaran, Kelas, atau Siswa di file Excel ini. Unduh template Excel untuk melihat format kolom yang didukung.'
        );
        setExcelPreview(parsed);
      } else {
        setExcelPreview(parsed);
        if (parsed.subjects.length > 0 && parsed.classes.length === 0) {
          setExcelPreviewTab('pelajaran');
        } else if (parsed.classes.length > 0 || parsed.unassignedStudents.length > 0) {
          setExcelPreviewTab(
            parsed.subjects.length > 0 && activeTab === 'pelajaran'
              ? 'pelajaran'
              : 'kelas'
          );
        }
      }
    } catch {
      setExcelError(
        'File gagal dibaca. Pastikan file berformat .xlsx, .xls, atau .csv yang valid.'
      );
    } finally {
      setExcelParsing(false);
    }
  };

  const handleConfirmExcelImport = () => {
    if (!excelPreview) return;

    const mergedClasses = excelPreview.classes.map((c) => ({
      ...c,
      students: [...c.students],
    }));

    if (excelPreview.unassignedStudents.length > 0) {
      const targetName = unassignedClassName.trim() || 'X-1';
      const existingTarget = mergedClasses.find(
        (c) => c.name.trim().toLowerCase() === targetName.toLowerCase()
      );
      if (existingTarget) {
        existingTarget.students.push(...excelPreview.unassignedStudents);
      } else {
        const matchedExisting = classes.find(
          (c) => c.name.trim().toLowerCase() === targetName.toLowerCase()
        );
        mergedClasses.push({
          name: matchedExisting?.name ?? targetName,
          grade: matchedExisting?.grade ?? (targetName.startsWith('XII') ? 'XII' : targetName.startsWith('XI') ? 'XI' : 'X'),
          major: matchedExisting?.major ?? 'Umum',
          room: matchedExisting?.room ?? '',
          homeroomTeacher: matchedExisting?.homeroomTeacher ?? '',
          students: [...excelPreview.unassignedStudents],
        });
      }
    }

    const summary = onImportExcelBulk({
      subjects: excelPreview.subjects,
      classes: mergedClasses,
      mode: excelMode,
    });

    const parts: string[] = [];
    if (summary.addedSubjects > 0) {
      parts.push(`${summary.addedSubjects} mapel ditambahkan`);
    }
    if (summary.updatedSubjects > 0) {
      parts.push(`${summary.updatedSubjects} mapel diperbarui`);
    }
    if (summary.addedClasses > 0) {
      parts.push(`${summary.addedClasses} kelas ditambahkan`);
    }
    if (summary.updatedClasses > 0) {
      parts.push(`${summary.updatedClasses} kelas diperbarui`);
    }
    if (summary.addedStudents > 0) {
      parts.push(`${summary.addedStudents} siswa ditambahkan`);
    }

    setImportFeedback(
      parts.length > 0
        ? `Impor Excel (${excelPreview.fileName}) selesai: ${parts.join(', ')}.`
        : `File ${excelPreview.fileName} sudah sesuai dengan data yang ada (tidak ada baris baru ditambahkan).`
    );

    if (mergedClasses.length > 0 && excelPreview.subjects.length === 0) {
      setActiveTab('kelas');
    } else if (excelPreview.subjects.length > 0 && mergedClasses.length === 0) {
      setActiveTab('pelajaran');
    }

    setExcelModalOpen(false);
    setExcelPreview(null);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
          <button
            type="button"
            onClick={() => setActiveTab('pelajaran')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'pelajaran'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookMarked className="h-3.5 w-3.5" />
            Pelajaran Guru ({subjects.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('kelas')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'kelas'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <GraduationCap className="h-3.5 w-3.5" />
            Kelas & Siswa ({classes.length} kelas · {totalStudentsAll} siswa)
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={openExcelModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-700" />
            Impor Excel Sekaligus
          </button>

          {activeTab === 'pelajaran' ? (
            <button
              type="button"
              onClick={openAddSubject}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              Tambah Mata Pelajaran
            </button>
          ) : (
            <button
              type="button"
              onClick={openAddClass}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              Tambah Kelas
            </button>
          )}
        </div>
      </div>

      {importFeedback && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs font-medium text-emerald-900">
            <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
            <span>{importFeedback}</span>
          </div>
          <button
            type="button"
            onClick={() => setImportFeedback(null)}
            aria-label="Tutup pemberitahuan impor"
            className="p-1 text-emerald-700 hover:text-emerald-950 rounded"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {activeTab === 'pelajaran' ? (
        subjects.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
            <p className="text-sm font-medium text-slate-900">
              Belum ada mata pelajaran yang diampu.
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Daftarkan mata pelajaran satu per satu atau unggah file Excel untuk mengisi seluruh pelajaran, kelas, dan siswa sekaligus.
            </p>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
              <button
                type="button"
                onClick={openExcelModal}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
              >
                <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-700" />
                Impor File Excel
              </button>
              <button
                type="button"
                onClick={openAddSubject}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
              >
                <Plus className="h-3.5 w-3.5" />
                Tambah Mata Pelajaran
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-3 pl-6 pr-3 w-28">Kode Guru</th>
                    <th className="py-3 px-3 min-w-[200px]">Mata Pelajaran</th>
                    <th className="py-3 px-3 w-36">Tingkat / Fase</th>
                    <th className="py-3 px-3 w-20 text-right">KKTP</th>
                    <th className="py-3 px-3 w-24 text-right">JP/Minggu</th>
                    <th className="py-3 px-3 w-28 text-right">Jadwal & TP</th>
                    <th className="py-3 pl-3 pr-6 w-24 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs">
                  {subjects.map((subj) => {
                    const slotCount = schedules.filter(
                      (s) => s.subjectId === subj.id || s.subject === subj.name
                    ).length;
                    const atpCount = atpItems.filter(
                      (a) => a.subjectId === subj.id
                    ).length;

                    return (
                      <React.Fragment key={subj.id}>
                        <tr className="hover:bg-slate-50/70">
                          <td className="py-3.5 pl-6 pr-3 font-mono font-semibold text-blue-700">
                            {subj.code}
                          </td>
                          <td className="py-3.5 px-3">
                            <p className="font-semibold text-slate-900">
                              {subj.name}
                            </p>
                            {subj.description && (
                              <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                                {subj.description}
                              </p>
                            )}
                          </td>
                          <td className="py-3.5 px-3 text-slate-700">
                            {subj.gradeLevel}
                          </td>
                          <td className="py-3.5 px-3 text-right font-mono text-slate-800 tabular-nums">
                            {subj.kktp}
                          </td>
                          <td className="py-3.5 px-3 text-right font-mono text-slate-800 tabular-nums">
                            {subj.weeklyHours} JP
                          </td>
                          <td className="py-3.5 px-3 text-right text-slate-600 tabular-nums">
                            {slotCount} sesi · {atpCount} TP
                          </td>
                          <td className="py-3.5 pl-3 pr-6 text-right">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditSubject(subj)}
                                aria-label={`Edit ${subj.name}`}
                                className="p-1.5 text-slate-400 hover:text-slate-700 rounded"
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteSubjectId(subj.id)}
                                aria-label={`Hapus ${subj.name}`}
                                className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                        {confirmDeleteSubjectId === subj.id && (
                          <tr className="bg-red-50">
                            <td colSpan={7} className="px-6 py-2.5">
                              <div className="flex items-center justify-between gap-3">
                                <span className="text-xs text-red-800">
                                  Hapus mata pelajaran <strong>{subj.name}</strong> beserta ATP yang terhubung?
                                </span>
                                <div className="flex items-center gap-2 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => setConfirmDeleteSubjectId(null)}
                                    className="px-2.5 py-1 text-xs font-medium text-slate-600"
                                  >
                                    Batal
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onDeleteSubject(subj.id);
                                      setConfirmDeleteSubjectId(null);
                                    }}
                                    className="px-2.5 py-1 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded"
                                  >
                                    Hapus
                                  </button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h2 className="font-display text-sm font-semibold text-slate-900">
                  Daftar Kelas Guru
                </h2>
                <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                  {classes.length} kelas diajar
                </p>
              </div>
              <button
                type="button"
                onClick={openAddClass}
                className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:text-blue-800 whitespace-nowrap shrink-0"
              >
                <Plus className="h-3.5 w-3.5" />
                Tambah
              </button>
            </div>

            {classes.length === 0 ? (
              <div className="px-5 py-10 text-center text-xs text-slate-500">
                Belum ada kelas. Klik Tambah Kelas untuk membuat rombongan belajar.
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {classes.map((cls) => {
                  const isSelected = cls.id === selectedClassId;
                  const classScheduleCount = schedules.filter(
                    (s) => s.classId === cls.id
                  ).length;

                  return (
                    <div
                      key={cls.id}
                      className={`px-5 py-3.5 flex items-center justify-between gap-2 transition-colors ${
                        isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => setSelectedClassId(cls.id)}
                        className="text-left min-w-0 flex-1"
                      >
                        <p className="font-display text-sm font-semibold text-slate-900 truncate">
                          {cls.name}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5 truncate tabular-nums">
                          {cls.major} · {cls.room || 'Tanpa ruang'} ·{' '}
                          {cls.students.length} siswa · {classScheduleCount} jadwal
                        </p>
                        {cls.homeroomTeacher && (
                          <p className="text-[11px] text-slate-400 truncate mt-0.5">
                            Wali Kelas: {cls.homeroomTeacher}
                          </p>
                        )}
                      </button>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => openEditClass(cls)}
                          aria-label={`Edit kelas ${cls.name}`}
                          className="p-1.5 text-slate-400 hover:text-slate-700 rounded"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteClassId(cls.id)}
                          aria-label={`Hapus kelas ${cls.name}`}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {confirmDeleteClassId && (
              <div className="p-4 bg-red-50 border-t border-red-200 space-y-2">
                <p className="text-xs text-red-800">
                  Hapus kelas{' '}
                  <strong>
                    {classes.find((c) => c.id === confirmDeleteClassId)?.name}
                  </strong>{' '}
                  beserta jadwal terkait?
                </p>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteClassId(null)}
                    className="px-2.5 py-1 text-xs font-medium text-slate-600"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteClass(confirmDeleteClassId);
                      setConfirmDeleteClassId(null);
                    }}
                    className="px-2.5 py-1 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded"
                  >
                    Ya, Hapus
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden">
            {!activeClass ? (
              <div className="px-6 py-14 text-center text-xs text-slate-500">
                Pilih atau buat kelas di sebelah kiri untuk mengelola daftar siswa.
              </div>
            ) : (
              <>
                <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-base font-semibold text-slate-900">
                      Daftar Siswa — {activeClass.name}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                      Tingkat {activeClass.grade} · {activeClass.major} ·{' '}
                      {activeClass.students.length} siswa terdaftar
                      {activeClass.homeroomTeacher
                        ? ` · Wali Kelas: ${activeClass.homeroomTeacher}`
                        : ''}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => setBulkModalOpen(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
                    >
                      <Users className="h-3.5 w-3.5" />
                      Tempel Banyak
                    </button>
                    <button
                      type="button"
                      onClick={openAddStudent}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
                    >
                      <UserPlus className="h-3.5 w-3.5" />
                      Tambah Siswa
                    </button>
                  </div>
                </div>

                {activeClass.students.length === 0 ? (
                  <div className="px-6 py-12 text-center">
                    <p className="text-sm font-medium text-slate-900">
                      Belum ada siswa di kelas {activeClass.name}.
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Tambahkan siswa satu per satu atau tempel daftar nama langsung dari Excel.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                          <th className="py-2.5 pl-6 pr-2 w-12">No</th>
                          <th className="py-2.5 px-2 w-28">NIS</th>
                          <th className="py-2.5 px-2">Nama Lengkap</th>
                          <th className="py-2.5 px-2 w-16 text-center">L/P</th>
                          <th className="py-2.5 pl-2 pr-6 w-24 text-right">Aksi</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 text-xs">
                        {activeClass.students.map((st, idx) => (
                          <tr key={st.id} className="hover:bg-slate-50/70">
                            <td className="py-2.5 pl-6 pr-2 text-slate-500 tabular-nums">
                              {idx + 1}
                            </td>
                            <td className="py-2.5 px-2 font-mono text-slate-600 tabular-nums">
                              {st.nis}
                            </td>
                            <td className="py-2.5 px-2 font-medium text-slate-900">
                              {st.name}
                            </td>
                            <td className="py-2.5 px-2 text-center text-slate-600">
                              {st.gender}
                            </td>
                            <td className="py-2.5 pl-2 pr-6 text-right">
                              <div className="inline-flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => openEditStudent(st)}
                                  aria-label={`Edit ${st.name}`}
                                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded"
                                >
                                  <Pencil className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    onDeleteStudent(activeClass.id, st.id)
                                  }
                                  aria-label={`Hapus ${st.name}`}
                                  className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {subjectModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h3 className="font-display text-base font-semibold text-slate-900">
                {editingSubject
                  ? 'Ubah Mata Pelajaran'
                  : 'Tambah Mata Pelajaran'}
              </h3>
              <button
                type="button"
                onClick={() => setSubjectModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSaveSubject} className="p-6 space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Kode Guru
                  </label>
                  <input
                    type="text"
                    required
                    value={subjectForm.code}
                    onChange={(e) =>
                      setSubjectForm({ ...subjectForm, code: e.target.value })
                    }
                    placeholder="GR-01"
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Nama Mata Pelajaran
                  </label>
                  <input
                    type="text"
                    required
                    value={subjectForm.name}
                    onChange={(e) =>
                      setSubjectForm({ ...subjectForm, name: e.target.value })
                    }
                    placeholder="Matematika Wajib"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    KKTP
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    required
                    value={subjectForm.kktp}
                    onChange={(e) =>
                      setSubjectForm({
                        ...subjectForm,
                        kktp: Number(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div className="col-span-1">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    JP/Minggu
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    required
                    value={subjectForm.weeklyHours}
                    onChange={(e) =>
                      setSubjectForm({
                        ...subjectForm,
                        weeklyHours: Math.max(1, Number(e.target.value) || 1),
                      })
                    }
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div className="col-span-1">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tingkat/Fase
                  </label>
                  <input
                    type="text"
                    value={subjectForm.gradeLevel}
                    onChange={(e) =>
                      setSubjectForm({
                        ...subjectForm,
                        gradeLevel: e.target.value,
                      })
                    }
                    placeholder="X (Fase E)"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Deskripsi / Ruang Lingkup Mata Pelajaran
                </label>
                <textarea
                  rows={3}
                  value={subjectForm.description}
                  onChange={(e) =>
                    setSubjectForm({
                      ...subjectForm,
                      description: e.target.value,
                    })
                  }
                  placeholder="Ringkasan fokus materi atau capaian semester ini..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSubjectModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
                >
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {classModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h3 className="font-display text-base font-semibold text-slate-900">
                {editingClass ? 'Ubah Data Kelas' : 'Tambah Kelas Baru'}
              </h3>
              <button
                type="button"
                onClick={() => setClassModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSaveClass} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Nama Kelas
                </label>
                <input
                  type="text"
                  required
                  value={classForm.name}
                  onChange={(e) =>
                    setClassForm({ ...classForm, name: e.target.value })
                  }
                  placeholder="Contoh: X-A atau XI-IPA-1"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tingkat
                  </label>
                  <input
                    type="text"
                    value={classForm.grade}
                    onChange={(e) =>
                      setClassForm({ ...classForm, grade: e.target.value })
                    }
                    placeholder="X / XI / XII"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Ruang Kelas
                  </label>
                  <input
                    type="text"
                    value={classForm.room}
                    onChange={(e) =>
                      setClassForm({ ...classForm, room: e.target.value })
                    }
                    placeholder="Ruang 104"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Jurusan / Program
                </label>
                <input
                  type="text"
                  value={classForm.major}
                  onChange={(e) =>
                    setClassForm({ ...classForm, major: e.target.value })
                  }
                  placeholder="Contoh: MIPA, IPS, Fase E"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Wali Kelas (Opsional)
                </label>
                <input
                  type="text"
                  value={classForm.homeroomTeacher}
                  onChange={(e) =>
                    setClassForm({
                      ...classForm,
                      homeroomTeacher: e.target.value,
                    })
                  }
                  placeholder="Nama wali kelas"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setClassModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
                >
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {studentModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h3 className="font-display text-base font-semibold text-slate-900">
                {editingStudent ? 'Edit Data Siswa' : 'Tambah Siswa'}
              </h3>
              <button
                type="button"
                onClick={() => setStudentModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSaveStudent} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    NIS
                  </label>
                  <input
                    type="text"
                    required
                    value={studentForm.nis}
                    onChange={(e) =>
                      setStudentForm({ ...studentForm, nis: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Jenis Kelamin
                  </label>
                  <select
                    value={studentForm.gender}
                    onChange={(e) =>
                      setStudentForm({
                        ...studentForm,
                        gender: e.target.value as 'L' | 'P',
                      })
                    }
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Nama Lengkap Siswa
                </label>
                <input
                  type="text"
                  required
                  value={studentForm.name}
                  onChange={(e) =>
                    setStudentForm({ ...studentForm, name: e.target.value })
                  }
                  placeholder="Nama lengkap siswa"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStudentModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
                >
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {bulkModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h3 className="font-display text-base font-semibold text-slate-900">
                Tambah Banyak Siswa — {activeClass?.name}
              </h3>
              <button
                type="button"
                onClick={() => setBulkModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSaveBulk} className="p-6 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                Tempel daftar siswa satu baris per siswa. Format yang didukung:{' '}
                <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">
                  NIS, Nama Siswa, L/P
                </code>{' '}
                atau langsung{' '}
                <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">
                  Nama Siswa
                </code>
                .
              </p>
              <textarea
                rows={7}
                required
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                placeholder={
                  '261011, Budi Santoso, L\n261012, Citra Dewi, P\n261013, Dedi Pratama, L'
                }
                className="w-full px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setBulkModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
                >
                  Tambahkan Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {excelModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="excel-import-title"
        >
          <div className="w-full max-w-3xl bg-white border border-slate-200 rounded-xl shadow-lg max-h-[90vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 shrink-0">
              <div>
                <h3
                  id="excel-import-title"
                  className="font-display text-base font-semibold text-slate-900"
                >
                  Impor Pelajaran, Kelas & Siswa Sekaligus (Excel)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Unggah satu file Excel (.xlsx, .xls, atau .csv) untuk menambahkan seluruh mata pelajaran, rombel kelas, dan daftar siswa sekaligus.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setExcelModalOpen(false)}
                aria-label="Tutup modal impor Excel"
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-slate-900">
                    Format File Excel yang Didukung
                  </p>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Anda dapat memakai template 3 sheet (<strong>Mata Pelajaran</strong>, <strong>Kelas</strong>, <strong>Siswa</strong>) atau file daftar siswa yang memiliki kolom <strong>Nama Kelas</strong>, <strong>NIS</strong>, <strong>Nama Lengkap</strong>, dan <strong>L/P</strong>.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={downloadExcelTemplate}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-blue-700 bg-white border border-blue-200 hover:bg-blue-50 rounded-lg whitespace-nowrap shrink-0"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Unduh Template (.xlsx)
                  </button>
                  {(subjects.length > 0 || classes.length > 0) && (
                    <button
                      type="button"
                      onClick={() => exportSubjectsClassesToExcel(subjects, classes)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg whitespace-nowrap shrink-0"
                    >
                      <FileSpreadsheet className="h-3.5 w-3.5" />
                      Ekspor Data (.xlsx)
                    </button>
                  )}
                </div>
              </div>

              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragActive(false);
                  const dropped = e.dataTransfer.files?.[0];
                  void handleExcelFileSelected(dropped);
                }}
                className={`border-2 border-dashed rounded-xl p-6 text-center transition-colors ${
                  dragActive
                    ? 'border-blue-600 bg-blue-50/50'
                    : 'border-slate-300 bg-white hover:border-slate-400'
                }`}
              >
                <Upload className="h-6 w-6 text-slate-400 mx-auto" />
                <p className="text-sm font-medium text-slate-900 mt-2">
                  {excelParsing
                    ? 'Membaca isi file Excel...'
                    : excelPreview
                    ? `File terpilih: ${excelPreview.fileName}`
                    : 'Tarik file Excel ke sini atau pilih file dari perangkat'}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Mendukung format .xlsx, .xls, dan .csv
                </p>
                <input
                  ref={excelInputRef}
                  type="file"
                  accept=".xlsx,.xls,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    void handleExcelFileSelected(file);
                    e.target.value = '';
                  }}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={excelParsing}
                  onClick={() => excelInputRef.current?.click()}
                  className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg whitespace-nowrap shrink-0"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5" />
                  {excelPreview ? 'Pilih File Lain' : 'Pilih File Excel'}
                </button>
              </div>

              {excelError && (
                <div
                  role="alert"
                  className="bg-red-50 border border-red-200 rounded-lg px-4 py-3 flex items-start gap-2.5 text-xs text-red-800"
                >
                  <AlertCircle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{excelError}</span>
                </div>
              )}

              {excelPreview &&
                (excelPreview.subjects.length > 0 ||
                  excelPreview.classes.length > 0 ||
                  excelPreview.unassignedStudents.length > 0) && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                        <p className="text-[11px] text-slate-500">Mata Pelajaran</p>
                        <p className="font-display text-lg font-semibold text-slate-900 tabular-nums mt-0.5">
                          {excelPreview.subjects.length}
                        </p>
                      </div>
                      <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                        <p className="text-[11px] text-slate-500">Kelas / Rombel</p>
                        <p className="font-display text-lg font-semibold text-slate-900 tabular-nums mt-0.5">
                          {excelPreview.classes.length}
                        </p>
                      </div>
                      <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                        <p className="text-[11px] text-slate-500">Total Siswa</p>
                        <p className="font-display text-lg font-semibold text-slate-900 tabular-nums mt-0.5">
                          {excelPreview.classes.reduce(
                            (sum, c) => sum + c.students.length,
                            0
                          ) + excelPreview.unassignedStudents.length}
                        </p>
                      </div>
                    </div>

                    {excelPreview.warnings.length > 0 && (
                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 space-y-1 text-xs text-amber-900">
                        {excelPreview.warnings.map((w, idx) => (
                          <p key={idx}>• {w}</p>
                        ))}
                      </div>
                    )}

                    {excelPreview.unassignedStudents.length > 0 && (
                      <div className="bg-blue-50/70 border border-blue-200 rounded-lg p-3.5 space-y-2">
                        <label
                          htmlFor="unassigned-class-target"
                          className="block text-xs font-medium text-slate-800"
                        >
                          Kelas Tujuan untuk {excelPreview.unassignedStudents.length} Siswa Tanpa Kolom Nama Kelas:
                        </label>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <input
                            id="unassigned-class-target"
                            type="text"
                            value={unassignedClassName}
                            onChange={(e) => setUnassignedClassName(e.target.value)}
                            placeholder="Contoh: X-1"
                            className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                          />
                          {classes.length > 0 && (
                            <select
                              value=""
                              onChange={(e) => {
                                if (e.target.value) setUnassignedClassName(e.target.value);
                              }}
                              className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                            >
                              <option value="">Pilih dari kelas yang ada...</option>
                              {classes.map((c) => (
                                <option key={c.id} value={c.name}>
                                  {c.name}
                                </option>
                              ))}
                            </select>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="border border-slate-200 rounded-xl overflow-hidden">
                      <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3">
                        <span className="text-xs font-semibold text-slate-800">
                          Pratinjau Data Terbaca
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setExcelPreviewTab('pelajaran')}
                            className={`px-2.5 py-1 text-[11px] font-medium rounded ${
                              excelPreviewTab === 'pelajaran'
                                ? 'bg-white text-slate-900 border border-slate-200'
                                : 'text-slate-500 hover:text-slate-900'
                            }`}
                          >
                            Mata Pelajaran ({excelPreview.subjects.length})
                          </button>
                          <button
                            type="button"
                            onClick={() => setExcelPreviewTab('kelas')}
                            className={`px-2.5 py-1 text-[11px] font-medium rounded ${
                              excelPreviewTab === 'kelas'
                                ? 'bg-white text-slate-900 border border-slate-200'
                                : 'text-slate-500 hover:text-slate-900'
                            }`}
                          >
                            Kelas & Siswa ({excelPreview.classes.length})
                          </button>
                        </div>
                      </div>

                      {excelPreviewTab === 'pelajaran' ? (
                        excelPreview.subjects.length === 0 ? (
                          <p className="p-4 text-xs text-slate-500 text-center">
                            Tidak ada data mata pelajaran di file ini.
                          </p>
                        ) : (
                          <div className="max-h-44 overflow-auto">
                            <table className="w-full text-left text-xs border-collapse">
                              <thead className="bg-slate-50/70 text-[11px] text-slate-500 border-b border-slate-200">
                                <tr>
                                  <th className="py-2 px-3">Kode Guru</th>
                                  <th className="py-2 px-3">Mata Pelajaran</th>
                                  <th className="py-2 px-3">Tingkat/Fase</th>
                                  <th className="py-2 px-3 text-right">KKTP</th>
                                  <th className="py-2 px-3 text-right">JP</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200">
                                {excelPreview.subjects.slice(0, 15).map((s, idx) => (
                                  <tr key={idx}>
                                    <td className="py-1.5 px-3 font-mono text-blue-700">
                                      {s.code}
                                    </td>
                                    <td className="py-1.5 px-3 font-medium text-slate-900">
                                      {s.name}
                                    </td>
                                    <td className="py-1.5 px-3 text-slate-600">
                                      {s.gradeLevel}
                                    </td>
                                    <td className="py-1.5 px-3 text-right tabular-nums">
                                      {s.kktp}
                                    </td>
                                    <td className="py-1.5 px-3 text-right tabular-nums">
                                      {s.weeklyHours}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )
                      ) : excelPreview.classes.length === 0 &&
                        excelPreview.unassignedStudents.length === 0 ? (
                        <p className="p-4 text-xs text-slate-500 text-center">
                          Tidak ada data kelas atau siswa di file ini.
                        </p>
                      ) : (
                        <div className="max-h-48 overflow-auto divide-y divide-slate-200 text-xs">
                          {excelPreview.classes.map((cls, idx) => (
                            <div key={idx} className="px-4 py-2.5 flex items-center justify-between gap-3">
                              <div>
                                <p className="font-semibold text-slate-900">
                                  {cls.name}
                                </p>
                                <p className="text-[11px] text-slate-500">
                                  Tingkat {cls.grade} · {cls.major}
                                  {cls.room ? ` · ${cls.room}` : ''}
                                  {cls.homeroomTeacher
                                    ? ` · Wali: ${cls.homeroomTeacher}`
                                    : ''}
                                </p>
                              </div>
                              <span className="font-mono text-xs text-slate-700 tabular-nums shrink-0">
                                {cls.students.length} siswa
                              </span>
                            </div>
                          ))}
                          {excelPreview.unassignedStudents.length > 0 && (
                            <div className="px-4 py-2.5 flex items-center justify-between gap-3 bg-blue-50/40">
                              <div>
                                <p className="font-semibold text-slate-900">
                                  {unassignedClassName.trim() || 'X-1'} (Target Siswa)
                                </p>
                                <p className="text-[11px] text-slate-500">
                                  Siswa dari sheet tanpa kolom Nama Kelas
                                </p>
                              </div>
                              <span className="font-mono text-xs text-blue-700 tabular-nums shrink-0">
                                {excelPreview.unassignedStudents.length} siswa
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <p className="text-xs font-medium text-slate-800">
                        Metode Penggabungan Data
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <label
                          className={`flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer text-xs ${
                            excelMode === 'merge'
                              ? 'border-blue-600 bg-blue-50/50'
                              : 'border-slate-200 bg-white'
                          }`}
                        >
                          <input
                            type="radio"
                            name="excel-import-mode"
                            checked={excelMode === 'merge'}
                            onChange={() => setExcelMode('merge')}
                            className="mt-0.5"
                          />
                          <div>
                            <p className="font-semibold text-slate-900">
                              Gabungkan & Perbarui (Disarankan)
                            </p>
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              Menambahkan data baru dan memperbarui mata pelajaran/kelas dengan nama yang sama tanpa menghapus jadwal yang sudah ada.
                            </p>
                          </div>
                        </label>
                        <label
                          className={`flex items-start gap-2.5 p-3 rounded-lg border cursor-pointer text-xs ${
                            excelMode === 'replace'
                              ? 'border-blue-600 bg-blue-50/50'
                              : 'border-slate-200 bg-white'
                          }`}
                        >
                          <input
                            type="radio"
                            name="excel-import-mode"
                            checked={excelMode === 'replace'}
                            onChange={() => setExcelMode('replace')}
                            className="mt-0.5"
                          />
                          <div>
                            <p className="font-semibold text-slate-900">
                              Ganti Data Sesuai File Excel
                            </p>
                            <p className="text-[11px] text-slate-500 mt-0.5">
                              Mengganti daftar mata pelajaran dan/atau daftar kelas sesuai isi file Excel yang diunggah.
                            </p>
                          </div>
                        </label>
                      </div>
                    </div>
                  </div>
                )}
            </div>

            <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setExcelModalOpen(false)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={
                  !excelPreview ||
                  (excelPreview.subjects.length === 0 &&
                    excelPreview.classes.length === 0 &&
                    excelPreview.unassignedStudents.length === 0)
                }
                onClick={handleConfirmExcelImport}
                className="px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 disabled:cursor-not-allowed rounded-lg whitespace-nowrap shrink-0"
              >
                Impor Semua Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
