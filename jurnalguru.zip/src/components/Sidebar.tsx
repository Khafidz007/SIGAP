import React, { useState } from 'react';
import {
  CalendarDays,
  CalendarClock,
  ClipboardCheck,
  History,
  LayoutDashboard,
  Layers,
  GraduationCap,
  LogOut,
  Settings,
  ShieldCheck,
  X,
} from 'lucide-react';
import { NavSection, TeacherProfile, UserRole } from '../types/journal';
import { SCHOOL_LOGO_URL } from '../data/seedData';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  profile: TeacherProfile;
  userRole: UserRole;
  username: string;
  onOpenProfile: () => void;
  onLogout: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const BASE_NAV_ITEMS: {
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: 'ringkasan', label: 'Ringkasan Hari Ini', icon: LayoutDashboard },
  { id: 'jadwal', label: 'Jadwal Mengajar', icon: CalendarDays },
  { id: 'presensi', label: 'Presensi Siswa', icon: ClipboardCheck },
  { id: 'atp', label: 'ATP & Materi', icon: Layers },
  { id: 'riwayat', label: 'Riwayat Jurnal', icon: History },
  { id: 'pelajaran_kelas', label: 'Pelajaran & Kelas', icon: GraduationCap },
  { id: 'kalender', label: 'Kalender & Pengingat', icon: CalendarClock },
];

export function Sidebar({
  activeSection,
  onSelectSection,
  profile,
  userRole,
  username,
  onOpenProfile,
  onLogout,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const [imgError, setImgError] = useState(false);

  const navItems =
    userRole === 'admin'
      ? [
          ...BASE_NAV_ITEMS,
          { id: 'kelola_user' as NavSection, label: 'Kelola Akun Guru', icon: ShieldCheck },
        ]
      : BASE_NAV_ITEMS;

  const initials = profile.name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');

  const content = (
    <div className="flex h-full flex-col justify-between bg-white border-r border-slate-200">
      <div className="overflow-y-auto">
        <div className="flex items-center justify-between px-5 h-16 border-b border-slate-200">
          <button
            type="button"
            onClick={() => {
              onSelectSection('ringkasan');
              onCloseMobile();
            }}
            className="text-left min-w-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700 rounded"
          >
            <span className="block font-display text-lg font-bold tracking-tight text-slate-900 leading-none">
              SIGAP
            </span>
            <span className="block text-[10px] font-medium text-slate-500 truncate mt-1">
              Sistem Informasi Guru & Administrasi
            </span>
          </button>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Tutup menu navigasi"
            className="lg:hidden p-2 text-slate-500 hover:text-slate-900 rounded-md"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="px-5 pt-4 pb-4 flex items-center gap-3">
          <img
            src={profile.schoolLogoUrl || SCHOOL_LOGO_URL}
            alt={`Logo ${profile.school}`}
            referrerPolicy="no-referrer"
            className="h-9 w-9 object-contain shrink-0"
          />
          <div className="min-w-0">
            <p className="text-xs font-semibold text-slate-800 truncate">
              {profile.school}
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5 tabular-nums">
              Semester {profile.semester} · {profile.academicYear}
            </p>
          </div>
        </div>

        <nav aria-label="Menu utama" className="px-3 space-y-1 pb-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectSection(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700 ${
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    isActive ? 'text-blue-700' : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="p-3 border-t border-slate-200 space-y-1.5">
        <button
          type="button"
          onClick={() => {
            onOpenProfile();
            onCloseMobile();
          }}
          className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-100 transition-colors text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
        >
          <div className="h-9 w-9 rounded-lg overflow-hidden bg-slate-200 shrink-0 flex items-center justify-center border border-slate-200">
            {!imgError && profile.avatarUrl ? (
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="h-full w-full object-cover"
              />
            ) : (
              <span className="text-xs font-semibold text-slate-700">
                {initials || 'GR'}
              </span>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-slate-900 truncate">
              {profile.name}
            </p>
            <p className="text-xs text-slate-500 truncate">
              @{username} · {userRole === 'admin' ? 'Admin' : profile.subject}
            </p>
          </div>
          <Settings className="h-4 w-4 text-slate-400 shrink-0" />
        </button>

        <button
          type="button"
          onClick={() => {
            onCloseMobile();
            onLogout();
          }}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-slate-600 hover:text-red-700 hover:bg-red-50 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-600"
        >
          <LogOut className="h-3.5 w-3.5 shrink-0" />
          <span>Keluar Akun</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block w-[260px] shrink-0 h-screen sticky top-0 no-print">
        {content}
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden no-print">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative w-[272px] max-w-[85vw] h-full z-10">
            {content}
          </div>
        </div>
      )}
    </>
  );
}
