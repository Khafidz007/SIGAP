import React, { useMemo, useState } from 'react';
import { Plus, Trash2, CalendarClock, X } from 'lucide-react';
import {
  CalendarCategory,
  CalendarReminder,
  Classroom,
  ScheduleSlot,
  UserRole,
} from '../types/journal';
import {
  formatIndonesianDate,
  getDayOfWeekFromIso,
  getOffsetIsoDate,
  getTodayIsoDate,
} from '../data/seedData';

interface CalendarRemindersViewProps {
  userRole: UserRole;
  userId: string;
  reminders: CalendarReminder[];
  schedules: ScheduleSlot[];
  classes: Classroom[];
  onCreateReminder: (payload: {
    date: string;
    time?: string;
    title: string;
    description: string;
    scope: 'sekolah' | 'pribadi';
    category: CalendarCategory;
  }) => Promise<void>;
  onDeleteReminder: (id: string) => Promise<void>;
}

const CATEGORIES: CalendarCategory[] = [
  'Akademik',
  'Rapat',
  'Ujian',
  'Peringatan',
  'Pribadi',
];

export function CalendarRemindersView({
  userRole,
  userId,
  reminders,
  schedules,
  classes,
  onCreateReminder,
  onDeleteReminder,
}: CalendarRemindersViewProps) {
  const todayIso = getTodayIsoDate();
  const [selectedDate, setSelectedDate] = useState<string>(todayIso);
  const [scopeFilter, setScopeFilter] = useState<'semua' | 'sekolah' | 'pribadi'>(
    'semua'
  );
  const [modalOpen, setModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [form, setForm] = useState<{
    date: string;
    time: string;
    title: string;
    description: string;
    scope: 'sekolah' | 'pribadi';
    category: CalendarCategory;
  }>({
    date: todayIso,
    time: '07:30',
    title: '',
    description: '',
    scope: userRole === 'admin' ? 'sekolah' : 'pribadi',
    category: userRole === 'admin' ? 'Akademik' : 'Pribadi',
  });

  const weekDates = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const iso = getOffsetIsoDate(i);
      const [y, m, d] = iso.split('-').map(Number);
      const dt = new Date(y, (m || 1) - 1, d || 1);
      const weekdayShort = new Intl.DateTimeFormat('id-ID', {
        weekday: 'short',
      }).format(dt);
      const dayNum = String(dt.getDate()).padStart(2, '0');
      const monthShort = new Intl.DateTimeFormat('id-ID', {
        month: 'short',
      }).format(dt);
      const count = reminders.filter((r) => r.date === iso).length;
      return { iso, weekdayShort, dayNum, monthShort, count };
    });
  }, [reminders]);

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c])),
    [classes]
  );

  const selectedDayName = getDayOfWeekFromIso(selectedDate);
  const selectedDaySchedules = useMemo(
    () =>
      schedules
        .filter((s) => s.day === selectedDayName)
        .sort((a, b) => a.startTime.localeCompare(b.startTime)),
    [schedules, selectedDayName]
  );

  const filteredReminders = useMemo(() => {
    return reminders
      .filter((r) => (scopeFilter === 'semua' ? true : r.scope === scopeFilter))
      .sort(
        (a, b) =>
          a.date.localeCompare(b.date) ||
          (a.time ?? '').localeCompare(b.time ?? '')
      );
  }, [reminders, scopeFilter]);

  const selectedDateReminders = useMemo(
    () => filteredReminders.filter((r) => r.date === selectedDate),
    [filteredReminders, selectedDate]
  );

  const handleOpenCreate = () => {
    setErrorMsg(null);
    setForm({
      date: selectedDate || todayIso,
      time: '07:30',
      title: '',
      description: '',
      scope: userRole === 'admin' ? 'sekolah' : 'pribadi',
      category: userRole === 'admin' ? 'Akademik' : 'Pribadi',
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim() || !form.date) return;
    setSubmitting(true);
    setErrorMsg(null);
    try {
      await onCreateReminder({
        date: form.date,
        time: form.time.trim() || undefined,
        title: form.title.trim(),
        description: form.description.trim(),
        scope: form.scope,
        category: form.category,
      });
      setSelectedDate(form.date);
      setModalOpen(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Gagal menambah pengingat.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              Kalender Berjalan 7 Hari ke Depan
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Pilih tanggal untuk meninjau jadwal mengajar dan pengingat harian Anda
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {(['semua', 'sekolah', 'pribadi'] as const).map((sc) => (
                <button
                  key={sc}
                  type="button"
                  onClick={() => setScopeFilter(sc)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    scopeFilter === sc
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {sc === 'semua'
                    ? 'Semua'
                    : sc === 'sekolah'
                    ? 'Agenda Sekolah'
                    : 'Pengingat Pribadi'}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleOpenCreate}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              Tambah Pengingat
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
          {weekDates.map((d) => {
            const isSelected = d.iso === selectedDate;
            const isToday = d.iso === todayIso;
            return (
              <button
                key={d.iso}
                type="button"
                onClick={() => setSelectedDate(d.iso)}
                className={`p-3 rounded-lg border text-left transition-colors ${
                  isSelected
                    ? 'bg-blue-700 border-blue-700 text-white'
                    : 'bg-slate-50/70 border-slate-200 hover:bg-slate-100 text-slate-800'
                }`}
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className={isSelected ? 'text-blue-100' : 'text-slate-500'}>
                    {d.weekdayShort}
                  </span>
                  {isToday && (
                    <span
                      className={`font-semibold ${
                        isSelected ? 'text-white' : 'text-blue-700'
                      }`}
                    >
                      Hari Ini
                    </span>
                  )}
                </div>
                <p className="mt-1 font-display text-lg font-semibold tabular-nums">
                  {d.dayNum}{' '}
                  <span
                    className={`text-xs font-normal ${
                      isSelected ? 'text-blue-100' : 'text-slate-500'
                    }`}
                  >
                    {d.monthShort}
                  </span>
                </p>
                <p
                  className={`mt-1 text-[11px] tabular-nums ${
                    isSelected ? 'text-blue-100' : 'text-slate-500'
                  }`}
                >
                  {d.count} agenda
                </p>
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200">
            <h3 className="font-display text-sm font-semibold text-slate-900">
              Agenda {formatIndonesianDate(selectedDate)}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
              {selectedDaySchedules.length} jam mengajar ·{' '}
              {selectedDateReminders.length} pengingat
            </p>
          </div>

          <div className="divide-y divide-slate-200">
            {selectedDaySchedules.length > 0 && (
              <div className="p-5 space-y-2.5">
                <p className="text-[11px] font-semibold text-slate-500">
                  Jadwal Mengajar ({selectedDayName})
                </p>
                {selectedDaySchedules.map((slot) => {
                  const cls = classMap.get(slot.classId);
                  return (
                    <div
                      key={slot.id}
                      className="text-xs flex items-baseline justify-between gap-2"
                    >
                      <span className="font-medium text-slate-900 truncate">
                        {cls?.name ?? 'Kelas'} · {slot.subject}
                      </span>
                      <span className="font-mono text-slate-500 tabular-nums shrink-0">
                        {slot.startTime}–{slot.endTime}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            {selectedDateReminders.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                Tidak ada pengingat kalender khusus pada tanggal ini.
              </div>
            ) : (
              selectedDateReminders.map((ev) => {
                const canDelete =
                  userRole === 'admin' ||
                  (ev.scope === 'pribadi' && ev.ownerUserId === userId);
                return (
                  <div key={ev.id} className="p-5 space-y-1.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-xs text-slate-500 flex flex-wrap items-center gap-x-1.5">
                        <span className="font-semibold text-blue-700">
                          {ev.category}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {ev.scope === 'sekolah' ? 'Sekolah' : 'Pribadi'}
                        </span>
                        {ev.time && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">
                              {ev.time}
                            </span>
                          </>
                        )}
                      </div>
                      {canDelete && (
                        <button
                          type="button"
                          onClick={() => onDeleteReminder(ev.id)}
                          aria-label={`Hapus ${ev.title}`}
                          className="p-1 text-slate-400 hover:text-red-600 rounded"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                    <p className="text-sm font-semibold text-slate-900">
                      {ev.title}
                    </p>
                    {ev.description && (
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {ev.description}
                      </p>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="font-display text-sm font-semibold text-slate-900">
                Daftar Lengkap Pengingat Kalender
              </h3>
              <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                {filteredReminders.length} agenda tercatat
              </p>
            </div>
            <CalendarClock className="h-4 w-4 text-slate-400" />
          </div>

          {filteredReminders.length === 0 ? (
            <div className="px-6 py-12 text-center text-xs text-slate-500">
              Belum ada pengingat kalender yang tersimpan.
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {filteredReminders.map((ev) => {
                const canDelete =
                  userRole === 'admin' ||
                  (ev.scope === 'pribadi' && ev.ownerUserId === userId);
                const isToday = ev.date === todayIso;
                return (
                  <div
                    key={ev.id}
                    className={`px-6 py-4 flex items-start justify-between gap-4 ${
                      isToday ? 'bg-blue-50/40' : ''
                    }`}
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                        <span className="font-semibold text-slate-900">
                          {formatIndonesianDate(ev.date)}
                        </span>
                        {ev.time && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">
                              {ev.time}
                            </span>
                          </>
                        )}
                        <span aria-hidden="true">·</span>
                        <span className="font-medium text-blue-700">
                          {ev.category}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {ev.scope === 'sekolah'
                            ? 'Agenda Sekolah'
                            : 'Pengingat Pribadi'}
                        </span>
                      </div>
                      <p className="text-sm font-semibold text-slate-900">
                        {ev.title}
                      </p>
                      {ev.description && (
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {ev.description}
                        </p>
                      )}
                    </div>

                    {canDelete && (
                      <button
                        type="button"
                        onClick={() => onDeleteReminder(ev.id)}
                        aria-label={`Hapus ${ev.title}`}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded shrink-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h3 className="font-display text-base font-semibold text-slate-900">
                Tambah Pengingat Kalender
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {errorMsg && (
                <p className="text-xs text-red-700 bg-red-50 border border-red-200 px-3 py-2 rounded-lg">
                  {errorMsg}
                </p>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Jam (Opsional)
                  </label>
                  <input
                    type="time"
                    value={form.time}
                    onChange={(e) => setForm({ ...form, time: e.target.value })}
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Kategori
                  </label>
                  <select
                    value={form.category}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        category: e.target.value as CalendarCategory,
                      })
                    }
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Cakupan Pengingat
                  </label>
                  <select
                    value={form.scope}
                    disabled={userRole !== 'admin'}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        scope: e.target.value as 'sekolah' | 'pribadi',
                      })
                    }
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white disabled:bg-slate-100 focus:outline-none focus:border-blue-600"
                  >
                    <option value="pribadi">Pengingat Pribadi</option>
                    {userRole === 'admin' && (
                      <option value="sekolah">Semua Guru (Sekolah)</option>
                    )}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Judul Pengingat / Kegiatan
                </label>
                <input
                  type="text"
                  required
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="Contoh: Pengumpulan Soal UAS atau Rapat MGMP"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Catatan / Keterangan
                </label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                  placeholder="Detail lokasi atau hal yang perlu disiapkan..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 rounded-lg"
                >
                  {submitting ? 'Menyimpan...' : 'Simpan Pengingat'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
