import React, { useCallback, useEffect, useState } from 'react';
import { Menu, Plus } from 'lucide-react';
import { useJournalStore } from './hooks/useJournalStore';
import {
  AtpItem,
  CalendarCategory,
  CalendarReminder,
  JournalState,
  NavSection,
  ScheduleSlot,
  UserAccount,
} from './types/journal';
import {
  formatIndonesianDate,
  getTodayIsoDate,
  SCHOOL_LOGO_URL,
} from './data/seedData';
import {
  clearAuthToken,
  createCalendarEvent,
  deleteCalendarEvent,
  fetchCalendarEvents,
  fetchCurrentUser,
  fetchPublicOverview,
  fetchUserJournal,
  getAuthToken,
  PublicOverviewResponse,
  setAuthToken,
} from './services/api';
import { Sidebar } from './components/Sidebar';
import { RunningCalendarBar } from './components/RunningCalendarBar';
import { LandingPage } from './components/LandingPage';
import { TodayOverview } from './components/TodayOverview';
import { ScheduleView } from './components/ScheduleView';
import { AttendanceView } from './components/AttendanceView';
import { AtpMaterialsView } from './components/AtpMaterialsView';
import { JournalHistoryView } from './components/JournalHistoryView';
import { SubjectsClassesView } from './components/SubjectsClassesView';
import { CalendarRemindersView } from './components/CalendarRemindersView';
import { UserManagementView } from './components/UserManagementView';
import { TeacherProfileModal } from './components/TeacherProfileModal';

const SECTION_TITLES: Record<NavSection, string> = {
  ringkasan: 'Ringkasan Hari Ini',
  jadwal: 'Jadwal Mengajar',
  presensi: 'Presensi Siswa',
  atp: 'ATP dan Materi',
  riwayat: 'Riwayat Jurnal',
  pelajaran_kelas: 'Pelajaran & Kelas Guru',
  kalender: 'Kalender & Pengingat Harian',
  kelola_user: 'Kelola Akun Guru',
};

const DEFAULT_PUBLIC_OVERVIEW: PublicOverviewResponse = {
  schoolName: 'SMA Negeri 1 Pagerbarang',
  schoolLogoUrl: SCHOOL_LOGO_URL,
  activeTeachers: 3,
  schoolReminders: [],
};

interface AuthenticatedWorkspaceProps {
  user: UserAccount;
  initialJournal: JournalState;
  reminders: CalendarReminder[];
  onCreateReminder: (payload: {
    date: string;
    time?: string;
    title: string;
    description: string;
    scope: 'sekolah' | 'pribadi';
    category: CalendarCategory;
  }) => Promise<void>;
  onDeleteReminder: (id: string) => Promise<void>;
  onLogout: () => void;
}

function AuthenticatedWorkspace({
  user,
  initialJournal,
  reminders,
  onCreateReminder,
  onDeleteReminder,
  onLogout,
}: AuthenticatedWorkspaceProps) {
  const {
    state,
    updateProfile,
    addSubject,
    updateSubject,
    deleteSubject,
    addAtpItem,
    updateAtpItem,
    deleteAtpItem,
    addClass,
    updateClass,
    deleteClass,
    addStudent,
    addStudentsBulk,
    updateStudent,
    deleteStudent,
    addSchedule,
    updateSchedule,
    deleteSchedule,
    upsertAttendanceSession,
    setStudentAttendance,
    deleteAttendanceSession,
    addLessonNote,
    updateLessonNote,
    deleteLessonNote,
    importSubjectsAndClasses,
    importFullState,
    resetToSeed,
    clearAllData,
  } = useJournalStore(user.id, initialJournal);

  const [activeSection, setActiveSection] = useState<NavSection>('ringkasan');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  const [attendanceContext, setAttendanceContext] = useState<{
    classId: string;
    date: string;
    scheduleSlotId?: string;
    subject?: string;
  } | null>(null);

  const [noteDraftContext, setNoteDraftContext] = useState<{
    classId: string;
    date: string;
    scheduleSlotId?: string;
    subject?: string;
    atpId?: string;
    atpCode?: string;
    topic?: string;
    learningObjective?: string;
  } | null>(null);

  const handleOpenAttendanceForSlot = (slot: ScheduleSlot, date: string) => {
    setAttendanceContext({
      classId: slot.classId,
      date,
      scheduleSlotId: slot.id,
      subject: slot.subject,
    });
    setActiveSection('presensi');
  };

  const handleOpenNoteForSlot = (slot: ScheduleSlot, date: string) => {
    setNoteDraftContext({
      classId: slot.classId,
      date,
      scheduleSlotId: slot.id,
      subject: slot.subject,
    });
    setActiveSection('riwayat');
  };

  const handleCreateJournalFromAtp = (atp: AtpItem) => {
    const matchingClass =
      state.classes.find((c) => c.grade === atp.gradeLevel) ?? state.classes[0];
    setNoteDraftContext({
      classId: matchingClass?.id ?? '',
      date: getTodayIsoDate(),
      subject: atp.subjectName,
      atpId: atp.id,
      atpCode: atp.code,
      topic: atp.materials[0] ?? atp.element,
      learningObjective: atp.objective,
    });
    setActiveSection('riwayat');
  };

  const handleQuickCreateNote = () => {
    const firstClass = state.classes[0];
    if (firstClass) {
      setNoteDraftContext({
        classId: firstClass.id,
        date: getTodayIsoDate(),
        subject: state.subjects[0]?.name ?? state.profile.subject,
      });
    }
    setActiveSection('riwayat');
  };

  const todayLabel = formatIndonesianDate(getTodayIsoDate());
  const currentSection: NavSection =
    activeSection === 'kelola_user' && user.role !== 'admin'
      ? 'ringkasan'
      : activeSection;

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      <Sidebar
        activeSection={currentSection}
        onSelectSection={setActiveSection}
        profile={state.profile}
        userRole={user.role}
        username={user.username}
        onOpenProfile={() => setProfileModalOpen(true)}
        onLogout={onLogout}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        <RunningCalendarBar
          reminders={reminders}
          schedules={state.schedules}
          classes={state.classes}
          attendanceSessions={state.attendanceSessions}
          lessonNotes={state.lessonNotes}
          onOpenCalendar={() => setActiveSection('kalender')}
        />

        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between gap-4 sticky top-0 z-30 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Buka menu navigasi"
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="min-w-0 flex items-baseline gap-2 truncate">
              <h1 className="font-display text-base sm:text-lg font-semibold text-slate-900 truncate">
                {SECTION_TITLES[currentSection]}
              </h1>
              <span className="hidden md:inline text-xs text-slate-400" aria-hidden="true">
                /
              </span>
              <span className="hidden md:inline text-xs text-slate-500 truncate">
                {todayLabel}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleQuickCreateNote}
              disabled={state.classes.length === 0}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 disabled:cursor-not-allowed rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700"
            >
              <Plus className="h-3.5 w-3.5" />
              Catat Jurnal
            </button>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-8 py-6 max-w-[1280px] w-full mx-auto print-container">
          {currentSection === 'ringkasan' && (
            <TodayOverview
              classes={state.classes}
              schedules={state.schedules}
              atpItems={state.atpItems}
              attendanceSessions={state.attendanceSessions}
              lessonNotes={state.lessonNotes}
              onOpenAttendanceForSlot={handleOpenAttendanceForSlot}
              onOpenNoteForSlot={handleOpenNoteForSlot}
              onNavigateSchedule={() => setActiveSection('jadwal')}
              onNavigateHistory={() => setActiveSection('riwayat')}
              onNavigateAtp={() => setActiveSection('atp')}
            />
          )}

          {currentSection === 'jadwal' && (
            <ScheduleView
              classes={state.classes}
              subjects={state.subjects}
              schedules={state.schedules}
              defaultSubject={state.profile.subject}
              onAddSchedule={addSchedule}
              onUpdateSchedule={updateSchedule}
              onDeleteSchedule={deleteSchedule}
              onOpenAttendance={handleOpenAttendanceForSlot}
              onOpenNote={handleOpenNoteForSlot}
            />
          )}

          {currentSection === 'presensi' && (
            <AttendanceView
              classes={state.classes}
              schedules={state.schedules}
              attendanceSessions={state.attendanceSessions}
              defaultSubject={state.profile.subject}
              initialContext={attendanceContext}
              onSetStudentAttendance={setStudentAttendance}
              onUpsertSession={upsertAttendanceSession}
              onDeleteSession={deleteAttendanceSession}
            />
          )}

          {currentSection === 'atp' && (
            <AtpMaterialsView
              subjects={state.subjects}
              atpItems={state.atpItems}
              lessonNotes={state.lessonNotes}
              defaultSemester={state.profile.semester}
              onAddAtp={addAtpItem}
              onUpdateAtp={updateAtpItem}
              onDeleteAtp={deleteAtpItem}
              onCreateJournalFromAtp={handleCreateJournalFromAtp}
            />
          )}

          {currentSection === 'riwayat' && (
            <JournalHistoryView
              profile={state.profile}
              classes={state.classes}
              subjects={state.subjects}
              schedules={state.schedules}
              atpItems={state.atpItems}
              attendanceSessions={state.attendanceSessions}
              lessonNotes={state.lessonNotes}
              initialDraftContext={noteDraftContext}
              onConsumeDraftContext={() => setNoteDraftContext(null)}
              onAddNote={addLessonNote}
              onUpdateNote={updateLessonNote}
              onDeleteNote={deleteLessonNote}
            />
          )}

          {currentSection === 'pelajaran_kelas' && (
            <SubjectsClassesView
              subjects={state.subjects}
              classes={state.classes}
              schedules={state.schedules}
              atpItems={state.atpItems}
              onAddSubject={addSubject}
              onUpdateSubject={updateSubject}
              onDeleteSubject={deleteSubject}
              onAddClass={addClass}
              onUpdateClass={updateClass}
              onDeleteClass={deleteClass}
              onAddStudent={addStudent}
              onAddStudentsBulk={addStudentsBulk}
              onUpdateStudent={updateStudent}
              onDeleteStudent={deleteStudent}
              onImportExcelBulk={importSubjectsAndClasses}
            />
          )}

          {currentSection === 'kalender' && (
            <CalendarRemindersView
              userRole={user.role}
              userId={user.id}
              reminders={reminders}
              schedules={state.schedules}
              classes={state.classes}
              onCreateReminder={onCreateReminder}
              onDeleteReminder={onDeleteReminder}
            />
          )}

          {currentSection === 'kelola_user' && user.role === 'admin' && (
            <UserManagementView currentUserId={user.id} />
          )}
        </main>
      </div>

      {profileModalOpen && (
        <TeacherProfileModal
          profile={state.profile}
          username={user.username}
          fullState={state}
          onSaveProfile={updateProfile}
          onImportState={importFullState}
          onResetToSeed={resetToSeed}
          onClearAll={clearAllData}
          onClose={() => setProfileModalOpen(false)}
        />
      )}
    </div>
  );
}

export default function App() {
  const [authStatus, setAuthStatus] = useState<'checking' | 'guest' | 'authenticated'>(
    'checking'
  );
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [initialJournal, setInitialJournal] = useState<JournalState | null>(null);
  const [reminders, setReminders] = useState<CalendarReminder[]>([]);
  const [publicOverview, setPublicOverview] =
    useState<PublicOverviewResponse>(DEFAULT_PUBLIC_OVERVIEW);

  const loadGuestOverview = useCallback(async () => {
    try {
      const overview = await fetchPublicOverview();
      setPublicOverview(overview);
    } catch {
      setPublicOverview(DEFAULT_PUBLIC_OVERVIEW);
    }
  }, []);

  const loadAuthenticatedWorkspace = useCallback(async () => {
    const [meRes, journalRes, calRes] = await Promise.all([
      fetchCurrentUser(),
      fetchUserJournal(),
      fetchCalendarEvents(),
    ]);
    setCurrentUser(meRes.user);
    setInitialJournal(journalRes.journal);
    setReminders(calRes.events);
    setAuthStatus('authenticated');
  }, []);

  useEffect(() => {
    let active = true;
    const init = async () => {
      const token = getAuthToken();
      if (!token) {
        await loadGuestOverview();
        if (active) setAuthStatus('guest');
        return;
      }
      try {
        await loadAuthenticatedWorkspace();
      } catch {
        clearAuthToken();
        await loadGuestOverview();
        if (active) {
          setCurrentUser(null);
          setInitialJournal(null);
          setAuthStatus('guest');
        }
      }
    };
    void init();
    return () => {
      active = false;
    };
  }, [loadAuthenticatedWorkspace, loadGuestOverview]);

  const handleLoginSuccess = async (token: string, user: UserAccount) => {
    setAuthToken(token);
    setCurrentUser(user);
    setAuthStatus('checking');
    try {
      const [journalRes, calRes] = await Promise.all([
        fetchUserJournal(),
        fetchCalendarEvents(),
      ]);
      setInitialJournal(journalRes.journal);
      setReminders(calRes.events);
      setAuthStatus('authenticated');
    } catch {
      clearAuthToken();
      setCurrentUser(null);
      setInitialJournal(null);
      await loadGuestOverview();
      setAuthStatus('guest');
    }
  };

  const handleLogout = async () => {
    clearAuthToken();
    setCurrentUser(null);
    setInitialJournal(null);
    setReminders([]);
    setAuthStatus('guest');
    await loadGuestOverview();
  };

  const handleCreateReminder = async (payload: {
    date: string;
    time?: string;
    title: string;
    description: string;
    scope: 'sekolah' | 'pribadi';
    category: CalendarCategory;
  }) => {
    const res = await createCalendarEvent(payload);
    setReminders((prev) =>
      [...prev, res.event].sort(
        (a, b) =>
          a.date.localeCompare(b.date) || (a.time ?? '').localeCompare(b.time ?? '')
      )
    );
  };

  const handleDeleteReminder = async (id: string) => {
    await deleteCalendarEvent(id);
    setReminders((prev) => prev.filter((item) => item.id !== id));
  };

  if (authStatus === 'checking') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-4 px-4">
        <img
          src={SCHOOL_LOGO_URL}
          alt="Logo SMA Negeri 1 Pagerbarang"
          className="h-14 w-14 object-contain"
        />
        <div className="text-center">
          <p className="font-display text-base font-semibold text-slate-900">
            SIGAP : Sistem Informasi Guru dan Administrasi SMA Negeri 1 Pagerbarang
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Memuat ruang kerja dan kalender mengajar...
          </p>
        </div>
      </div>
    );
  }

  if (authStatus === 'guest' || !currentUser || !initialJournal) {
    return (
      <LandingPage
        schoolName={publicOverview.schoolName}
        schoolLogoUrl={publicOverview.schoolLogoUrl}
        activeTeachers={publicOverview.activeTeachers}
        schoolReminders={publicOverview.schoolReminders}
        onLoginSuccess={handleLoginSuccess}
      />
    );
  }

  return (
    <AuthenticatedWorkspace
      key={currentUser.id}
      user={currentUser}
      initialJournal={initialJournal}
      reminders={reminders}
      onCreateReminder={handleCreateReminder}
      onDeleteReminder={handleDeleteReminder}
      onLogout={handleLogout}
    />
  );
}
