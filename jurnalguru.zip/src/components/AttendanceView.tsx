import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCheck,
  Download,
  Search,
  Trash2,
} from 'lucide-react';
import {
  AttendanceSession,
  AttendanceStatus,
  Classroom,
  ScheduleSlot,
} from '../types/journal';
import {
  formatIndonesianDate,
  formatShortDate,
  getDayOfWeekFromIso,
  getTodayIsoDate,
} from '../data/seedData';
import { downloadCsv } from '../utils/exportCsv';

interface AttendanceViewProps {
  classes: Classroom[];
  schedules: ScheduleSlot[];
  attendanceSessions: AttendanceSession[];
  defaultSubject: string;
  initialContext?: {
    classId: string;
    date: string;
    scheduleSlotId?: string;
    subject?: string;
  } | null;
  onSetStudentAttendance: (params: {
    date: string;
    classId: string;
    subject: string;
    scheduleSlotId?: string;
    studentId: string;
    status: AttendanceStatus;
    note?: string;
    allStudentIds: string[];
  }) => void;
  onUpsertSession: (payload: {
    date: string;
    classId: string;
    subject: string;
    scheduleSlotId?: string;
    records: AttendanceSession['records'];
  }) => void;
  onDeleteSession: (id: string) => void;
}

const STATUS_OPTIONS: {
  value: AttendanceStatus;
  label: string;
  activeClass: string;
}[] = [
  {
    value: 'H',
    label: 'Hadir',
    activeClass: 'bg-emerald-600 text-white border-emerald-600',
  },
  {
    value: 'I',
    label: 'Izin',
    activeClass: 'bg-sky-600 text-white border-sky-600',
  },
  {
    value: 'S',
    label: 'Sakit',
    activeClass: 'bg-amber-600 text-white border-amber-600',
  },
  {
    value: 'A',
    label: 'Alpa',
    activeClass: 'bg-red-600 text-white border-red-600',
  },
];

export function AttendanceView({
  classes,
  schedules,
  attendanceSessions,
  defaultSubject,
  initialContext,
  onSetStudentAttendance,
  onUpsertSession,
  onDeleteSession,
}: AttendanceViewProps) {
  const [mode, setMode] = useState<'input' | 'rekap'>('input');
  const [selectedDate, setSelectedDate] = useState<string>(
    initialContext?.date || getTodayIsoDate()
  );
  const [selectedClassId, setSelectedClassId] = useState<string>(
    initialContext?.classId || classes[0]?.id || ''
  );
  const [selectedSlotId, setSelectedSlotId] = useState<string>(
    initialContext?.scheduleSlotId || ''
  );
  const [customSubject, setCustomSubject] = useState<string>(
    initialContext?.subject || defaultSubject
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDeleteSessionId, setConfirmDeleteSessionId] = useState<string | null>(
    null
  );

  useEffect(() => {
    if (initialContext) {
      setSelectedDate(initialContext.date);
      setSelectedClassId(initialContext.classId);
      setSelectedSlotId(initialContext.scheduleSlotId || '');
      if (initialContext.subject) {
        setCustomSubject(initialContext.subject);
      }
      setMode('input');
    }
  }, [initialContext]);

  useEffect(() => {
    if (!classes.some((c) => c.id === selectedClassId)) {
      setSelectedClassId(classes[0]?.id ?? '');
    }
  }, [classes, selectedClassId]);

  const activeClass = useMemo(
    () => classes.find((c) => c.id === selectedClassId),
    [classes, selectedClassId]
  );

  const dayOfSelectedDate = useMemo(
    () => getDayOfWeekFromIso(selectedDate),
    [selectedDate]
  );

  const matchingDaySlots = useMemo(
    () =>
      schedules.filter(
        (s) => s.classId === selectedClassId && s.day === dayOfSelectedDate
      ),
    [schedules, selectedClassId, dayOfSelectedDate]
  );

  useEffect(() => {
    if (selectedSlotId) {
      const slot = schedules.find((s) => s.id === selectedSlotId);
      if (slot && slot.classId === selectedClassId) {
        setCustomSubject(slot.subject);
        return;
      }
    }
    if (matchingDaySlots.length > 0 && !initialContext?.subject) {
      setSelectedSlotId(matchingDaySlots[0].id);
      setCustomSubject(matchingDaySlots[0].subject);
    } else if (!customSubject) {
      setCustomSubject(defaultSubject);
    }
  }, [selectedClassId, selectedDate]);

  const activeSession = useMemo(() => {
    return attendanceSessions.find(
      (s) =>
        s.date === selectedDate &&
        s.classId === selectedClassId &&
        (selectedSlotId ? s.scheduleSlotId === selectedSlotId || !s.scheduleSlotId : true)
    );
  }, [attendanceSessions, selectedDate, selectedClassId, selectedSlotId]);

  const students = activeClass?.students ?? [];
  const allStudentIds = useMemo(() => students.map((s) => s.id), [students]);

  const filteredStudents = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return students;
    return students.filter(
      (s) =>
        s.name.toLowerCase().includes(q) || s.nis.toLowerCase().includes(q)
    );
  }, [students, searchQuery]);

  const summary = useMemo(() => {
    const counts = { H: 0, I: 0, S: 0, A: 0, unrecorded: 0 };
    for (const st of students) {
      const status = activeSession?.records[st.id]?.status;
      if (!status) {
        counts.unrecorded += 1;
      } else {
        counts[status] += 1;
      }
    }
    const recordedTotal = students.length - counts.unrecorded;
    const pct =
      recordedTotal > 0 ? Math.round((counts.H / recordedTotal) * 100) : 0;
    return { ...counts, total: students.length, recordedTotal, pct };
  }, [students, activeSession]);

  const handleMarkAllPresent = () => {
    if (!activeClass || students.length === 0) return;
    const records: AttendanceSession['records'] = {};
    for (const st of students) {
      const existing = activeSession?.records[st.id];
      records[st.id] = {
        studentId: st.id,
        status: 'H',
        note: existing?.note,
      };
    }
    onUpsertSession({
      date: selectedDate,
      classId: activeClass.id,
      subject: customSubject || defaultSubject,
      scheduleSlotId: selectedSlotId || undefined,
      records,
    });
  };

  const handleExportSessionCsv = () => {
    if (!activeClass) return;
    const headers = ['No', 'NIS', 'Nama Siswa', 'L/P', 'Status', 'Keterangan'];
    const labelMap: Record<AttendanceStatus, string> = {
      H: 'Hadir',
      I: 'Izin',
      S: 'Sakit',
      A: 'Alpa',
    };
    const rows = students.map((st, idx) => {
      const entry = activeSession?.records[st.id];
      return [
        idx + 1,
        st.nis,
        st.name,
        st.gender,
        entry ? labelMap[entry.status] : 'Belum Diisi',
        entry?.note ?? '',
      ];
    });
    downloadCsv(
      `presensi-${activeClass.name}-${selectedDate}.csv`,
      headers,
      rows
    );
  };

  const classSessions = useMemo(() => {
    return attendanceSessions
      .filter((s) => s.classId === selectedClassId)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [attendanceSessions, selectedClassId]);

  const recapRows = useMemo(() => {
    return students.map((st) => {
      let H = 0;
      let I = 0;
      let S = 0;
      let A = 0;
      for (const sess of classSessions) {
        const rec = sess.records[st.id];
        if (!rec) continue;
        if (rec.status === 'H') H += 1;
        else if (rec.status === 'I') I += 1;
        else if (rec.status === 'S') S += 1;
        else if (rec.status === 'A') A += 1;
      }
      const total = H + I + S + A;
      const pct = total > 0 ? Math.round((H / total) * 100) : 0;
      return { student: st, H, I, S, A, total, pct };
    });
  }, [students, classSessions]);

  const handleExportRecapCsv = () => {
    if (!activeClass) return;
    const headers = [
      'No',
      'NIS',
      'Nama Siswa',
      'L/P',
      'Hadir',
      'Izin',
      'Sakit',
      'Alpa',
      'Total Pertemuan',
      'Persentase Hadir (%)',
    ];
    const rows = recapRows.map((r, idx) => [
      idx + 1,
      r.student.nis,
      r.student.name,
      r.student.gender,
      r.H,
      r.I,
      r.S,
      r.A,
      r.total,
      `${r.pct}%`,
    ]);
    downloadCsv(`rekap-presensi-${activeClass.name}.csv`, headers, rows);
  };

  if (classes.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
        <p className="text-sm font-medium text-slate-900">
          Belum ada kelas dan daftar siswa.
        </p>
        <p className="text-xs text-slate-500 mt-1">
          Tambahkan kelas dan siswa pada menu Kelas & Siswa untuk mulai mencatat presensi.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
            <button
              type="button"
              onClick={() => setMode('input')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                mode === 'input'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Input Presensi
            </button>
            <button
              type="button"
              onClick={() => setMode('rekap')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                mode === 'rekap'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Rekap Kehadiran ({classSessions.length} sesi)
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div>
              <label htmlFor="att-class" className="sr-only">
                Pilih Kelas
              </label>
              <select
                id="att-class"
                value={selectedClassId}
                onChange={(e) => {
                  setSelectedClassId(e.target.value);
                  setSelectedSlotId('');
                }}
                className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:border-blue-600"
              >
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    Kelas {c.name} ({c.students.length} siswa)
                  </option>
                ))}
              </select>
            </div>

            {mode === 'input' && (
              <>
                <div>
                  <label htmlFor="att-date" className="sr-only">
                    Tanggal Pertemuan
                  </label>
                  <input
                    id="att-date"
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="px-3 py-2 text-xs font-mono border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:border-blue-600"
                  />
                </div>

                {matchingDaySlots.length > 0 ? (
                  <select
                    aria-label="Pilih Slot Jadwal"
                    value={selectedSlotId}
                    onChange={(e) => {
                      const id = e.target.value;
                      setSelectedSlotId(id);
                      const slot = matchingDaySlots.find((s) => s.id === id);
                      if (slot) setCustomSubject(slot.subject);
                    }}
                    className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:border-blue-600"
                  >
                    {matchingDaySlots.map((slot) => (
                      <option key={slot.id} value={slot.id}>
                        {slot.startTime}–{slot.endTime} · {slot.subject}
                      </option>
                    ))}
                    <option value="">Sesi Lain / Pengganti</option>
                  </select>
                ) : (
                  <input
                    type="text"
                    aria-label="Mata pelajaran"
                    value={customSubject}
                    onChange={(e) => setCustomSubject(e.target.value)}
                    placeholder="Mata pelajaran"
                    className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:border-blue-600"
                  />
                )}
              </>
            )}
          </div>
        </div>

        {mode === 'input' && (
          <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs text-slate-600">
              <span className="font-medium text-slate-900">
                {formatIndonesianDate(selectedDate)}
              </span>
              <span className="mx-1.5 text-slate-300" aria-hidden="true">
                ·
              </span>
              <span>{customSubject}</span>
              {activeSession && (
                <>
                  <span className="mx-1.5 text-slate-300" aria-hidden="true">
                    ·
                  </span>
                  <span className="text-emerald-700 font-medium">
                    Tersimpan (diperbarui{' '}
                    {new Date(activeSession.updatedAt).toLocaleTimeString('id-ID', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                    )
                  </span>
                </>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleMarkAllPresent}
                disabled={students.length === 0}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 rounded-lg whitespace-nowrap shrink-0"
              >
                <CheckCheck className="h-3.5 w-3.5" />
                Tandai Semua Hadir
              </button>
              <button
                type="button"
                onClick={handleExportSessionCsv}
                disabled={students.length === 0}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
              >
                <Download className="h-3.5 w-3.5" />
                Unduh CSV
              </button>
            </div>
          </div>
        )}
      </div>

      {mode === 'input' ? (
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 items-start">
          <div className="xl:col-span-3 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs tabular-nums">
                <span className="text-slate-600">
                  Total: <strong className="text-slate-900">{summary.total}</strong>
                </span>
                <span className="text-emerald-700">
                  Hadir: <strong>{summary.H}</strong>
                </span>
                <span className="text-sky-700">
                  Izin: <strong>{summary.I}</strong>
                </span>
                <span className="text-amber-700">
                  Sakit: <strong>{summary.S}</strong>
                </span>
                <span className="text-red-700">
                  Alpa: <strong>{summary.A}</strong>
                </span>
                {summary.unrecorded > 0 && (
                  <span className="text-slate-500">
                    Belum diisi: <strong>{summary.unrecorded}</strong>
                  </span>
                )}
              </div>

              <div className="relative w-full sm:w-56">
                <Search className="h-3.5 w-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari nama / NIS..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>
            </div>

            {students.length === 0 ? (
              <div className="px-6 py-12 text-center">
                <p className="text-sm font-medium text-slate-900">
                  Belum ada siswa di kelas {activeClass?.name}.
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Tambahkan daftar siswa melalui menu Kelas & Siswa terlebih dahulu.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                      <th className="py-2.5 pl-5 pr-2 w-10">No</th>
                      <th className="py-2.5 px-2 w-24">NIS</th>
                      <th className="py-2.5 px-2 min-w-[180px]">Nama Siswa</th>
                      <th className="py-2.5 px-2 w-10 text-center">L/P</th>
                      <th className="py-2.5 px-2 min-w-[230px]">Status Kehadiran</th>
                      <th className="py-2.5 pl-2 pr-5 min-w-[160px]">Catatan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-xs">
                    {filteredStudents.map((st, idx) => {
                      const rec = activeSession?.records[st.id];
                      return (
                        <tr key={st.id} className="hover:bg-slate-50/70">
                          <td className="py-2.5 pl-5 pr-2 text-slate-500 tabular-nums">
                            {idx + 1}
                          </td>
                          <td className="py-2.5 px-2 font-mono text-slate-600 tabular-nums">
                            {st.nis}
                          </td>
                          <td className="py-2.5 px-2 font-medium text-slate-900">
                            {st.name}
                          </td>
                          <td className="py-2.5 px-2 text-center text-slate-500">
                            {st.gender}
                          </td>
                          <td className="py-2.5 px-2">
                            <div className="inline-flex items-center gap-1">
                              {STATUS_OPTIONS.map((opt) => {
                                const isActive = rec?.status === opt.value;
                                return (
                                  <button
                                    key={opt.value}
                                    type="button"
                                    onClick={() =>
                                      onSetStudentAttendance({
                                        date: selectedDate,
                                        classId: selectedClassId,
                                        subject: customSubject || defaultSubject,
                                        scheduleSlotId: selectedSlotId || undefined,
                                        studentId: st.id,
                                        status: opt.value,
                                        allStudentIds,
                                      })
                                    }
                                    className={`px-2.5 py-1 text-[11px] font-medium rounded border transition-colors whitespace-nowrap shrink-0 ${
                                      isActive
                                        ? opt.activeClass
                                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                                    }`}
                                  >
                                    {opt.label}
                                  </button>
                                );
                              })}
                            </div>
                          </td>
                          <td className="py-2.5 pl-2 pr-5">
                            <input
                              type="text"
                              value={rec?.note ?? ''}
                              onChange={(e) =>
                                onSetStudentAttendance({
                                  date: selectedDate,
                                  classId: selectedClassId,
                                  subject: customSubject || defaultSubject,
                                  scheduleSlotId: selectedSlotId || undefined,
                                  studentId: st.id,
                                  status: rec?.status ?? 'H',
                                  note: e.target.value,
                                  allStudentIds,
                                })
                              }
                              placeholder="Keterangan..."
                              className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded bg-white text-slate-700 focus:outline-none focus:border-blue-600"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-200">
              <h3 className="font-display text-sm font-semibold text-slate-900">
                Riwayat Presensi {activeClass?.name}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Klik tanggal untuk melihat atau mengubah
              </p>
            </div>
            {classSessions.length === 0 ? (
              <div className="px-5 py-8 text-center text-xs text-slate-400">
                Belum ada riwayat presensi untuk kelas ini.
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {classSessions.map((sess) => {
                  const isCurrent =
                    sess.date === selectedDate &&
                    (!selectedSlotId ||
                      !sess.scheduleSlotId ||
                      sess.scheduleSlotId === selectedSlotId);
                  const hCount = Object.values(sess.records).filter(
                    (r) => r.status === 'H'
                  ).length;
                  const totalCount = Object.keys(sess.records).length;

                  return (
                    <div
                      key={sess.id}
                      className={`px-5 py-3 flex items-center justify-between gap-2 ${
                        isCurrent ? 'bg-blue-50/70' : 'hover:bg-slate-50'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedDate(sess.date);
                          setSelectedSlotId(sess.scheduleSlotId || '');
                          setCustomSubject(sess.subject);
                        }}
                        className="text-left min-w-0 flex-1"
                      >
                        <p className="text-xs font-semibold text-slate-900">
                          {formatShortDate(sess.date)}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate mt-0.5">
                          {sess.subject} ·{' '}
                          <span className="tabular-nums">
                            {hCount}/{totalCount} hadir
                          </span>
                        </p>
                      </button>

                      {confirmDeleteSessionId === sess.id ? (
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteSessionId(null)}
                            className="px-2 py-1 text-[11px] text-slate-600"
                          >
                            Batal
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              onDeleteSession(sess.id);
                              setConfirmDeleteSessionId(null);
                            }}
                            className="px-2 py-1 text-[11px] text-white bg-red-600 rounded"
                          >
                            Hapus
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteSessionId(sess.id)}
                          aria-label="Hapus sesi presensi"
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-display text-sm font-semibold text-slate-900">
                Rekapitulasi Kehadiran — Kelas {activeClass?.name}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                Dihitung dari {classSessions.length} sesi presensi yang tercatat
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportRecapCsv}
              disabled={students.length === 0}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0 self-start sm:self-auto"
            >
              <Download className="h-3.5 w-3.5" />
              Unduh Rekap CSV
            </button>
          </div>

          {students.length === 0 ? (
            <div className="px-6 py-12 text-center text-xs text-slate-500">
              Belum ada siswa di kelas ini.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                    <th className="py-2.5 pl-5 pr-2 w-10">No</th>
                    <th className="py-2.5 px-2 w-24">NIS</th>
                    <th className="py-2.5 px-2 min-w-[200px]">Nama Siswa</th>
                    <th className="py-2.5 px-3 text-right">Hadir</th>
                    <th className="py-2.5 px-3 text-right">Izin</th>
                    <th className="py-2.5 px-3 text-right">Sakit</th>
                    <th className="py-2.5 px-3 text-right">Alpa</th>
                    <th className="py-2.5 px-3 text-right">Sesi</th>
                    <th className="py-2.5 pl-3 pr-5 text-right">% Hadir</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs tabular-nums">
                  {recapRows.map((row, idx) => (
                    <tr key={row.student.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 pl-5 pr-2 text-slate-500">{idx + 1}</td>
                      <td className="py-2.5 px-2 font-mono text-slate-600">
                        {row.student.nis}
                      </td>
                      <td className="py-2.5 px-2 font-medium text-slate-900">
                        {row.student.name}
                      </td>
                      <td className="py-2.5 px-3 text-right font-medium text-emerald-700">
                        {row.H}
                      </td>
                      <td className="py-2.5 px-3 text-right text-sky-700">{row.I}</td>
                      <td className="py-2.5 px-3 text-right text-amber-700">{row.S}</td>
                      <td className="py-2.5 px-3 text-right font-medium text-red-700">
                        {row.A}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-600">
                        {row.total}
                      </td>
                      <td className="py-2.5 pl-3 pr-5 text-right font-semibold text-slate-900">
                        {row.total > 0 ? `${row.pct}%` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
