import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express, { type Request, type Response, type NextFunction } from 'express';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const DB_DIR = path.resolve(__dirname, 'data');
const DB_PATH = path.resolve(DB_DIR, 'jurnalguru-db.json');
const SCHOOL_NAME = 'SMA Negeri 1 Pagerbarang';
const SCHOOL_LOGO_URL =
  '/assets/aistudio/1622767670852-Logo__PNG-1080p__-_SMAN1PGB_5dbdc145.png';
const TEACHER_AVATAR_URL =
  '/src/assets/images/avatar_teacher_profile_1794839809299.jpg';

type UserRole = 'admin' | 'guru';
type CalendarCategory = 'Akademik' | 'Rapat' | 'Ujian' | 'Peringatan' | 'Pribadi';

interface StoredUser {
  id: string;
  username: string;
  passwordHash: string;
  role: UserRole;
  name: string;
  nip: string;
  subject: string;
  active: boolean;
  createdAt: string;
}

interface CalendarReminderRecord {
  id: string;
  date: string;
  time?: string;
  title: string;
  description: string;
  scope: 'sekolah' | 'pribadi';
  category: CalendarCategory;
  ownerUserId: string;
  ownerName: string;
  createdAt: string;
}

interface DatabaseSchema {
  sessionSecret: string;
  users: StoredUser[];
  journals: Record<string, unknown>;
  calendarEvents: CalendarReminderRecord[];
}

interface SessionPayload {
  userId: string;
  username: string;
  role: UserRole;
  exp: number;
}

interface AuthenticatedRequest extends Request {
  authUser?: StoredUser;
}

function getTodayIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function getOffsetIso(offsetDays: number): string {
  const dt = new Date();
  dt.setDate(dt.getDate() + offsetDays);
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, '0');
  const d = String(dt.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derivedBuf.length) return false;
  return crypto.timingSafeEqual(keyBuf, derivedBuf);
}

function signToken(payload: SessionPayload, secret: string): string {
  const headerB64 = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString(
    'base64url'
  );
  const payloadB64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto
    .createHmac('sha256', secret)
    .update(`${headerB64}.${payloadB64}`)
    .digest('base64url');
  return `${headerB64}.${payloadB64}.${signature}`;
}

function verifyToken(token: string, secret: string): SessionPayload | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, signature] = parts;
  const expectedSig = crypto
    .createHmac('sha256', secret)
    .update(`${headerB64}.${payloadB64}`)
    .digest('base64url');
  const sigBuf = Buffer.from(signature);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(
      Buffer.from(payloadB64, 'base64url').toString('utf8')
    ) as SessionPayload;
    if (!parsed.userId || Date.now() > parsed.exp) return null;
    return parsed;
  } catch {
    return null;
  }
}

function buildStarterJournalForUser(user: StoredUser): Record<string, unknown> {
  return {
    profile: {
      name: user.name,
      nip: user.nip,
      subject: user.subject,
      school: SCHOOL_NAME,
      schoolLogoUrl: SCHOOL_LOGO_URL,
      academicYear: '2026/2027',
      semester: 'Ganjil',
      avatarUrl: TEACHER_AVATAR_URL,
    },
    subjects: [
      {
        id: `subj-${user.id}-1`,
        code: user.subject.slice(0, 3).toUpperCase() + '-1',
        name: user.subject,
        gradeLevel: 'X / XI / XII',
        kktp: 75,
        weeklyHours: 4,
        description: `Mata pelajaran ${user.subject} yang diampu oleh ${user.name}.`,
      },
    ],
    atpItems: [],
    classes: [],
    schedules: [],
    attendanceSessions: [],
    lessonNotes: [],
  };
}

function buildRatnaJournal(user: StoredUser): Record<string, unknown> {
  const today = getTodayIso();
  const yesterday3 = getOffsetIso(-3);
  const yesterday4 = getOffsetIso(-4);
  const lastWeek = getOffsetIso(-7);

  return {
    profile: {
      name: user.name,
      nip: user.nip,
      subject: user.subject,
      school: SCHOOL_NAME,
      schoolLogoUrl: SCHOOL_LOGO_URL,
      academicYear: '2026/2027',
      semester: 'Ganjil',
      avatarUrl: TEACHER_AVATAR_URL,
    },
    subjects: [
      {
        id: 'subj-mtk-wajib',
        code: 'MTK-W',
        name: 'Matematika Wajib',
        gradeLevel: 'X / XI / XII',
        kktp: 75,
        weeklyHours: 4,
        description:
          'Capaian pembelajaran matematika umum mencakup aljabar, sistem pertidaksamaan, fungsi, dan statistika.',
      },
      {
        id: 'subj-mtk-lanjut',
        code: 'MTK-TL',
        name: 'Matematika Tingkat Lanjut',
        gradeLevel: 'XI (Fase F)',
        kktp: 78,
        weeklyHours: 4,
        description:
          'Pendalaman aljabar polinomial, matriks, transformasi geometri, dan fungsi kompleks.',
      },
      {
        id: 'subj-mtk-peminatan',
        code: 'MTK-P',
        name: 'Matematika Peminatan',
        gradeLevel: 'XII (Fase F+)',
        kktp: 78,
        weeklyHours: 4,
        description:
          'Limit fungsi trigonometri, turunan fungsi trigonometri, serta aplikasinya pada kurva dan laju perubahan.',
      },
    ],
    atpItems: [
      {
        id: 'atp-1',
        subjectId: 'subj-mtk-wajib',
        subjectName: 'Matematika Wajib',
        gradeLevel: 'X',
        semester: 'Ganjil',
        code: 'TP.10.1',
        element: 'Bilangan & Aljabar',
        objective:
          'Peserta didik mampu menggeneralisasi sifat-sifat eksponen dan logaritma serta menerapkannya dalam pemodelan pertumbuhan.',
        materials: [
          'Sifat-sifat bilangan berpangkat (eksponen)',
          'Fungsi eksponen dan grafik pertumbuhan',
          'Konsep dasar dan sifat logaritma',
        ],
        allocatedHours: 8,
        status: 'Tercapai',
        order: 1,
      },
      {
        id: 'atp-2',
        subjectId: 'subj-mtk-wajib',
        subjectName: 'Matematika Wajib',
        gradeLevel: 'X',
        semester: 'Ganjil',
        code: 'TP.10.2',
        element: 'Aljabar dan Fungsi',
        objective:
          'Peserta didik mampu menyelesaikan masalah kontekstual yang berkaitan dengan sistem persamaan dan pertidaksamaan linear dua variabel.',
        materials: [
          'Sistem Persamaan Linear Tiga Variabel (SPLTV)',
          'Sistem Pertidaksamaan Linear Dua Variabel (SPtLDV)',
          'Penentuan daerah himpunan penyelesaian & model optimum',
        ],
        allocatedHours: 10,
        status: 'Sedang Berjalan',
        order: 2,
      },
      {
        id: 'atp-3',
        subjectId: 'subj-mtk-lanjut',
        subjectName: 'Matematika Tingkat Lanjut',
        gradeLevel: 'XI',
        semester: 'Ganjil',
        code: 'TP.11.1',
        element: 'Aljabar dan Fungsi',
        objective:
          'Peserta didik mampu melakukan operasi aritmetika pada polinomial serta menggunakan Teorema Sisa dan Teorema Faktor untuk pemfaktoran.',
        materials: [
          'Pengertian, derajat, dan operasi polinomial',
          'Pembagian bersusun dan skema Horner',
          'Teorema Sisa dan Teorema Faktor',
        ],
        allocatedHours: 12,
        status: 'Tercapai',
        order: 1,
      },
    ],
    classes: [
      {
        id: 'cls-xa',
        name: 'X-A',
        grade: 'X',
        major: 'Fase E (Umum)',
        room: 'Ruang 104',
        homeroomTeacher: 'Ratna Dewi, S.Pd.',
        students: [
          { id: 'st-xa-1', nis: '261001', name: 'Aditya Pratama Wijaya', gender: 'L' },
          { id: 'st-xa-2', nis: '261002', name: 'Aisyah Putri Ramadhani', gender: 'P' },
          { id: 'st-xa-3', nis: '261003', name: 'Bagas Kurniawan', gender: 'L' },
          { id: 'st-xa-4', nis: '261004', name: 'Clarissa Natania', gender: 'P' },
          { id: 'st-xa-5', nis: '261005', name: 'Dimas Arya Saputra', gender: 'L' },
          { id: 'st-xa-6', nis: '261006', name: 'Farah Salsabila', gender: 'P' },
          { id: 'st-xa-7', nis: '261007', name: 'Gilang Mahendra', gender: 'L' },
          { id: 'st-xa-8', nis: '261008', name: 'Hana Permata Sari', gender: 'P' },
        ],
      },
      {
        id: 'cls-xi1',
        name: 'XI-IPA-1',
        grade: 'XI',
        major: 'MIPA',
        room: 'Ruang 203',
        homeroomTeacher: 'Drs. Hendra Wijaya',
        students: [
          { id: 'st-xi-1', nis: '251011', name: 'Alvin Hendrawan', gender: 'L' },
          { id: 'st-xi-2', nis: '251012', name: 'Bella Puspita Dewi', gender: 'P' },
          { id: 'st-xi-3', nis: '251013', name: 'Candra Setiawan', gender: 'L' },
          { id: 'st-xi-4', nis: '251014', name: 'Dina Safitri', gender: 'P' },
          { id: 'st-xi-5', nis: '251015', name: 'Evan Ramadhan', gender: 'L' },
          { id: 'st-xi-6', nis: '251016', name: 'Firda Aulia Rahma', gender: 'P' },
        ],
      },
      {
        id: 'cls-xii2',
        name: 'XII-IPA-2',
        grade: 'XII',
        major: 'MIPA',
        room: 'Ruang 301',
        homeroomTeacher: 'Siti Aminah, M.Pd.',
        students: [
          { id: 'st-xii-1', nis: '241021', name: 'Arif Rahman Hakim', gender: 'L' },
          { id: 'st-xii-2', nis: '241022', name: 'Bunga Citra Lestari', gender: 'P' },
          { id: 'st-xii-3', nis: '241023', name: 'Daffa Alfarizi', gender: 'L' },
          { id: 'st-xii-4', nis: '241024', name: 'Eka Putri Maharani', gender: 'P' },
          { id: 'st-xii-5', nis: '241025', name: 'Fajar Sidik Purnomo', gender: 'L' },
          { id: 'st-xii-6', nis: '241026', name: 'Gita Anggraini', gender: 'P' },
        ],
      },
    ],
    schedules: [
      {
        id: 'sch-1',
        day: 'Senin',
        startTime: '07:15',
        endTime: '08:45',
        classId: 'cls-xa',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 104',
        lessonHours: 2,
      },
      {
        id: 'sch-2',
        day: 'Selasa',
        startTime: '07:00',
        endTime: '08:30',
        classId: 'cls-xi1',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 203',
        lessonHours: 2,
      },
      {
        id: 'sch-3',
        day: 'Rabu',
        startTime: '07:00',
        endTime: '08:30',
        classId: 'cls-xa',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 104',
        lessonHours: 2,
      },
      {
        id: 'sch-4',
        day: 'Rabu',
        startTime: '09:45',
        endTime: '11:15',
        classId: 'cls-xii2',
        subjectId: 'subj-mtk-peminatan',
        subject: 'Matematika Peminatan',
        room: 'Ruang 301',
        lessonHours: 2,
      },
      {
        id: 'sch-5',
        day: 'Kamis',
        startTime: '08:30',
        endTime: '10:00',
        classId: 'cls-xi1',
        subjectId: 'subj-mtk-lanjut',
        subject: 'Matematika Tingkat Lanjut',
        room: 'Ruang 203',
        lessonHours: 2,
      },
      {
        id: 'sch-6',
        day: 'Jumat',
        startTime: '07:30',
        endTime: '09:00',
        classId: 'cls-xa',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 104',
        lessonHours: 2,
      },
    ],
    attendanceSessions: [
      {
        id: `att-${today}-sch-3`,
        date: today,
        scheduleSlotId: 'sch-3',
        classId: 'cls-xa',
        subject: 'Matematika Wajib',
        updatedAt: `${today}T07:25:00`,
        records: {
          'st-xa-1': { studentId: 'st-xa-1', status: 'H' },
          'st-xa-2': { studentId: 'st-xa-2', status: 'H' },
          'st-xa-3': { studentId: 'st-xa-3', status: 'S', note: 'Surat izin orang tua' },
          'st-xa-4': { studentId: 'st-xa-4', status: 'H' },
          'st-xa-5': { studentId: 'st-xa-5', status: 'H' },
          'st-xa-6': { studentId: 'st-xa-6', status: 'H' },
          'st-xa-7': { studentId: 'st-xa-7', status: 'I', note: 'Lomba OSN kota' },
          'st-xa-8': { studentId: 'st-xa-8', status: 'H' },
        },
      },
      {
        id: `att-${lastWeek}-sch-1`,
        date: lastWeek,
        scheduleSlotId: 'sch-1',
        classId: 'cls-xa',
        subject: 'Matematika Wajib',
        updatedAt: `${lastWeek}T07:20:00`,
        records: {
          'st-xa-1': { studentId: 'st-xa-1', status: 'H' },
          'st-xa-2': { studentId: 'st-xa-2', status: 'H' },
          'st-xa-3': { studentId: 'st-xa-3', status: 'H' },
          'st-xa-4': { studentId: 'st-xa-4', status: 'H' },
          'st-xa-5': { studentId: 'st-xa-5', status: 'A', note: 'Tanpa keterangan' },
          'st-xa-6': { studentId: 'st-xa-6', status: 'H' },
          'st-xa-7': { studentId: 'st-xa-7', status: 'H' },
          'st-xa-8': { studentId: 'st-xa-8', status: 'H' },
        },
      },
    ],
    lessonNotes: [
      {
        id: 'note-1',
        date: today,
        scheduleSlotId: 'sch-3',
        classId: 'cls-xa',
        subject: 'Matematika Wajib',
        atpId: 'atp-2',
        atpCode: 'TP.10.2',
        meetingNumber: 14,
        topic: 'Sistem Pertidaksamaan Linear Dua Variabel (SPtLDV)',
        learningObjective:
          'Siswa mampu menentukan daerah himpunan penyelesaian sistem pertidaksamaan linear dua variabel.',
        activitySummary:
          'Diskusi kelompok kecil menggunakan LKPD 4.2 di koordinat Kartesius.',
        homework: 'Latihan Buku Paket Hal. 118 No. 1–5.',
        reflection:
          'Perlu penguatan 10 menit pada uji titik untuk koefisien y negatif pada pertemuan berikutnya.',
        status: 'Berlanjut',
        updatedAt: `${today}T08:42:00`,
      },
      {
        id: 'note-2',
        date: yesterday3,
        scheduleSlotId: 'sch-5',
        classId: 'cls-xi1',
        subject: 'Matematika Tingkat Lanjut',
        atpId: 'atp-3',
        atpCode: 'TP.11.1',
        meetingNumber: 12,
        topic: 'Polinomial: Teorema Sisa dan Teorema Faktor',
        learningObjective:
          'Siswa mampu menentukan sisa pembagian suku banyak menggunakan skema Horner.',
        activitySummary:
          'Demonstrasi pembagian bersusun vs skema Horner dilanjutkan latihan berpasangan.',
        homework: 'Kuis mandiri 4 soal teorema faktor.',
        reflection: 'Materi tuntas sesuai alokasi waktu.',
        status: 'Tuntas',
        updatedAt: `${yesterday3}T10:05:00`,
      },
      {
        id: 'note-3',
        date: yesterday4,
        scheduleSlotId: 'sch-4',
        classId: 'cls-xii2',
        subject: 'Matematika Peminatan',
        meetingNumber: 15,
        topic: 'Turunan Fungsi Trigonometri & Aturan Rantai',
        learningObjective:
          'Siswa dapat menentukan turunan pertama fungsi komposisi trigonometri.',
        activitySummary: 'Penurunan bertahap sin(ax + b) dan latihan soal terstruktur.',
        homework: 'Membuat 3 soal variasi aturan rantai.',
        reflection: 'Aplikasi garis singgung dilanjutkan pertemuan berikutnya.',
        status: 'Tertunda',
        updatedAt: `${yesterday4}T11:20:00`,
      },
    ],
  };
}

function buildHendraJournal(user: StoredUser): Record<string, unknown> {
  const today = getTodayIso();
  return {
    profile: {
      name: user.name,
      nip: user.nip,
      subject: user.subject,
      school: SCHOOL_NAME,
      schoolLogoUrl: SCHOOL_LOGO_URL,
      academicYear: '2026/2027',
      semester: 'Ganjil',
      avatarUrl: '',
    },
    subjects: [
      {
        id: 'subj-fis-xi',
        code: 'FIS-XI',
        name: 'Fisika Tingkat Lanjut',
        gradeLevel: 'XI (Fase F)',
        kktp: 75,
        weeklyHours: 4,
        description: 'Kinematika, dinamika rotasi, kesetimbangan benda tegar, dan fluida.',
      },
    ],
    atpItems: [
      {
        id: 'atp-fis-1',
        subjectId: 'subj-fis-xi',
        subjectName: 'Fisika Tingkat Lanjut',
        gradeLevel: 'XI',
        semester: 'Ganjil',
        code: 'FIS.11.1',
        element: 'Mekanika & Fluida',
        objective:
          'Peserta didik mampu menganalisis prinsip hukum Pascal, Archimedes, dan Bernoulli pada fluida statis dan dinamis.',
        materials: [
          'Tekanan hidrostatis dan hukum Pascal',
          'Gaya apung Archimedes',
          'Persamaan kontinuitas dan asas Bernoulli',
        ],
        allocatedHours: 8,
        status: 'Sedang Berjalan',
        order: 1,
      },
    ],
    classes: [
      {
        id: 'cls-fis-xi1',
        name: 'XI-IPA-1',
        grade: 'XI',
        major: 'MIPA',
        room: 'Lab Fisika',
        homeroomTeacher: 'Drs. Hendra Wijaya',
        students: [
          { id: 'st-f-1', nis: '251011', name: 'Alvin Hendrawan', gender: 'L' },
          { id: 'st-f-2', nis: '251012', name: 'Bella Puspita Dewi', gender: 'P' },
          { id: 'st-f-3', nis: '251013', name: 'Candra Setiawan', gender: 'L' },
          { id: 'st-f-4', nis: '251014', name: 'Dina Safitri', gender: 'P' },
        ],
      },
    ],
    schedules: [
      {
        id: 'sch-f-1',
        day: 'Rabu',
        startTime: '08:45',
        endTime: '10:15',
        classId: 'cls-fis-xi1',
        subjectId: 'subj-fis-xi',
        subject: 'Fisika Tingkat Lanjut',
        room: 'Lab Fisika',
        lessonHours: 2,
      },
      {
        id: 'sch-f-2',
        day: 'Kamis',
        startTime: '10:15',
        endTime: '11:45',
        classId: 'cls-fis-xi1',
        subjectId: 'subj-fis-xi',
        subject: 'Fisika Tingkat Lanjut',
        room: 'Lab Fisika',
        lessonHours: 2,
      },
    ],
    attendanceSessions: [],
    lessonNotes: [
      {
        id: 'note-f-1',
        date: today,
        scheduleSlotId: 'sch-f-1',
        classId: 'cls-fis-xi1',
        subject: 'Fisika Tingkat Lanjut',
        atpId: 'atp-fis-1',
        atpCode: 'FIS.11.1',
        meetingNumber: 9,
        topic: 'Tekanan Hidrostatis & Hukum Pascal',
        learningObjective:
          'Siswa dapat menghitung tekanan hidrostatis pada berbagai kedalaman dan menerapkan prinsip dongkrak hidrolik.',
        activitySummary: 'Praktikum bejana berhubungan dan simulasi dongkrak hidrolik.',
        homework: 'Laporan hasil pengamatan praktikum kelompok.',
        reflection: 'Siswa antusias melakukan percobaan laboratorium.',
        status: 'Tuntas',
        updatedAt: `${today}T10:10:00`,
      },
    ],
  };
}

function createInitialDatabase(): DatabaseSchema {
  const today = getTodayIso();
  const tomorrow = getOffsetIso(1);
  const plus3 = getOffsetIso(3);
  const plus6 = getOffsetIso(6);

  const adminUser: StoredUser = {
    id: 'usr-admin',
    username: 'admin',
    passwordHash: hashPassword('admin123'),
    role: 'admin',
    name: 'Drs. Budi Santoso, M.Pd.',
    nip: '19750812 200112 1 002',
    subject: 'Kurikulum & Akademik',
    active: true,
    createdAt: new Date().toISOString(),
  };

  const ratnaUser: StoredUser = {
    id: 'usr-ratna',
    username: 'ratna',
    passwordHash: hashPassword('guru123'),
    role: 'guru',
    name: 'Ratna Dewi, S.Pd.',
    nip: '19890415 201503 2 004',
    subject: 'Matematika',
    active: true,
    createdAt: new Date().toISOString(),
  };

  const hendraUser: StoredUser = {
    id: 'usr-hendra',
    username: 'hendra',
    passwordHash: hashPassword('guru123'),
    role: 'guru',
    name: 'Drs. Hendra Wijaya',
    nip: '19820310 200801 1 007',
    subject: 'Fisika',
    active: true,
    createdAt: new Date().toISOString(),
  };

  const calendarEvents: CalendarReminderRecord[] = [
    {
      id: 'cal-1',
      date: today,
      time: '07:00',
      title: 'Pengisian Presensi & Jurnal Mengajar Harian',
      description:
        'Bapak/Ibu guru dimohon melengkapi presensi siswa dan catatan materi setiap selesai sesi kelas.',
      scope: 'sekolah',
      category: 'Akademik',
      ownerUserId: adminUser.id,
      ownerName: adminUser.name,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'cal-2',
      date: today,
      time: '13:30',
      title: 'Rapat Koordinasi Kurikulum & Review ATP',
      description:
        'Bertempat di Ruang Guru SMA Negeri 1 Pagerbarang. Membawa perangkat ATP masing-masing mapel.',
      scope: 'sekolah',
      category: 'Rapat',
      ownerUserId: adminUser.id,
      ownerName: adminUser.name,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'cal-3',
      date: tomorrow,
      time: '15:00',
      title: 'Batas Akhir Verifikasi Nilai Sumatif Tengah Semester',
      description: 'Pastikan seluruh nilai dan kehadiran siswa telah diverifikasi.',
      scope: 'sekolah',
      category: 'Ujian',
      ownerUserId: adminUser.id,
      ownerName: adminUser.name,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'cal-4',
      date: plus3,
      time: '07:15',
      title: 'Supervisi Akademik Kelas Fase E & Fase F',
      description: 'Jadwal supervisi pembelajaran semester ganjil bersama tim kurikulum.',
      scope: 'sekolah',
      category: 'Akademik',
      ownerUserId: adminUser.id,
      ownerName: adminUser.name,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'cal-5',
      date: plus6,
      time: '07:00',
      title: 'Upacara Peringatan Hari Guru Nasional',
      description:
        'Seluruh Bapak/Ibu guru mengenakan seragam PGRI di lapangan upacara SMAN 1 Pagerbarang.',
      scope: 'sekolah',
      category: 'Peringatan',
      ownerUserId: adminUser.id,
      ownerName: adminUser.name,
      createdAt: new Date().toISOString(),
    },
  ];

  return {
    sessionSecret: crypto.randomBytes(32).toString('hex'),
    users: [adminUser, ratnaUser, hendraUser],
    journals: {
      [adminUser.id]: buildStarterJournalForUser(adminUser),
      [ratnaUser.id]: buildRatnaJournal(ratnaUser),
      [hendraUser.id]: buildHendraJournal(hendraUser),
    },
    calendarEvents,
  };
}

function readDatabase(): DatabaseSchema {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_PATH)) {
    const initial = createInitialDatabase();
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2), 'utf8');
    return initial;
  }
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  return JSON.parse(raw) as DatabaseSchema;
}

function writeDatabase(db: DatabaseSchema): void {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');
}

function sanitizeUser(user: StoredUser) {
  return {
    id: user.id,
    username: user.username,
    role: user.role,
    name: user.name,
    nip: user.nip,
    subject: user.subject,
    active: user.active,
    createdAt: user.createdAt,
  };
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Sesi login tidak ditemukan. Silakan masuk kembali.' });
    return;
  }
  const token = authHeader.slice(7).trim();
  const db = readDatabase();
  const payload = verifyToken(token, db.sessionSecret);
  if (!payload) {
    res.status(401).json({ error: 'Sesi telah kedaluwarsa. Silakan masuk kembali.' });
    return;
  }
  const user = db.users.find((u) => u.id === payload.userId);
  if (!user || !user.active) {
    res.status(403).json({ error: 'Akun pengguna tidak aktif atau tidak ditemukan.' });
    return;
  }
  req.authUser = user;
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.authUser || req.authUser.role !== 'admin') {
    res.status(403).json({ error: 'Akses ditolak. Khusus administrator sekolah.' });
    return;
  }
  next();
}

async function startServer() {
  // Ensure database exists on boot
  readDatabase();

  const app = express();
  app.use(express.json({ limit: '5mb' }));

  // Public overview for Landing Page (school calendar reminders & active teacher count)
  app.get('/api/public/overview', (_req, res) => {
    const db = readDatabase();
    const schoolReminders = db.calendarEvents
      .filter((e) => e.scope === 'sekolah')
      .sort((a, b) => a.date.localeCompare(b.date) || (a.time ?? '').localeCompare(b.time ?? ''));
    const activeTeachers = db.users.filter((u) => u.active).length;
    res.json({
      schoolName: SCHOOL_NAME,
      schoolLogoUrl: SCHOOL_LOGO_URL,
      activeTeachers,
      schoolReminders,
    });
  });

  // Auth routes
  app.post('/api/auth/login', (req, res) => {
    const usernameInput = String(req.body?.username ?? '').trim().toLowerCase();
    const passwordInput = String(req.body?.password ?? '');

    if (!usernameInput || !passwordInput) {
      res.status(400).json({ error: 'Username dan password wajib diisi.' });
      return;
    }

    const db = readDatabase();
    const user = db.users.find((u) => u.username.toLowerCase() === usernameInput);
    if (!user || !verifyPassword(passwordInput, user.passwordHash)) {
      res.status(401).json({ error: 'Username atau password salah.' });
      return;
    }
    if (!user.active) {
      res.status(403).json({
        error: 'Akun Anda sedang dinonaktifkan. Hubungi admin kurikulum sekolah.',
      });
      return;
    }

    const token = signToken(
      {
        userId: user.id,
        username: user.username,
        role: user.role,
        exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
      },
      db.sessionSecret
    );

    res.json({ token, user: sanitizeUser(user) });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
    res.json({ user: sanitizeUser(req.authUser!) });
  });

  app.post('/api/auth/change-password', requireAuth, (req: AuthenticatedRequest, res) => {
    const currentPassword = String(req.body?.currentPassword ?? '');
    const newPassword = String(req.body?.newPassword ?? '');
    if (newPassword.length < 6) {
      res.status(400).json({ error: 'Password baru minimal 6 karakter.' });
      return;
    }
    const db = readDatabase();
    const idx = db.users.findIndex((u) => u.id === req.authUser!.id);
    if (idx < 0 || !verifyPassword(currentPassword, db.users[idx].passwordHash)) {
      res.status(400).json({ error: 'Password saat ini tidak sesuai.' });
      return;
    }
    db.users[idx].passwordHash = hashPassword(newPassword);
    writeDatabase(db);
    res.json({ ok: true });
  });

  // Per-user Journal State
  app.get('/api/journal', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = readDatabase();
    const user = req.authUser!;
    let journal = db.journals[user.id];
    if (!journal) {
      journal = buildStarterJournalForUser(user);
      db.journals[user.id] = journal;
      writeDatabase(db);
    }
    res.json({ journal });
  });

  app.put('/api/journal', requireAuth, (req: AuthenticatedRequest, res) => {
    const payload = req.body?.journal;
    if (!payload || typeof payload !== 'object') {
      res.status(400).json({ error: 'Format data jurnal tidak valid.' });
      return;
    }
    const db = readDatabase();
    db.journals[req.authUser!.id] = payload;
    writeDatabase(db);
    res.json({ ok: true });
  });

  // Running Calendar & Daily Reminders
  app.get('/api/calendar', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = readDatabase();
    const user = req.authUser!;
    const events = db.calendarEvents
      .filter((e) => e.scope === 'sekolah' || e.ownerUserId === user.id)
      .sort((a, b) => a.date.localeCompare(b.date) || (a.time ?? '').localeCompare(b.time ?? ''));
    res.json({ events });
  });

  app.post('/api/calendar', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const date = String(req.body?.date ?? '').trim();
    const time = String(req.body?.time ?? '').trim();
    const title = String(req.body?.title ?? '').trim();
    const description = String(req.body?.description ?? '').trim();
    const requestedScope = req.body?.scope === 'sekolah' ? 'sekolah' : 'pribadi';
    const category = (req.body?.category ?? 'Pribadi') as CalendarCategory;

    if (!date || !title) {
      res.status(400).json({ error: 'Tanggal dan judul pengingat wajib diisi.' });
      return;
    }

    const scope = requestedScope === 'sekolah' && user.role === 'admin' ? 'sekolah' : 'pribadi';
    const db = readDatabase();
    const created: CalendarReminderRecord = {
      id: `cal-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      date,
      time: time || undefined,
      title,
      description,
      scope,
      category,
      ownerUserId: user.id,
      ownerName: user.name,
      createdAt: new Date().toISOString(),
    };
    db.calendarEvents.push(created);
    writeDatabase(db);
    res.status(201).json({ event: created });
  });

  app.delete('/api/calendar/:id', requireAuth, (req: AuthenticatedRequest, res) => {
    const user = req.authUser!;
    const db = readDatabase();
    const idx = db.calendarEvents.findIndex((e) => e.id === req.params.id);
    if (idx < 0) {
      res.status(404).json({ error: 'Agenda tidak ditemukan.' });
      return;
    }
    const target = db.calendarEvents[idx];
    const canDelete =
      user.role === 'admin' || (target.scope === 'pribadi' && target.ownerUserId === user.id);
    if (!canDelete) {
      res.status(403).json({ error: 'Anda tidak memiliki izin menghapus agenda ini.' });
      return;
    }
    db.calendarEvents.splice(idx, 1);
    writeDatabase(db);
    res.json({ ok: true });
  });

  // Admin User Management
  app.get('/api/users', requireAuth, requireAdmin, (_req, res) => {
    const db = readDatabase();
    res.json({ users: db.users.map(sanitizeUser) });
  });

  app.post('/api/users', requireAuth, requireAdmin, (req, res) => {
    const username = String(req.body?.username ?? '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9._-]/g, '');
    const password = String(req.body?.password ?? '');
    const name = String(req.body?.name ?? '').trim();
    const nip = String(req.body?.nip ?? '-').trim();
    const subject = String(req.body?.subject ?? 'Mata Pelajaran').trim();
    const role: UserRole = req.body?.role === 'admin' ? 'admin' : 'guru';

    if (!username || username.length < 3) {
      res.status(400).json({ error: 'Username minimal 3 karakter (huruf/angka/._-).' });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: 'Password awal minimal 6 karakter.' });
      return;
    }
    if (!name) {
      res.status(400).json({ error: 'Nama lengkap guru wajib diisi.' });
      return;
    }

    const db = readDatabase();
    if (db.users.some((u) => u.username.toLowerCase() === username)) {
      res.status(409).json({ error: `Username "${username}" sudah digunakan.` });
      return;
    }

    const newUser: StoredUser = {
      id: `usr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      username,
      passwordHash: hashPassword(password),
      role,
      name,
      nip: nip || '-',
      subject: subject || 'Mata Pelajaran',
      active: true,
      createdAt: new Date().toISOString(),
    };

    db.users.push(newUser);
    db.journals[newUser.id] = buildStarterJournalForUser(newUser);
    writeDatabase(db);

    res.status(201).json({ user: sanitizeUser(newUser) });
  });

  app.patch('/api/users/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
    const db = readDatabase();
    const idx = db.users.findIndex((u) => u.id === req.params.id);
    if (idx < 0) {
      res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
      return;
    }

    const target = db.users[idx];
    if (req.body?.name !== undefined) {
      target.name = String(req.body.name).trim() || target.name;
    }
    if (req.body?.nip !== undefined) {
      target.nip = String(req.body.nip).trim() || '-';
    }
    if (req.body?.subject !== undefined) {
      target.subject = String(req.body.subject).trim() || target.subject;
    }
    if (req.body?.role === 'admin' || req.body?.role === 'guru') {
      if (target.id === req.authUser!.id && req.body.role !== 'admin') {
        res.status(400).json({ error: 'Tidak dapat menurunkan peran akun sendiri.' });
        return;
      }
      target.role = req.body.role;
    }
    if (typeof req.body?.active === 'boolean') {
      if (target.id === req.authUser!.id && !req.body.active) {
        res.status(400).json({ error: 'Tidak dapat menonaktifkan akun sendiri.' });
        return;
      }
      target.active = req.body.active;
    }
    if (req.body?.newPassword) {
      const pw = String(req.body.newPassword);
      if (pw.length < 6) {
        res.status(400).json({ error: 'Password baru minimal 6 karakter.' });
        return;
      }
      target.passwordHash = hashPassword(pw);
    }

    writeDatabase(db);
    res.json({ user: sanitizeUser(target) });
  });

  app.delete('/api/users/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
    if (req.params.id === req.authUser!.id) {
      res.status(400).json({ error: 'Tidak dapat menghapus akun yang sedang digunakan.' });
      return;
    }
    const db = readDatabase();
    const idx = db.users.findIndex((u) => u.id === req.params.id);
    if (idx < 0) {
      res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
      return;
    }
    const [removed] = db.users.splice(idx, 1);
    delete db.journals[removed.id];
    writeDatabase(db);
    res.json({ ok: true });
  });

  // Vite dev middleware vs production static files
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SIGAP server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
