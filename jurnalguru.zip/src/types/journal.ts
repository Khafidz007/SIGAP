export type DayOfWeek = 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu';

export type AttendanceStatus = 'H' | 'I' | 'S' | 'A';

export type MaterialStatus = 'Tuntas' | 'Berlanjut' | 'Tertunda';

export type AtpStatus = 'Belum Diajarkan' | 'Sedang Berjalan' | 'Tercapai';

export type UserRole = 'admin' | 'guru';

export type CalendarCategory =
  | 'Akademik'
  | 'Rapat'
  | 'Ujian'
  | 'Peringatan'
  | 'Pribadi';

export interface UserAccount {
  id: string;
  username: string;
  role: UserRole;
  name: string;
  nip: string;
  subject: string;
  active: boolean;
  createdAt: string;
}

export interface CalendarReminder {
  id: string;
  date: string;
  time?: string;
  title: string;
  description: string;
  scope: 'sekolah' | 'pribadi';
  category: CalendarCategory;
  ownerUserId: string;
  ownerName: string;
  createdAt: string;
}

export type NavSection =
  | 'ringkasan'
  | 'jadwal'
  | 'presensi'
  | 'atp'
  | 'riwayat'
  | 'pelajaran_kelas'
  | 'kalender'
  | 'kelola_user';

export interface TeacherProfile {
  name: string;
  nip: string;
  subject: string;
  school: string;
  schoolLogoUrl?: string;
  academicYear: string;
  semester: 'Ganjil' | 'Genap';
  avatarUrl: string;
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  gradeLevel: string;
  kktp: number;
  weeklyHours: number;
  description: string;
}

export interface AtpItem {
  id: string;
  subjectId: string;
  subjectName: string;
  gradeLevel: string;
  semester: 'Ganjil' | 'Genap';
  code: string;
  element: string;
  objective: string;
  materials: string[];
  allocatedHours: number;
  status: AtpStatus;
  order: number;
}

export interface Student {
  id: string;
  nis: string;
  name: string;
  gender: 'L' | 'P';
}

export interface Classroom {
  id: string;
  name: string;
  grade: string;
  major: string;
  room: string;
  homeroomTeacher?: string;
  students: Student[];
}

export interface ScheduleSlot {
  id: string;
  day: DayOfWeek;
  startTime: string;
  endTime: string;
  classId: string;
  subjectId?: string;
  subject: string;
  room: string;
  lessonHours: number;
}

export interface StudentAttendanceEntry {
  studentId: string;
  status: AttendanceStatus;
  note?: string;
}

export interface AttendanceSession {
  id: string;
  date: string;
  scheduleSlotId?: string;
  classId: string;
  subject: string;
  records: Record<string, StudentAttendanceEntry>;
  updatedAt: string;
}

export interface LessonNote {
  id: string;
  date: string;
  scheduleSlotId?: string;
  classId: string;
  subject: string;
  atpId?: string;
  atpCode?: string;
  meetingNumber: number;
  topic: string;
  learningObjective: string;
  activitySummary: string;
  homework: string;
  reflection: string;
  status: MaterialStatus;
  updatedAt: string;
}

export interface JournalState {
  profile: TeacherProfile;
  subjects: Subject[];
  atpItems: AtpItem[];
  classes: Classroom[];
  schedules: ScheduleSlot[];
  attendanceSessions: AttendanceSession[];
  lessonNotes: LessonNote[];
}
