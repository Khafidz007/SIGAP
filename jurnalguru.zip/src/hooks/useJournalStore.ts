import { useEffect, useState, useCallback, useRef } from 'react';
import {
  AtpItem,
  AttendanceSession,
  AttendanceStatus,
  Classroom,
  JournalState,
  LessonNote,
  ScheduleSlot,
  Student,
  Subject,
  TeacherProfile,
} from '../types/journal';
import {
  createEmptyData,
  createSeedData,
  SCHOOL_LOGO_URL,
  SEED_ATP_ITEMS,
  SEED_SUBJECTS,
} from '../data/seedData';
import { saveUserJournal } from '../services/api';

function normalizeJournalState(
  raw: Partial<JournalState> | null | undefined,
  fallbackSchoolLogo = SCHOOL_LOGO_URL
): JournalState {
  if (!raw || !raw.profile || !Array.isArray(raw.classes)) {
    return createSeedData();
  }
  const migratedSchool =
    raw.profile.school === 'SMA Negeri 1 Nusantara'
      ? 'SMA Negeri 1 Pagerbarang'
      : raw.profile.school;
  return {
    profile: {
      ...raw.profile,
      school: migratedSchool,
      schoolLogoUrl: raw.profile.schoolLogoUrl || fallbackSchoolLogo,
    },
    subjects: Array.isArray(raw.subjects) ? raw.subjects : SEED_SUBJECTS,
    atpItems: Array.isArray(raw.atpItems) ? raw.atpItems : SEED_ATP_ITEMS,
    classes: raw.classes,
    schedules: Array.isArray(raw.schedules) ? raw.schedules : [],
    attendanceSessions: Array.isArray(raw.attendanceSessions)
      ? raw.attendanceSessions
      : [],
    lessonNotes: Array.isArray(raw.lessonNotes) ? raw.lessonNotes : [],
  };
}

export interface ImportSubjectsAndClassesPayload {
  subjects: Omit<Subject, 'id'>[];
  classes: Array<
    Omit<Classroom, 'id' | 'students'> & { students: Omit<Student, 'id'>[] }
  >;
  mode: 'merge' | 'replace';
}

export interface ImportSubjectsAndClassesSummary {
  addedSubjects: number;
  updatedSubjects: number;
  addedClasses: number;
  updatedClasses: number;
  addedStudents: number;
}

export function useJournalStore(
  userId: string | null,
  initialServerState: JournalState | null
) {
  const [state, setState] = useState<JournalState>(() =>
    normalizeJournalState(initialServerState)
  );
  const stateRef = useRef<JournalState>(state);
  stateRef.current = state;
  const hydratedUserRef = useRef<string | null>(null);
  const saveTimerRef = useRef<number | null>(null);

  useEffect(() => {
    if (!userId || !initialServerState) return;
    hydratedUserRef.current = userId;
    setState(normalizeJournalState(initialServerState));
  }, [userId, initialServerState]);

  useEffect(() => {
    if (!userId || hydratedUserRef.current !== userId) return;

    try {
      localStorage.setItem(`jurnalguru_state_${userId}`, JSON.stringify(state));
    } catch {
      // ignore localStorage quota errors
    }

    if (saveTimerRef.current) {
      window.clearTimeout(saveTimerRef.current);
    }
    saveTimerRef.current = window.setTimeout(() => {
      saveUserJournal(state).catch((err) => {
        console.error('Gagal menyinkronkan jurnal ke server:', err);
      });
    }, 350);

    return () => {
      if (saveTimerRef.current) {
        window.clearTimeout(saveTimerRef.current);
      }
    };
  }, [state, userId]);

  const updateProfile = useCallback((profile: TeacherProfile) => {
    setState((prev) => ({ ...prev, profile }));
  }, []);

  // Subject CRUD
  const addSubject = useCallback((payload: Omit<Subject, 'id'>) => {
    const id = `subj-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setState((prev) => ({
      ...prev,
      subjects: [...prev.subjects, { ...payload, id }],
    }));
    return id;
  }, []);

  const updateSubject = useCallback(
    (id: string, patch: Partial<Omit<Subject, 'id'>>) => {
      setState((prev) => ({
        ...prev,
        subjects: prev.subjects.map((s) => (s.id === id ? { ...s, ...patch } : s)),
      }));
    },
    []
  );

  const deleteSubject = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      subjects: prev.subjects.filter((s) => s.id !== id),
      atpItems: prev.atpItems.filter((a) => a.subjectId !== id),
    }));
  }, []);

  // ATP CRUD
  const addAtpItem = useCallback((payload: Omit<AtpItem, 'id'>) => {
    const id = `atp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setState((prev) => ({
      ...prev,
      atpItems: [...prev.atpItems, { ...payload, id }],
    }));
    return id;
  }, []);

  const updateAtpItem = useCallback(
    (id: string, patch: Partial<Omit<AtpItem, 'id'>>) => {
      setState((prev) => ({
        ...prev,
        atpItems: prev.atpItems.map((a) => (a.id === id ? { ...a, ...patch } : a)),
      }));
    },
    []
  );

  const deleteAtpItem = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      atpItems: prev.atpItems.filter((a) => a.id !== id),
    }));
  }, []);

  // Class CRUD
  const addClass = useCallback(
    (payload: Omit<Classroom, 'id' | 'students'> & { students?: Student[] }) => {
      const id = `cls-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      setState((prev) => ({
        ...prev,
        classes: [
          ...prev.classes,
          {
            id,
            name: payload.name,
            grade: payload.grade,
            major: payload.major,
            room: payload.room,
            homeroomTeacher: payload.homeroomTeacher,
            students: payload.students ?? [],
          },
        ],
      }));
      return id;
    },
    []
  );

  const updateClass = useCallback((id: string, patch: Partial<Omit<Classroom, 'id'>>) => {
    setState((prev) => ({
      ...prev,
      classes: prev.classes.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    }));
  }, []);

  const deleteClass = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      classes: prev.classes.filter((c) => c.id !== id),
      schedules: prev.schedules.filter((s) => s.classId !== id),
    }));
  }, []);

  // Student CRUD
  const addStudent = useCallback(
    (classId: string, student: Omit<Student, 'id'>) => {
      const id = `st-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      setState((prev) => ({
        ...prev,
        classes: prev.classes.map((c) =>
          c.id === classId
            ? { ...c, students: [...c.students, { ...student, id }] }
            : c
        ),
      }));
    },
    []
  );

  const addStudentsBulk = useCallback(
    (classId: string, students: Omit<Student, 'id'>[]) => {
      setState((prev) => ({
        ...prev,
        classes: prev.classes.map((c) => {
          if (c.id !== classId) return c;
          const created = students.map((st, idx) => ({
            ...st,
            id: `st-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
          }));
          return { ...c, students: [...c.students, ...created] };
        }),
      }));
    },
    []
  );

  const updateStudent = useCallback(
    (classId: string, studentId: string, patch: Partial<Omit<Student, 'id'>>) => {
      setState((prev) => ({
        ...prev,
        classes: prev.classes.map((c) =>
          c.id === classId
            ? {
                ...c,
                students: c.students.map((s) =>
                  s.id === studentId ? { ...s, ...patch } : s
                ),
              }
            : c
        ),
      }));
    },
    []
  );

  const deleteStudent = useCallback((classId: string, studentId: string) => {
    setState((prev) => ({
      ...prev,
      classes: prev.classes.map((c) =>
        c.id === classId
          ? { ...c, students: c.students.filter((s) => s.id !== studentId) }
          : c
      ),
    }));
  }, []);

  // Schedule CRUD
  const addSchedule = useCallback((payload: Omit<ScheduleSlot, 'id'>) => {
    const id = `sch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setState((prev) => ({
      ...prev,
      schedules: [...prev.schedules, { ...payload, id }],
    }));
    return id;
  }, []);

  const updateSchedule = useCallback(
    (id: string, patch: Partial<Omit<ScheduleSlot, 'id'>>) => {
      setState((prev) => ({
        ...prev,
        schedules: prev.schedules.map((s) => (s.id === id ? { ...s, ...patch } : s)),
      }));
    },
    []
  );

  const deleteSchedule = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      schedules: prev.schedules.filter((s) => s.id !== id),
    }));
  }, []);

  // Attendance Upsert
  const upsertAttendanceSession = useCallback(
    (payload: {
      date: string;
      classId: string;
      subject: string;
      scheduleSlotId?: string;
      records: AttendanceSession['records'];
    }) => {
      const nowIso = new Date().toISOString();
      setState((prev) => {
        const existingIdx = prev.attendanceSessions.findIndex(
          (s) =>
            s.date === payload.date &&
            s.classId === payload.classId &&
            (payload.scheduleSlotId
              ? s.scheduleSlotId === payload.scheduleSlotId
              : !s.scheduleSlotId || s.subject === payload.subject)
        );
        if (existingIdx >= 0) {
          const updated = [...prev.attendanceSessions];
          updated[existingIdx] = {
            ...updated[existingIdx],
            subject: payload.subject,
            scheduleSlotId: payload.scheduleSlotId ?? updated[existingIdx].scheduleSlotId,
            records: payload.records,
            updatedAt: nowIso,
          };
          return { ...prev, attendanceSessions: updated };
        }
        const newSession: AttendanceSession = {
          id: `att-${payload.date}-${payload.classId}-${Date.now()}`,
          date: payload.date,
          classId: payload.classId,
          subject: payload.subject,
          scheduleSlotId: payload.scheduleSlotId,
          records: payload.records,
          updatedAt: nowIso,
        };
        return {
          ...prev,
          attendanceSessions: [newSession, ...prev.attendanceSessions],
        };
      });
    },
    []
  );

  const setStudentAttendance = useCallback(
    (params: {
      date: string;
      classId: string;
      subject: string;
      scheduleSlotId?: string;
      studentId: string;
      status: AttendanceStatus;
      note?: string;
      allStudentIds: string[];
    }) => {
      const nowIso = new Date().toISOString();
      setState((prev) => {
        const idx = prev.attendanceSessions.findIndex(
          (s) =>
            s.date === params.date &&
            s.classId === params.classId &&
            (params.scheduleSlotId
              ? s.scheduleSlotId === params.scheduleSlotId
              : true)
        );
        if (idx >= 0) {
          const current = prev.attendanceSessions[idx];
          const updatedRecords = { ...current.records };
          updatedRecords[params.studentId] = {
            studentId: params.studentId,
            status: params.status,
            note: params.note !== undefined ? params.note : updatedRecords[params.studentId]?.note,
          };
          const updated = [...prev.attendanceSessions];
          updated[idx] = {
            ...current,
            records: updatedRecords,
            updatedAt: nowIso,
          };
          return { ...prev, attendanceSessions: updated };
        }
        const initialRecords: AttendanceSession['records'] = {};
        for (const sid of params.allStudentIds) {
          initialRecords[sid] = {
            studentId: sid,
            status: sid === params.studentId ? params.status : 'H',
            note: sid === params.studentId ? params.note : undefined,
          };
        }
        const newSession: AttendanceSession = {
          id: `att-${params.date}-${params.classId}-${Date.now()}`,
          date: params.date,
          classId: params.classId,
          subject: params.subject,
          scheduleSlotId: params.scheduleSlotId,
          records: initialRecords,
          updatedAt: nowIso,
        };
        return {
          ...prev,
          attendanceSessions: [newSession, ...prev.attendanceSessions],
        };
      });
    },
    []
  );

  const deleteAttendanceSession = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      attendanceSessions: prev.attendanceSessions.filter((s) => s.id !== id),
    }));
  }, []);

  // Lesson Notes CRUD
  const addLessonNote = useCallback(
    (payload: Omit<LessonNote, 'id' | 'updatedAt'>) => {
      const id = `note-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const nowIso = new Date().toISOString();
      setState((prev) => ({
        ...prev,
        lessonNotes: [{ ...payload, id, updatedAt: nowIso }, ...prev.lessonNotes],
      }));
      return id;
    },
    []
  );

  const updateLessonNote = useCallback(
    (id: string, patch: Partial<Omit<LessonNote, 'id'>>) => {
      const nowIso = new Date().toISOString();
      setState((prev) => ({
        ...prev,
        lessonNotes: prev.lessonNotes.map((n) =>
          n.id === id ? { ...n, ...patch, updatedAt: nowIso } : n
        ),
      }));
    },
    []
  );

  const deleteLessonNote = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      lessonNotes: prev.lessonNotes.filter((n) => n.id !== id),
    }));
  }, []);

  const importSubjectsAndClasses = useCallback(
    (
      payload: ImportSubjectsAndClassesPayload
    ): ImportSubjectsAndClassesSummary => {
      const prev = stateRef.current;
      const now = Date.now();
      let addedSubjects = 0;
      let updatedSubjects = 0;
      let addedClasses = 0;
      let updatedClasses = 0;
      let addedStudents = 0;

      // 1. Subjects
      let nextSubjects: Subject[] = [...prev.subjects];
      if (payload.subjects.length > 0) {
        if (payload.mode === 'replace') {
          const existingByNameGrade = new Map<string, Subject>();
          const existingByName = new Map<string, Subject>();
          for (const s of prev.subjects) {
            const nameKey = s.name.trim().toLowerCase();
            const gradeKey = s.gradeLevel.trim().toLowerCase();
            existingByNameGrade.set(`${nameKey}::${gradeKey}`, s);
            if (!existingByName.has(nameKey)) {
              existingByName.set(nameKey, s);
            }
          }
          nextSubjects = payload.subjects.map((incoming, idx) => {
            const nameKey = incoming.name.trim().toLowerCase();
            const gradeKey = incoming.gradeLevel.trim().toLowerCase();
            const matched =
              existingByNameGrade.get(`${nameKey}::${gradeKey}`) ??
              existingByName.get(nameKey);
            if (matched) {
              updatedSubjects++;
              return { ...incoming, id: matched.id };
            }
            addedSubjects++;
            return {
              ...incoming,
              id: `subj-${now}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
            };
          });
        } else {
          for (let idx = 0; idx < payload.subjects.length; idx++) {
            const incoming = payload.subjects[idx];
            const nameKey = incoming.name.trim().toLowerCase();
            const gradeKey = incoming.gradeLevel.trim().toLowerCase();
            let matchIdx = nextSubjects.findIndex(
              (s) =>
                s.name.trim().toLowerCase() === nameKey &&
                s.gradeLevel.trim().toLowerCase() === gradeKey
            );
            if (matchIdx < 0) {
              matchIdx = nextSubjects.findIndex(
                (s) => s.name.trim().toLowerCase() === nameKey
              );
            }
            if (matchIdx >= 0) {
              nextSubjects[matchIdx] = {
                ...nextSubjects[matchIdx],
                ...incoming,
              };
              updatedSubjects++;
            } else {
              nextSubjects.push({
                ...incoming,
                id: `subj-${now}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
              });
              addedSubjects++;
            }
          }
        }
      }

      // 2. Classes & Students
      let nextClasses: Classroom[] = prev.classes.map((c) => ({
        ...c,
        students: [...c.students],
      }));

      if (payload.classes.length > 0) {
        if (payload.mode === 'replace') {
          const existingByName = new Map(
            prev.classes.map((c) => [c.name.trim().toLowerCase(), c])
          );
          nextClasses = payload.classes.map((incoming, cIdx) => {
            const matched = existingByName.get(incoming.name.trim().toLowerCase());
            if (matched) {
              updatedClasses++;
            } else {
              addedClasses++;
            }
            const createdStudents: Student[] = incoming.students.map((st, sIdx) => {
              addedStudents++;
              return {
                ...st,
                id: `st-${now}-${cIdx}-${sIdx}-${Math.random().toString(36).slice(2, 5)}`,
              };
            });
            return {
              id:
                matched?.id ??
                `cls-${now}-${cIdx}-${Math.random().toString(36).slice(2, 5)}`,
              name: incoming.name,
              grade: incoming.grade,
              major: incoming.major,
              room: incoming.room,
              homeroomTeacher: incoming.homeroomTeacher,
              students: createdStudents,
            };
          });
        } else {
          for (let cIdx = 0; cIdx < payload.classes.length; cIdx++) {
            const incoming = payload.classes[cIdx];
            const matchIdx = nextClasses.findIndex(
              (c) =>
                c.name.trim().toLowerCase() === incoming.name.trim().toLowerCase()
            );

            if (matchIdx >= 0) {
              const target = nextClasses[matchIdx];
              const existingNis = new Set(
                target.students.map((s) => s.nis.trim().toLowerCase()).filter(Boolean)
              );
              const existingNames = new Set(
                target.students.map((s) => s.name.trim().toLowerCase())
              );

              const newStudents: Student[] = [];
              incoming.students.forEach((st, sIdx) => {
                const nisKey = st.nis.trim().toLowerCase();
                const nameKey = st.name.trim().toLowerCase();
                if ((nisKey && existingNis.has(nisKey)) || existingNames.has(nameKey)) {
                  return;
                }
                if (nisKey) existingNis.add(nisKey);
                existingNames.add(nameKey);
                addedStudents++;
                newStudents.push({
                  ...st,
                  id: `st-${now}-${cIdx}-${sIdx}-${Math.random().toString(36).slice(2, 5)}`,
                });
              });

              nextClasses[matchIdx] = {
                ...target,
                grade: incoming.grade || target.grade,
                major:
                  incoming.major && incoming.major !== 'Umum'
                    ? incoming.major
                    : target.major,
                room: incoming.room || target.room,
                homeroomTeacher: incoming.homeroomTeacher || target.homeroomTeacher,
                students: [...target.students, ...newStudents],
              };
              updatedClasses++;
            } else {
              const createdStudents: Student[] = incoming.students.map((st, sIdx) => {
                addedStudents++;
                return {
                  ...st,
                  id: `st-${now}-${cIdx}-${sIdx}-${Math.random().toString(36).slice(2, 5)}`,
                };
              });
              nextClasses.push({
                id: `cls-${now}-${cIdx}-${Math.random().toString(36).slice(2, 5)}`,
                name: incoming.name,
                grade: incoming.grade,
                major: incoming.major,
                room: incoming.room,
                homeroomTeacher: incoming.homeroomTeacher,
                students: createdStudents,
              });
              addedClasses++;
            }
          }
        }
      }

      setState((current) => ({
        ...current,
        subjects: nextSubjects,
        classes: nextClasses,
      }));

      return {
        addedSubjects,
        updatedSubjects,
        addedClasses,
        updatedClasses,
        addedStudents,
      };
    },
    []
  );

  const importFullState = useCallback((next: JournalState) => {
    setState(normalizeJournalState(next));
  }, []);

  const resetToSeed = useCallback(() => {
    setState((prev) => {
      const seed = createSeedData();
      return {
        ...seed,
        profile: {
          ...seed.profile,
          name: prev.profile.name,
          nip: prev.profile.nip,
          subject: prev.profile.subject,
          school: prev.profile.school,
          schoolLogoUrl: prev.profile.schoolLogoUrl,
        },
      };
    });
  }, []);

  const clearAllData = useCallback(() => {
    setState((prev) => {
      const empty = createEmptyData();
      return {
        ...empty,
        profile: prev.profile,
      };
    });
  }, []);

  return {
    state,
    updateProfile,
    addSubject,
    updateSubject,
    deleteSubject,
    addAtpItem,
    updateAtpItem,
    deleteAtpItem,
    addClass,
    updateClass,
    deleteClass,
    addStudent,
    addStudentsBulk,
    updateStudent,
    deleteStudent,
    addSchedule,
    updateSchedule,
    deleteSchedule,
    upsertAttendanceSession,
    setStudentAttendance,
    deleteAttendanceSession,
    addLessonNote,
    updateLessonNote,
    deleteLessonNote,
    importSubjectsAndClasses,
    importFullState,
    resetToSeed,
    clearAllData,
  };
}
