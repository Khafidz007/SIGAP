import React, { useEffect, useState } from 'react';
import { Pencil, Plus, Trash2, X } from 'lucide-react';
import { UserAccount, UserRole } from '../types/journal';
import {
  createUserAccount,
  deleteUserAccount,
  fetchUsers,
  updateUserAccount,
} from '../services/api';

interface UserManagementViewProps {
  currentUserId: string;
}

export function UserManagementView({ currentUserId }: UserManagementViewProps) {
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [form, setForm] = useState<{
    username: string;
    password: string;
    name: string;
    nip: string;
    subject: string;
    role: UserRole;
    active: boolean;
  }>({
    username: '',
    password: '',
    name: '',
    nip: '',
    subject: '',
    role: 'guru',
    active: true,
  });

  const loadUsers = async () => {
    setLoading(true);
    try {
      const res = await fetchUsers();
      setUsers(res.users);
      setErrorMsg(null);
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Gagal memuat daftar akun guru.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const openCreateModal = () => {
    setEditingUser(null);
    setErrorMsg(null);
    setForm({
      username: '',
      password: '',
      name: '',
      nip: '',
      subject: '',
      role: 'guru',
      active: true,
    });
    setModalOpen(true);
  };

  const openEditModal = (u: UserAccount) => {
    setEditingUser(u);
    setErrorMsg(null);
    setForm({
      username: u.username,
      password: '',
      name: u.name,
      nip: u.nip,
      subject: u.subject,
      role: u.role,
      active: u.active,
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg(null);
    try {
      if (editingUser) {
        const res = await updateUserAccount(editingUser.id, {
          name: form.name,
          nip: form.nip,
          subject: form.subject,
          role: form.role,
          active: form.active,
          newPassword: form.password.trim() || undefined,
        });
        setUsers((prev) =>
          prev.map((u) => (u.id === res.user.id ? res.user : u))
        );
      } else {
        const res = await createUserAccount({
          username: form.username,
          password: form.password,
          name: form.name,
          nip: form.nip,
          subject: form.subject,
          role: form.role,
        });
        setUsers((prev) => [...prev, res.user]);
      }
      setModalOpen(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Gagal menyimpan akun.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleActive = async (u: UserAccount) => {
    try {
      const res = await updateUserAccount(u.id, { active: !u.active });
      setUsers((prev) =>
        prev.map((item) => (item.id === res.user.id ? res.user : item))
      );
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Gagal mengubah status akun.'
      );
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteUserAccount(id);
      setUsers((prev) => prev.filter((u) => u.id !== id));
      setConfirmDeleteId(null);
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Gagal menghapus akun pengguna.'
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-base font-semibold text-slate-900">
            Kelola Akses Pengguna & Akun Guru
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Berikan username dan password masing-masing bagi Bapak/Ibu guru SMA Negeri 1 Pagerbarang.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreateModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Plus className="h-3.5 w-3.5" />
          Tambah Akun Guru
        </button>
      </div>

      {errorMsg && (
        <div className="text-xs font-medium text-red-700 bg-red-50 border border-red-200 px-4 py-3 rounded-xl">
          {errorMsg}
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {loading ? (
          <div className="px-6 py-10 text-center text-xs text-slate-500">
            Memuat daftar pengguna...
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                  <th className="py-3 pl-6 pr-3 w-32">Username</th>
                  <th className="py-3 px-3 min-w-[200px]">Nama Lengkap</th>
                  <th className="py-3 px-3 w-44">NIP</th>
                  <th className="py-3 px-3 w-40">Mata Pelajaran</th>
                  <th className="py-3 px-3 w-24">Peran</th>
                  <th className="py-3 px-3 w-28">Status</th>
                  <th className="py-3 pl-3 pr-6 w-24 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {users.map((u) => {
                  const isSelf = u.id === currentUserId;
                  return (
                    <React.Fragment key={u.id}>
                      <tr className="hover:bg-slate-50/70">
                        <td className="py-3.5 pl-6 pr-3 font-mono font-semibold text-blue-700">
                          {u.username}
                        </td>
                        <td className="py-3.5 px-3 font-medium text-slate-900">
                          {u.name}
                          {isSelf && (
                            <span className="ml-2 text-[11px] font-normal text-slate-500">
                              (Anda)
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-3 font-mono text-slate-600 tabular-nums">
                          {u.nip}
                        </td>
                        <td className="py-3.5 px-3 text-slate-700">{u.subject}</td>
                        <td className="py-3.5 px-3 font-medium text-slate-800">
                          {u.role === 'admin' ? 'Admin' : 'Guru'}
                        </td>
                        <td className="py-3.5 px-3">
                          <button
                            type="button"
                            disabled={isSelf}
                            onClick={() => handleToggleActive(u)}
                            className={`text-xs font-semibold ${
                              u.active ? 'text-emerald-700' : 'text-red-700'
                            } ${isSelf ? 'opacity-60 cursor-default' : 'hover:underline'}`}
                          >
                            {u.active ? 'Aktif' : 'Nonaktif'}
                          </button>
                        </td>
                        <td className="py-3.5 pl-3 pr-6 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openEditModal(u)}
                              aria-label={`Edit ${u.name}`}
                              className="p-1.5 text-slate-400 hover:text-slate-700 rounded"
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                            {!isSelf && (
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(u.id)}
                                aria-label={`Hapus ${u.name}`}
                                className="p-1.5 text-slate-400 hover:text-red-600 rounded"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                      {confirmDeleteId === u.id && (
                        <tr className="bg-red-50">
                          <td colSpan={7} className="px-6 py-2.5">
                            <div className="flex items-center justify-between gap-3">
                              <span className="text-xs text-red-800">
                                Hapus akun <strong>{u.username}</strong> ({u.name}) beserta seluruh data jurnal miliknya?
                              </span>
                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteId(null)}
                                  className="px-2.5 py-1 text-xs font-medium text-slate-600"
                                >
                                  Batal
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDelete(u.id)}
                                  className="px-2.5 py-1 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded"
                                >
                                  Hapus Akun
                                </button>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h3 className="font-display text-base font-semibold text-slate-900">
                {editingUser ? `Edit Akun (${editingUser.username})` : 'Tambah Akun Guru Baru'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {!editingUser && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Username Login
                  </label>
                  <input
                    type="text"
                    required
                    value={form.username}
                    onChange={(e) =>
                      setForm({ ...form, username: e.target.value })
                    }
                    placeholder="Contoh: siti.aminah"
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {editingUser
                    ? 'Reset Password Baru (Kosongkan jika tidak diubah)'
                    : 'Password Awal (Minimal 6 karakter)'}
                </label>
                <input
                  type="password"
                  required={!editingUser}
                  minLength={editingUser ? undefined : 6}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder={editingUser ? '••••••' : 'Minimal 6 karakter'}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Nama Lengkap & Gelar
                </label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Contoh: Siti Aminah, M.Pd."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    NIP / NUPTK
                  </label>
                  <input
                    type="text"
                    value={form.nip}
                    onChange={(e) => setForm({ ...form, nip: e.target.value })}
                    placeholder="-"
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Peran Akun
                  </label>
                  <select
                    value={form.role}
                    disabled={editingUser?.id === currentUserId}
                    onChange={(e) =>
                      setForm({ ...form, role: e.target.value as UserRole })
                    }
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white disabled:bg-slate-100 focus:outline-none focus:border-blue-600"
                  >
                    <option value="guru">Guru</option>
                    <option value="admin">Admin Sekolah</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Mata Pelajaran Utama
                </label>
                <input
                  type="text"
                  required
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  placeholder="Contoh: Bahasa Indonesia"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 rounded-lg"
                >
                  {submitting
                    ? 'Menyimpan...'
                    : editingUser
                    ? 'Simpan Perubahan'
                    : 'Buat Akun'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
