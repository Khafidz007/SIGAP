import React, { useRef, useState } from 'react';
import { X, Download, Upload, RotateCcw, Trash2, KeyRound } from 'lucide-react';
import { JournalState, TeacherProfile } from '../types/journal';
import { SCHOOL_LOGO_URL } from '../data/seedData';
import { changeMyPassword } from '../services/api';

interface TeacherProfileModalProps {
  profile: TeacherProfile;
  username?: string;
  fullState: JournalState;
  onSaveProfile: (profile: TeacherProfile) => void;
  onImportState: (next: JournalState) => void;
  onResetToSeed: () => void;
  onClearAll: () => void;
  onClose: () => void;
}

export function TeacherProfileModal({
  profile,
  username,
  fullState,
  onSaveProfile,
  onImportState,
  onResetToSeed,
  onClearAll,
  onClose,
}: TeacherProfileModalProps) {
  const [form, setForm] = useState<TeacherProfile>(profile);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [confirmMode, setConfirmMode] = useState<'none' | 'reset' | 'clear'>('none');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [changingPassword, setChangingPassword] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile({
      ...form,
      name: form.name.trim() || 'Guru Pengajar',
      subject: form.subject.trim() || 'Mata Pelajaran',
      school: form.school.trim() || 'Sekolah',
    });
    onClose();
  };

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(fullState, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cadangan-jurnalguru-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setFeedback('Cadangan data JSON berhasil diunduh.');
  };

  const handleImportJson = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as JournalState;
      if (!parsed.profile || !Array.isArray(parsed.classes) || !Array.isArray(parsed.schedules)) {
        setFeedback('Format file JSON tidak valid.');
        return;
      }
      onImportState(parsed);
      setForm(parsed.profile);
      setFeedback('Data jurnal berhasil dipulihkan dari file cadangan.');
    } catch {
      setFeedback('Gagal membaca file JSON.');
    }
    e.target.value = '';
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="profile-modal-title"
    >
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-xl shadow-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <h2 id="profile-modal-title" className="font-display text-lg font-semibold text-slate-900">
            Profil Guru & Pengaturan Data
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup pengaturan"
            className="p-2 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Nama Lengkap & Gelar
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                NIP / NUPTK
              </label>
              <input
                type="text"
                value={form.nip}
                onChange={(e) => setForm({ ...form, nip: e.target.value })}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Mata Pelajaran Utama
              </label>
              <input
                type="text"
                required
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Nama Sekolah / Instansi
              </label>
              <div className="flex items-center gap-3">
                <img
                  src={form.schoolLogoUrl || SCHOOL_LOGO_URL}
                  alt={`Logo ${form.school}`}
                  referrerPolicy="no-referrer"
                  className="h-10 w-10 object-contain shrink-0 border border-slate-200 rounded-lg p-1 bg-white"
                />
                <input
                  type="text"
                  required
                  value={form.school}
                  onChange={(e) => setForm({ ...form, school: e.target.value })}
                  className="flex-1 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Tahun Ajaran
              </label>
              <input
                type="text"
                value={form.academicYear}
                onChange={(e) => setForm({ ...form, academicYear: e.target.value })}
                placeholder="2026/2027"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Semester
              </label>
              <select
                value={form.semester}
                onChange={(e) =>
                  setForm({ ...form, semester: e.target.value as 'Ganjil' | 'Genap' })
                }
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
              >
                <option value="Ganjil">Ganjil</option>
                <option value="Genap">Genap</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-lg"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              Simpan Profil
            </button>
          </div>
        </form>

        <div className="px-6 py-5 border-t border-slate-200 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-slate-900 inline-flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-slate-500" />
              Keamanan Akun & Ubah Password
            </h3>
            {username && (
              <span className="font-mono text-xs text-slate-500">
                @{username}
              </span>
            )}
          </div>

          {passwordStatus && (
            <p
              className={`text-xs font-medium px-3 py-2 rounded-lg border ${
                passwordStatus.type === 'success'
                  ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                  : 'text-red-700 bg-red-50 border-red-200'
              }`}
            >
              {passwordStatus.text}
            </p>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Password Saat Ini
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Password Baru
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Min. 6 karakter"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Konfirmasi Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Ulangi password"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="button"
              disabled={changingPassword}
              onClick={async () => {
                setPasswordStatus(null);
                if (!currentPassword || !newPassword) {
                  setPasswordStatus({
                    type: 'error',
                    text: 'Isi password saat ini dan password baru.',
                  });
                  return;
                }
                if (newPassword.length < 6) {
                  setPasswordStatus({
                    type: 'error',
                    text: 'Password baru minimal 6 karakter.',
                  });
                  return;
                }
                if (newPassword !== confirmPassword) {
                  setPasswordStatus({
                    type: 'error',
                    text: 'Konfirmasi password baru tidak cocok.',
                  });
                  return;
                }
                setChangingPassword(true);
                try {
                  await changeMyPassword(currentPassword, newPassword);
                  setCurrentPassword('');
                  setNewPassword('');
                  setConfirmPassword('');
                  setPasswordStatus({
                    type: 'success',
                    text: 'Password akun berhasil diperbarui.',
                  });
                } catch (err) {
                  setPasswordStatus({
                    type: 'error',
                    text:
                      err instanceof Error
                        ? err.message
                        : 'Gagal memperbarui password.',
                  });
                } finally {
                  setChangingPassword(false);
                }
              }}
              className="px-3.5 py-2 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 disabled:opacity-60 rounded-lg whitespace-nowrap shrink-0"
            >
              {changingPassword ? 'Menyimpan...' : 'Perbarui Password'}
            </button>
          </div>
        </div>

        <div className="px-6 py-5 border-t border-slate-200 bg-slate-50/70 space-y-3">
          <h3 className="text-sm font-semibold text-slate-900">
            Cadangan & Pemulihan Data Akun
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Seluruh jadwal, presensi, dan catatan materi tersimpan otomatis untuk akun Anda. Unduh cadangan JSON secara berkala bila diperlukan.
          </p>

          {feedback && (
            <p className="text-xs font-medium text-blue-700 bg-blue-50 border border-blue-200 px-3 py-2 rounded-lg">
              {feedback}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleExportJson}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              Ekspor JSON
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg whitespace-nowrap shrink-0"
            >
              <Upload className="h-3.5 w-3.5" />
              Impor JSON
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleImportJson}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => setConfirmMode('reset')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Muat Data Contoh
            </button>

            <button
              type="button"
              onClick={() => setConfirmMode('clear')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-red-700 bg-white border border-red-200 hover:bg-red-50 rounded-lg whitespace-nowrap shrink-0"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Kosongkan Data
            </button>
          </div>

          {confirmMode !== 'none' && (
            <div className="p-3 bg-white border border-slate-200 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <p className="text-xs text-slate-700">
                {confirmMode === 'reset'
                  ? 'Kembalikan seluruh data ke contoh awal? Data saat ini akan diganti.'
                  : 'Hapus seluruh kelas, jadwal, presensi, dan catatan materi?'}
              </p>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setConfirmMode('none')}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-md"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (confirmMode === 'reset') {
                      onResetToSeed();
                      setFeedback('Data contoh berhasil dimuat ulang.');
                    } else {
                      onClearAll();
                      setFeedback('Seluruh data telah dikosongkan.');
                    }
                    setConfirmMode('none');
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-md whitespace-nowrap shrink-0"
                >
                  Ya, Lanjutkan
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
