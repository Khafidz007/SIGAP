import React, { useEffect, useMemo, useState } from 'react';
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Printer,
  Download,
  X,
} from 'lucide-react';
import {
  AtpItem,
  AttendanceSession,
  Classroom,
  LessonNote,
  MaterialStatus,
  ScheduleSlot,
  Subject,
  TeacherProfile,
} from '../types/journal';
import {
  formatIndonesianDate,
  formatShortDate,
  getTodayIsoDate,
  SCHOOL_LOGO_URL,
} from '../data/seedData';
import { downloadCsv } from '../utils/exportCsv';

interface JournalHistoryViewProps {
  profile: TeacherProfile;
  classes: Classroom[];
  subjects: Subject[];
  schedules: ScheduleSlot[];
  atpItems: AtpItem[];
  attendanceSessions: AttendanceSession[];
  lessonNotes: LessonNote[];
  initialDraftContext?: {
    classId: string;
    date: string;
    scheduleSlotId?: string;
    subject?: string;
    atpId?: string;
    atpCode?: string;
    topic?: string;
    learningObjective?: string;
  } | null;
  onConsumeDraftContext?: () => void;
  onAddNote: (payload: Omit<LessonNote, 'id' | 'updatedAt'>) => void;
  onUpdateNote: (id: string, patch: Partial<Omit<LessonNote, 'id'>>) => void;
  onDeleteNote: (id: string) => void;
}

const MATERIAL_STATUSES: MaterialStatus[] = ['Tuntas', 'Berlanjut', 'Tertunda'];

export function JournalHistoryView({
  profile,
  classes,
  subjects,
  schedules,
  atpItems,
  attendanceSessions,
  lessonNotes,
  initialDraftContext,
  onConsumeDraftContext,
  onAddNote,
  onUpdateNote,
  onDeleteNote,
}: JournalHistoryViewProps) {
  const [viewMode, setViewMode] = useState<'kronologi' | 'tabel'>('kronologi');
  const [searchQuery, setSearchQuery] = useState('');
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'Semua' | MaterialStatus>('Semua');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<LessonNote | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [form, setForm] = useState<Omit<LessonNote, 'id' | 'updatedAt'>>({
    date: getTodayIsoDate(),
    scheduleSlotId: undefined,
    classId: classes[0]?.id ?? '',
    subject: subjects[0]?.name ?? profile.subject,
    atpId: undefined,
    atpCode: undefined,
    meetingNumber: 1,
    topic: '',
    learningObjective: '',
    activitySummary: '',
    homework: '',
    reflection: '',
    status: 'Tuntas',
  });

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c])),
    [classes]
  );

  const atpMap = useMemo(
    () => new Map(atpItems.map((a) => [a.id, a])),
    [atpItems]
  );

  const getSuggestedMeetingNumber = (classId: string, subject: string) => {
    const matching = lessonNotes.filter(
      (n) => n.classId === classId && n.subject.toLowerCase() === subject.toLowerCase()
    );
    if (matching.length === 0) return 1;
    return Math.max(...matching.map((m) => m.meetingNumber)) + 1;
  };

  useEffect(() => {
    if (!initialDraftContext) return;
    const existing = !initialDraftContext.atpId
      ? lessonNotes.find(
          (n) =>
            n.date === initialDraftContext.date &&
            n.classId === initialDraftContext.classId &&
            (initialDraftContext.scheduleSlotId
              ? n.scheduleSlotId === initialDraftContext.scheduleSlotId
              : true)
        )
      : undefined;

    if (existing) {
      setEditingNote(existing);
      setForm({
        date: existing.date,
        scheduleSlotId: existing.scheduleSlotId,
        classId: existing.classId,
        subject: existing.subject,
        atpId: existing.atpId,
        atpCode: existing.atpCode,
        meetingNumber: existing.meetingNumber,
        topic: existing.topic,
        learningObjective: existing.learningObjective,
        activitySummary: existing.activitySummary,
        homework: existing.homework,
        reflection: existing.reflection,
        status: existing.status,
      });
    } else {
      const subj = initialDraftContext.subject || subjects[0]?.name || profile.subject;
      setEditingNote(null);
      setForm({
        date: initialDraftContext.date,
        scheduleSlotId: initialDraftContext.scheduleSlotId,
        classId: initialDraftContext.classId,
        subject: subj,
        atpId: initialDraftContext.atpId,
        atpCode: initialDraftContext.atpCode,
        meetingNumber: getSuggestedMeetingNumber(initialDraftContext.classId, subj),
        topic: initialDraftContext.topic ?? '',
        learningObjective: initialDraftContext.learningObjective ?? '',
        activitySummary: '',
        homework: '',
        reflection: '',
        status: 'Tuntas',
      });
    }
    setDrawerOpen(true);
    onConsumeDraftContext?.();
  }, [initialDraftContext]);

  const openNewDrawer = () => {
    const firstClassId = classFilter !== 'ALL' ? classFilter : classes[0]?.id ?? '';
    const defaultSubj =
      subjectFilter !== 'ALL' ? subjectFilter : subjects[0]?.name ?? profile.subject;
    setEditingNote(null);
    setForm({
      date: getTodayIsoDate(),
      scheduleSlotId: undefined,
      classId: firstClassId,
      subject: defaultSubj,
      atpId: undefined,
      atpCode: undefined,
      meetingNumber: getSuggestedMeetingNumber(firstClassId, defaultSubj),
      topic: '',
      learningObjective: '',
      activitySummary: '',
      homework: '',
      reflection: '',
      status: 'Tuntas',
    });
    setDrawerOpen(true);
  };

  const openEditDrawer = (note: LessonNote) => {
    setEditingNote(note);
    setForm({
      date: note.date,
      scheduleSlotId: note.scheduleSlotId,
      classId: note.classId,
      subject: note.subject,
      atpId: note.atpId,
      atpCode: note.atpCode,
      meetingNumber: note.meetingNumber,
      topic: note.topic,
      learningObjective: note.learningObjective,
      activitySummary: note.activitySummary,
      homework: note.homework,
      reflection: note.reflection,
      status: note.status,
    });
    setDrawerOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.classId || !form.topic.trim()) return;
    if (editingNote) {
      onUpdateNote(editingNote.id, form);
    } else {
      onAddNote(form);
    }
    setDrawerOpen(false);
  };

  const uniqueSubjectNames = useMemo(() => {
    const names = new Set<string>();
    for (const s of subjects) names.add(s.name);
    for (const n of lessonNotes) names.add(n.subject);
    return Array.from(names).sort();
  }, [subjects, lessonNotes]);

  const findAttendanceForNote = (note: LessonNote) => {
    const sess = attendanceSessions.find(
      (a) =>
        a.date === note.date &&
        a.classId === note.classId &&
        (note.scheduleSlotId && a.scheduleSlotId
          ? a.scheduleSlotId === note.scheduleSlotId
          : true)
    );
    if (!sess) return null;
    const cls = classMap.get(note.classId);
    const entries = Object.values(sess.records);
    const H = entries.filter((e) => e.status === 'H').length;
    const I = entries.filter((e) => e.status === 'I').length;
    const S = entries.filter((e) => e.status === 'S').length;
    const A = entries.filter((e) => e.status === 'A').length;
    const absentNames = cls
      ? cls.students
          .filter((st) => {
            const stStatus = sess.records[st.id]?.status;
            return stStatus && stStatus !== 'H';
          })
          .map((st) => `${st.name} (${sess.records[st.id]?.status})`)
      : [];
    return { H, I, S, A, total: entries.length, absentNames };
  };

  const filteredNotes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return [...lessonNotes]
      .filter((n) => (classFilter === 'ALL' ? true : n.classId === classFilter))
      .filter((n) => (subjectFilter === 'ALL' ? true : n.subject === subjectFilter))
      .filter((n) => (statusFilter === 'Semua' ? true : n.status === statusFilter))
      .filter((n) => (dateFrom ? n.date >= dateFrom : true))
      .filter((n) => (dateTo ? n.date <= dateTo : true))
      .filter((n) => {
        if (!q) return true;
        return (
          n.topic.toLowerCase().includes(q) ||
          n.subject.toLowerCase().includes(q) ||
          (n.atpCode ?? '').toLowerCase().includes(q) ||
          n.activitySummary.toLowerCase().includes(q) ||
          n.reflection.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => b.date.localeCompare(a.date) || b.updatedAt.localeCompare(a.updatedAt));
  }, [
    lessonNotes,
    classFilter,
    subjectFilter,
    statusFilter,
    dateFrom,
    dateTo,
    searchQuery,
  ]);

  const handleExportNotesCsv = () => {
    const headers = [
      'Tanggal',
      'Kelas',
      'Mata Pelajaran',
      'Kode TP / ATP',
      'Pertemuan Ke',
      'Pokok Bahasan / Materi',
      'Tujuan Pembelajaran',
      'Ringkasan Kegiatan',
      'Tugas / PR',
      'Refleksi & Tindak Lanjut',
      'Kehadiran (H/I/S/A)',
      'Status',
    ];
    const rows = filteredNotes.map((n) => {
      const att = findAttendanceForNote(n);
      const attStr = att ? `${att.H}/${att.I}/${att.S}/${att.A}` : 'Belum diisi';
      return [
        n.date,
        classMap.get(n.classId)?.name ?? '',
        n.subject,
        n.atpCode ?? '-',
        n.meetingNumber,
        n.topic,
        n.learningObjective,
        n.activitySummary,
        n.homework,
        n.reflection,
        attStr,
        n.status,
      ];
    });
    downloadCsv(`riwayat-jurnal-mengajar-${getTodayIsoDate()}.csv`, headers, rows);
  };

  const classSchedules = useMemo(
    () => schedules.filter((s) => s.classId === form.classId),
    [schedules, form.classId]
  );

  const matchingAtpList = useMemo(() => {
    return atpItems.filter(
      (a) =>
        !form.subject ||
        a.subjectName.toLowerCase() === form.subject.toLowerCase()
    );
  }, [atpItems, form.subject]);

  return (
    <div className="space-y-6">
      <div className="hidden print:flex items-center gap-4 pb-4 border-b border-slate-300">
        <img
          src={profile.schoolLogoUrl || SCHOOL_LOGO_URL}
          alt={`Logo ${profile.school}`}
          referrerPolicy="no-referrer"
          className="h-14 w-14 object-contain shrink-0"
        />
        <div>
          <p className="font-display text-sm font-bold uppercase tracking-wide text-slate-800">
            {profile.school}
          </p>
          <h1 className="font-display text-xl font-bold text-slate-900">
            Riwayat Jurnal Mengajar Guru
          </h1>
          <p className="text-xs text-slate-700 mt-0.5">
            {profile.name} (NIP. {profile.nip}) · Semester {profile.semester}{' '}
            {profile.academicYear}
          </p>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4 no-print">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 flex-1">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setViewMode('kronologi')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  viewMode === 'kronologi'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Kronologi Jurnal
              </button>
              <button
                type="button"
                onClick={() => setViewMode('tabel')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  viewMode === 'tabel'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Tabel Riwayat
              </button>
            </div>

            <div className="relative flex-1 min-w-[200px] max-w-xs">
              <Search className="h-3.5 w-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari materi, kode TP, atau refleksi..."
                className="w-full pl-8 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            <select
              aria-label="Filter kelas"
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-blue-600"
            >
              <option value="ALL">Semua Kelas</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  Kelas {c.name}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter mata pelajaran"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-blue-600"
            >
              <option value="ALL">Semua Mapel</option>
              {uniqueSubjectNames.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => window.print()}
              disabled={filteredNotes.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
            >
              <Printer className="h-3.5 w-3.5" />
              Cetak
            </button>
            <button
              type="button"
              onClick={handleExportNotesCsv}
              disabled={filteredNotes.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              Ekspor CSV
            </button>
            <button
              type="button"
              onClick={openNewDrawer}
              disabled={classes.length === 0}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 rounded-lg whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              Catat Jurnal Baru
            </button>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <span>Dari:</span>
              <input
                type="date"
                aria-label="Tanggal mulai"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg bg-white"
              />
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <span>Sampai:</span>
              <input
                type="date"
                aria-label="Tanggal akhir"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="px-2.5 py-1.5 text-xs font-mono border border-slate-200 rounded-lg bg-white"
              />
            </div>
            {(dateFrom || dateTo || classFilter !== 'ALL' || subjectFilter !== 'ALL' || statusFilter !== 'Semua' || searchQuery) && (
              <button
                type="button"
                onClick={() => {
                  setDateFrom('');
                  setDateTo('');
                  setClassFilter('ALL');
                  setSubjectFilter('ALL');
                  setStatusFilter('Semua');
                  setSearchQuery('');
                }}
                className="text-xs font-medium text-blue-700 hover:underline"
              >
                Reset filter
              </button>
            )}
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(['Semua', ...MATERIAL_STATUSES] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === st
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {filteredNotes.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <p className="text-sm font-medium text-slate-900">
            Belum ada riwayat jurnal mengajar yang sesuai.
          </p>
          <p className="text-xs text-slate-500 mt-1">
            {classes.length === 0
              ? 'Buat kelas terlebih dahulu di menu Pelajaran & Kelas.'
              : 'Klik "Catat Jurnal Baru" untuk mendokumentasikan materi, ATP, dan refleksi pembelajaran.'}
          </p>
          {classes.length > 0 && (
            <button
              type="button"
              onClick={openNewDrawer}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              Catat Jurnal Pertama
            </button>
          )}
        </div>
      ) : viewMode === 'tabel' ? (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500">
                  <th className="py-3 pl-5 pr-2 w-28">Tanggal</th>
                  <th className="py-3 px-2 w-24">Kelas</th>
                  <th className="py-3 px-2 w-40">Mata Pelajaran</th>
                  <th className="py-3 px-2 w-20">Kode TP</th>
                  <th className="py-3 px-2 w-16 text-center">Pert.</th>
                  <th className="py-3 px-2 min-w-[220px]">Pokok Bahasan</th>
                  <th className="py-3 px-2 w-32">Presensi (H/I/S/A)</th>
                  <th className="py-3 px-2 w-24">Status</th>
                  <th className="py-3 pl-2 pr-5 w-20 text-right no-print">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredNotes.map((note) => {
                  const cls = classMap.get(note.classId);
                  const att = findAttendanceForNote(note);
                  const statusColor =
                    note.status === 'Tuntas'
                      ? 'text-emerald-700'
                      : note.status === 'Berlanjut'
                      ? 'text-blue-700'
                      : 'text-amber-700';

                  return (
                    <tr key={note.id} className="hover:bg-slate-50/70 align-top">
                      <td className="py-3 pl-5 pr-2 text-slate-700 tabular-nums whitespace-nowrap">
                        {formatShortDate(note.date)}
                      </td>
                      <td className="py-3 px-2 font-semibold text-slate-900">
                        {cls?.name ?? 'Kelas'}
                      </td>
                      <td className="py-3 px-2 text-slate-700">{note.subject}</td>
                      <td className="py-3 px-2 font-mono text-blue-700">
                        {note.atpCode || '—'}
                      </td>
                      <td className="py-3 px-2 text-center font-mono text-slate-700 tabular-nums">
                        {note.meetingNumber}
                      </td>
                      <td className="py-3 px-2">
                        <p className="font-medium text-slate-900">{note.topic}</p>
                        {note.homework && (
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            Tugas: {note.homework}
                          </p>
                        )}
                      </td>
                      <td className="py-3 px-2 font-mono text-slate-700 tabular-nums whitespace-nowrap">
                        {att ? `${att.H} / ${att.I} / ${att.S} / ${att.A}` : 'Belum diisi'}
                      </td>
                      <td className={`py-3 px-2 font-semibold ${statusColor}`}>
                        {note.status}
                      </td>
                      <td className="py-3 pl-2 pr-5 text-right no-print">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openEditDrawer(note)}
                            aria-label="Edit jurnal"
                            className="p-1 text-slate-400 hover:text-slate-700"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(note.id)}
                            aria-label="Hapus jurnal"
                            className="p-1 text-slate-400 hover:text-red-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
          {filteredNotes.map((note) => {
            const cls = classMap.get(note.classId);
            const att = findAttendanceForNote(note);
            const statusTextClass =
              note.status === 'Tuntas'
                ? 'text-emerald-700'
                : note.status === 'Berlanjut'
                ? 'text-blue-700'
                : 'text-amber-700';

            return (
              <article key={note.id} className="p-6 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                      <span className="font-semibold text-slate-900">
                        {cls?.name ?? 'Kelas'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{note.subject}</span>
                      {note.atpCode && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono font-semibold text-blue-700">
                            {note.atpCode}
                          </span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums font-medium text-slate-700">
                        Pertemuan ke-{note.meetingNumber}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{formatIndonesianDate(note.date)}</span>
                      <span aria-hidden="true">·</span>
                      <span className={`font-semibold ${statusTextClass}`}>
                        {note.status}
                      </span>
                    </div>
                    <h3 className="font-display text-base font-semibold text-slate-900">
                      {note.topic}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1 shrink-0 no-print">
                    <button
                      type="button"
                      onClick={() => openEditDrawer(note)}
                      aria-label="Edit catatan jurnal"
                      className="p-2 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(note.id)}
                      aria-label="Hapus catatan jurnal"
                      className="p-2 text-slate-400 hover:text-red-600 rounded-lg"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {confirmDeleteId === note.id && (
                  <div className="flex items-center justify-between gap-2 bg-red-50 border border-red-200 px-3.5 py-2.5 rounded-lg no-print">
                    <span className="text-xs text-red-800">
                      Hapus catatan jurnal pertemuan ke-{note.meetingNumber} ini?
                    </span>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-2.5 py-1 text-xs font-medium text-slate-600"
                      >
                        Batal
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteNote(note.id);
                          setConfirmDeleteId(null);
                        }}
                        className="px-2.5 py-1 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded"
                      >
                        Hapus
                      </button>
                    </div>
                  </div>
                )}

                {att && (
                  <div className="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded-lg px-3.5 py-2 flex flex-wrap items-center gap-x-3 gap-y-1 tabular-nums">
                    <span className="font-semibold text-slate-800">
                      Presensi Pertemuan:
                    </span>
                    <span className="text-emerald-700 font-medium">
                      Hadir {att.H}
                    </span>
                    <span className="text-sky-700">Izin {att.I}</span>
                    <span className="text-amber-700">Sakit {att.S}</span>
                    <span className="text-red-700">Alpa {att.A}</span>
                    {att.absentNames.length > 0 && (
                      <span className="text-slate-500">
                        · Tidak hadir: {att.absentNames.join(', ')}
                      </span>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 text-xs leading-relaxed">
                  {note.learningObjective && (
                    <div>
                      <p className="font-semibold text-slate-700 mb-0.5">
                        Tujuan Pembelajaran
                      </p>
                      <p className="text-slate-600">{note.learningObjective}</p>
                    </div>
                  )}
                  {note.activitySummary && (
                    <div>
                      <p className="font-semibold text-slate-700 mb-0.5">
                        Ringkasan Kegiatan & Penyampaian
                      </p>
                      <p className="text-slate-600">{note.activitySummary}</p>
                    </div>
                  )}
                  {note.homework && (
                    <div>
                      <p className="font-semibold text-slate-700 mb-0.5">
                        Penugasan / PR
                      </p>
                      <p className="text-slate-600">{note.homework}</p>
                    </div>
                  )}
                  {note.reflection && (
                    <div>
                      <p className="font-semibold text-slate-700 mb-0.5">
                        Refleksi & Tindak Lanjut
                      </p>
                      <p className="text-slate-600">{note.reflection}</p>
                    </div>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}

      {drawerOpen && (
        <div
          className="fixed inset-0 z-50 flex justify-end bg-slate-900/45 no-print"
          role="dialog"
          aria-modal="true"
          aria-labelledby="note-drawer-title"
        >
          <div className="w-full max-w-xl bg-white h-full overflow-y-auto border-l border-slate-200 shadow-xl flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 sticky top-0 bg-white z-10">
              <h2
                id="note-drawer-title"
                className="font-display text-base font-semibold text-slate-900"
              >
                {editingNote ? 'Edit Catatan Jurnal' : 'Catat Jurnal Mengajar'}
              </h2>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                aria-label="Tutup form catatan jurnal"
                className="p-2 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tanggal Mengajar
                  </label>
                  <input
                    type="date"
                    required
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Kelas
                  </label>
                  <select
                    required
                    value={form.classId}
                    onChange={(e) => {
                      const nextClassId = e.target.value;
                      setForm({
                        ...form,
                        classId: nextClassId,
                        meetingNumber: editingNote
                          ? form.meetingNumber
                          : getSuggestedMeetingNumber(nextClassId, form.subject),
                      });
                    }}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Mata Pelajaran
                  </label>
                  {subjects.length > 0 ? (
                    <select
                      value={form.subject}
                      onChange={(e) =>
                        setForm({ ...form, subject: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                    >
                      {subjects.map((s) => (
                        <option key={s.id} value={s.name}>
                          {s.name}
                        </option>
                      ))}
                      {!subjects.some((s) => s.name === form.subject) &&
                        form.subject && (
                          <option value={form.subject}>{form.subject}</option>
                        )}
                    </select>
                  ) : (
                    <input
                      type="text"
                      required
                      value={form.subject}
                      onChange={(e) =>
                        setForm({ ...form, subject: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Pertemuan Ke-
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={form.meetingNumber}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        meetingNumber: Math.max(1, Number(e.target.value) || 1),
                      })
                    }
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              {matchingAtpList.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tautkan ATP / Tujuan Pembelajaran (Opsional)
                  </label>
                  <select
                    value={form.atpId ?? ''}
                    onChange={(e) => {
                      const atpId = e.target.value || undefined;
                      const chosen = atpId ? atpMap.get(atpId) : undefined;
                      setForm({
                        ...form,
                        atpId,
                        atpCode: chosen?.code,
                        learningObjective: chosen
                          ? chosen.objective
                          : form.learningObjective,
                        topic:
                          chosen && !form.topic
                            ? chosen.materials[0] ?? chosen.element
                            : form.topic,
                      });
                    }}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    <option value="">Tidak ditautkan ke ATP tertentu</option>
                    {matchingAtpList.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.code} · {a.element} — {a.objective.slice(0, 65)}...
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {classSchedules.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tautkan dengan Jadwal Mengajar (Opsional)
                  </label>
                  <select
                    value={form.scheduleSlotId ?? ''}
                    onChange={(e) => {
                      const slotId = e.target.value || undefined;
                      const slot = classSchedules.find((s) => s.id === slotId);
                      setForm({
                        ...form,
                        scheduleSlotId: slotId,
                        subject: slot ? slot.subject : form.subject,
                      });
                    }}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    <option value="">Tidak ditautkan ke slot tertentu</option>
                    {classSchedules.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.day}, {s.startTime}–{s.endTime} · {s.subject}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Pokok Bahasan / Judul Materi
                </label>
                <input
                  type="text"
                  required
                  value={form.topic}
                  onChange={(e) => setForm({ ...form, topic: e.target.value })}
                  placeholder="Contoh: Sistem Pertidaksamaan Linear Dua Variabel"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Tujuan Pembelajaran
                </label>
                <textarea
                  rows={2}
                  value={form.learningObjective}
                  onChange={(e) =>
                    setForm({ ...form, learningObjective: e.target.value })
                  }
                  placeholder="Capaian atau indikator yang ditargetkan pada pertemuan ini..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Ringkasan Kegiatan & Materi
                </label>
                <textarea
                  rows={3}
                  value={form.activitySummary}
                  onChange={(e) =>
                    setForm({ ...form, activitySummary: e.target.value })
                  }
                  placeholder="Metode pembelajaran, media/LKPD yang digunakan, atau poin penting materi..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Penugasan / PR Siswa
                </label>
                <input
                  type="text"
                  value={form.homework}
                  onChange={(e) => setForm({ ...form, homework: e.target.value })}
                  placeholder="Contoh: Latihan halaman 118 No. 1–5 dikumpulkan Rabu"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Refleksi & Catatan Tindak Lanjut
                </label>
                <textarea
                  rows={2}
                  value={form.reflection}
                  onChange={(e) =>
                    setForm({ ...form, reflection: e.target.value })
                  }
                  placeholder="Kendala kelas, siswa yang perlu pendampingan, atau batas materi untuk pertemuan berikutnya..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Status Ketuntasan Materi
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {MATERIAL_STATUSES.map((st) => {
                    const active = form.status === st;
                    return (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setForm({ ...form, status: st })}
                        className={`py-2 px-3 text-xs font-medium rounded-lg border transition-colors ${
                          active
                            ? 'bg-blue-700 border-blue-700 text-white'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {st}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2 sticky bottom-0 bg-white pb-2">
                <button
                  type="button"
                  onClick={() => setDrawerOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
                >
                  {editingNote ? 'Simpan Perubahan' : 'Simpan Jurnal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
