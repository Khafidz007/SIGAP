import * as XLSX from 'xlsx';
import { Classroom, Student, Subject } from '../types/journal';

export interface ParsedClassWithStudents
  extends Omit<Classroom, 'id' | 'students'> {
  students: Omit<Student, 'id'>[];
}

export interface ExcelParseResult {
  fileName: string;
  sheetNames: string[];
  subjects: Omit<Subject, 'id'>[];
  classes: ParsedClassWithStudents[];
  unassignedStudents: Omit<Student, 'id'>[];
  warnings: string[];
}

function normalizeHeader(value: unknown): string {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/[_/.-]+/g, ' ')
    .replace(/\s+/g, ' ');
}

function cellStr(value: unknown): string {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

function cellNum(value: unknown, fallback: number): number {
  if (typeof value === 'number' && !Number.isNaN(value)) return value;
  const cleaned = String(value ?? '').replace(/[^\d.-]/g, '');
  const n = Number(cleaned);
  return cleaned !== '' && !Number.isNaN(n) ? n : fallback;
}

function normalizeGender(value: unknown): 'L' | 'P' {
  const v = cellStr(value).toUpperCase();
  if (
    v === 'P' ||
    v === 'PR' ||
    v === 'PEREMPUAN' ||
    v === 'WANITA' ||
    v === 'FEMALE' ||
    v === 'F'
  ) {
    return 'P';
  }
  return 'L';
}

function inferGradeFromClassName(className: string): string {
  const upper = className.trim().toUpperCase();
  if (upper.startsWith('XII')) return 'XII';
  if (upper.startsWith('XI')) return 'XI';
  if (upper.startsWith('X')) return 'X';
  if (upper.startsWith('12')) return 'XII';
  if (upper.startsWith('11')) return 'XI';
  if (upper.startsWith('10')) return 'X';
  return 'X';
}

function findColumnKey(
  headers: string[],
  aliases: string[]
): string | undefined {
  // Exact match first
  for (const alias of aliases) {
    const idx = headers.findIndex((h) => h === alias);
    if (idx >= 0) return headers[idx];
  }
  // Substring match
  for (const alias of aliases) {
    const idx = headers.findIndex((h) => h.includes(alias));
    if (idx >= 0) return headers[idx];
  }
  return undefined;
}

function sheetToNormalizedRows(
  sheet: XLSX.WorkSheet
): { headers: string[]; rows: Record<string, unknown>[] } {
  const matrix = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
    header: 1,
    defval: '',
    blankrows: false,
  });

  if (matrix.length === 0) {
    return { headers: [], rows: [] };
  }

  // Find the first non-empty row that looks like a header (at least 2 non-empty cells or 1 text cell)
  let headerRowIdx = 0;
  for (let i = 0; i < Math.min(matrix.length, 6); i++) {
    const row = matrix[i] ?? [];
    const nonEmpty = row.filter((c) => cellStr(c) !== '').length;
    if (nonEmpty >= 2) {
      headerRowIdx = i;
      break;
    }
  }

  const rawHeaders = matrix[headerRowIdx] ?? [];
  const headers: string[] = rawHeaders.map((h, idx) => {
    const norm = normalizeHeader(h);
    return norm || `kolom_${idx}`;
  });

  const rows: Record<string, unknown>[] = [];
  for (let i = headerRowIdx + 1; i < matrix.length; i++) {
    const rawRow = matrix[i] ?? [];
    const hasAnyValue = rawRow.some((c) => cellStr(c) !== '');
    if (!hasAnyValue) continue;
    const obj: Record<string, unknown> = {};
    headers.forEach((key, colIdx) => {
      obj[key] = rawRow[colIdx] ?? '';
    });
    rows.push(obj);
  }

  return { headers, rows };
}

export async function parseExcelWorkbook(file: File): Promise<ExcelParseResult> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });

  const subjects: Omit<Subject, 'id'>[] = [];
  const classMap = new Map<string, ParsedClassWithStudents>();
  const unassignedStudents: Omit<Student, 'id'>[] = [];
  const warnings: string[] = [];

  const getOrCreateClass = (
    name: string,
    patch?: Partial<Omit<Classroom, 'id' | 'students'>>
  ): ParsedClassWithStudents => {
    const trimmed = name.trim();
    const key = trimmed.toLowerCase();
    const existing = classMap.get(key);
    if (existing) {
      if (patch?.grade && !existing.grade) existing.grade = patch.grade;
      if (patch?.major && existing.major === 'Umum') existing.major = patch.major;
      if (patch?.room && !existing.room) existing.room = patch.room;
      if (patch?.homeroomTeacher && !existing.homeroomTeacher) {
        existing.homeroomTeacher = patch.homeroomTeacher;
      }
      return existing;
    }
    const created: ParsedClassWithStudents = {
      name: trimmed,
      grade: patch?.grade?.trim() || inferGradeFromClassName(trimmed),
      major: patch?.major?.trim() || 'Umum',
      room: patch?.room?.trim() || '',
      homeroomTeacher: patch?.homeroomTeacher?.trim() || '',
      students: [],
    };
    classMap.set(key, created);
    return created;
  };

  let generatedNisCounter = 261001;

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) continue;
    const { headers, rows } = sheetToNormalizedRows(sheet);
    if (headers.length === 0 || rows.length === 0) continue;

    const lowerSheet = sheetName.toLowerCase();

    const subjNameKey = findColumnKey(headers, [
      'nama mata pelajaran',
      'mata pelajaran',
      'nama mapel',
      'nama pelajaran',
      'mapel',
      'subject',
    ]);
    const subjCodeKey = findColumnKey(headers, [
      'kode guru',
      'kd guru',
      'kode pengajar',
      'kode mapel',
      'kode pelajaran',
      'kode',
      'code',
    ]);
    const kktpKey = findColumnKey(headers, ['kktp', 'kkm', 'nilai minimal']);
    const jpKey = findColumnKey(headers, [
      'jp minggu',
      'jp per minggu',
      'jam minggu',
      'jp',
      'alokasi jp',
      'weekly hours',
    ]);
    const phaseKey = findColumnKey(headers, [
      'tingkat fase',
      'fase',
      'tingkat',
      'grade level',
    ]);
    const descKey = findColumnKey(headers, [
      'deskripsi',
      'keterangan',
      'ruang lingkup',
      'description',
    ]);

    const classNameKey = findColumnKey(headers, [
      'nama kelas',
      'kelas',
      'rombel',
      'rombongan belajar',
      'class',
    ]);
    const gradeKey = findColumnKey(headers, ['tingkat', 'jenjang', 'grade']);
    const majorKey = findColumnKey(headers, [
      'jurusan',
      'program',
      'peminatan',
      'major',
    ]);
    const roomKey = findColumnKey(headers, ['ruang kelas', 'ruang', 'room']);
    const homeroomKey = findColumnKey(headers, [
      'wali kelas',
      'walas',
      'homeroom',
    ]);

    const studentNameKey = findColumnKey(headers, [
      'nama siswa',
      'nama lengkap siswa',
      'nama lengkap',
      'nama peserta didik',
      'peserta didik',
      'siswa',
      'student name',
      ...(lowerSheet.includes('siswa') ||
      lowerSheet.includes('murid') ||
      lowerSheet.includes('student')
        ? ['nama']
        : []),
    ]);
    const nisKey = findColumnKey(headers, ['nisn', 'nis', 'nomor induk']);
    const genderKey = findColumnKey(headers, [
      'l p',
      'lp',
      'jenis kelamin',
      'jk',
      'kelamin',
      'gender',
    ]);

    const isSubjectSheet =
      lowerSheet.includes('mapel') ||
      lowerSheet.includes('pelajaran') ||
      lowerSheet.includes('subject') ||
      Boolean(subjNameKey && (subjCodeKey || kktpKey || jpKey));

    const isStudentSheet =
      lowerSheet.includes('siswa') ||
      lowerSheet.includes('murid') ||
      lowerSheet.includes('student') ||
      Boolean(studentNameKey || (nisKey && genderKey));

    const isClassSheet =
      !isStudentSheet &&
      (lowerSheet.includes('kelas') ||
        lowerSheet.includes('rombel') ||
        lowerSheet.includes('class') ||
        Boolean(classNameKey && !subjNameKey));

    if (isSubjectSheet) {
      const nameCol = subjNameKey || findColumnKey(headers, ['nama']);
      if (!nameCol) {
        warnings.push(
          `Sheet "${sheetName}" terdeteksi sebagai Mata Pelajaran tetapi kolom "Nama Mata Pelajaran" tidak ditemukan.`
        );
      } else {
        rows.forEach((row, idx) => {
          const name = cellStr(row[nameCol]);
          if (!name) return;
          const code =
            (subjCodeKey ? cellStr(row[subjCodeKey]) : '') ||
            `GR-${String(subjects.length + idx + 1).padStart(2, '0')}`;
          const gradeLevel =
            (phaseKey ? cellStr(row[phaseKey]) : '') || 'X (Fase E)';
          const kktp = Math.min(
            100,
            Math.max(0, cellNum(kktpKey ? row[kktpKey] : undefined, 75))
          );
          const weeklyHours = Math.max(
            1,
            cellNum(jpKey ? row[jpKey] : undefined, 2)
          );
          const description = descKey ? cellStr(row[descKey]) : '';
          subjects.push({
            code: code.toUpperCase(),
            name,
            gradeLevel,
            kktp,
            weeklyHours,
            description,
          });
        });
      }
      continue;
    }

    if (isClassSheet) {
      if (!classNameKey) {
        warnings.push(
          `Sheet "${sheetName}" terdeteksi sebagai Kelas tetapi kolom "Nama Kelas" tidak ditemukan.`
        );
      } else {
        rows.forEach((row) => {
          const clsName = cellStr(row[classNameKey]);
          if (!clsName) return;
          getOrCreateClass(clsName, {
            grade: gradeKey ? cellStr(row[gradeKey]) : undefined,
            major: majorKey ? cellStr(row[majorKey]) : undefined,
            room: roomKey ? cellStr(row[roomKey]) : undefined,
            homeroomTeacher: homeroomKey ? cellStr(row[homeroomKey]) : undefined,
          });
        });
      }
      continue;
    }

    if (isStudentSheet) {
      const nameCol = studentNameKey || findColumnKey(headers, ['nama']);
      if (!nameCol) {
        warnings.push(
          `Sheet "${sheetName}" terdeteksi sebagai Siswa tetapi kolom "Nama Siswa" tidak ditemukan.`
        );
        continue;
      }

      let missingClassInRow = 0;
      rows.forEach((row) => {
        const studentName = cellStr(row[nameCol]);
        if (!studentName) return;
        const nisVal = nisKey ? cellStr(row[nisKey]) : '';
        const nis = nisVal || String(generatedNisCounter++);
        const gender = normalizeGender(genderKey ? row[genderKey] : 'L');
        const clsName = classNameKey ? cellStr(row[classNameKey]) : '';

        if (clsName) {
          const targetClass = getOrCreateClass(clsName, {
            grade: gradeKey ? cellStr(row[gradeKey]) : undefined,
            major: majorKey ? cellStr(row[majorKey]) : undefined,
            room: roomKey ? cellStr(row[roomKey]) : undefined,
            homeroomTeacher: homeroomKey ? cellStr(row[homeroomKey]) : undefined,
          });
          targetClass.students.push({ nis, name: studentName, gender });
        } else {
          missingClassInRow++;
          unassignedStudents.push({ nis, name: studentName, gender });
        }
      });

      if (missingClassInRow > 0) {
        warnings.push(
          `${missingClassInRow} siswa pada sheet "${sheetName}" tidak memiliki kolom "Nama Kelas" dan akan dimasukkan ke kelas tujuan yang dipilih.`
        );
      }
      continue;
    }

    warnings.push(
      `Sheet "${sheetName}" tidak cocok dengan format kolom Mata Pelajaran, Kelas, atau Siswa sehingga dilewati.`
    );
  }

  return {
    fileName: file.name,
    sheetNames: workbook.SheetNames,
    subjects,
    classes: Array.from(classMap.values()),
    unassignedStudents,
    warnings,
  };
}

export function downloadExcelTemplate(): void {
  const wb = XLSX.utils.book_new();

  const subjectRows = [
    {
      'Kode Guru': 'GR-01',
      'Nama Mata Pelajaran': 'Matematika Wajib',
      'Tingkat / Fase': 'X (Fase E)',
      KKTP: 75,
      'JP/Minggu': 4,
      Deskripsi: 'Eksponen, logaritma, barisan dan deret, serta trigonometri dasar.',
    },
    {
      'Kode Guru': 'GR-01',
      'Nama Mata Pelajaran': 'Matematika Tingkat Lanjut',
      'Tingkat / Fase': 'XI (Fase F)',
      KKTP: 78,
      'JP/Minggu': 5,
      Deskripsi: 'Polinomial, matriks, transformasi geometri, dan fungsi lanjutan.',
    },
  ];

  const classRows = [
    {
      'Nama Kelas': 'X-1',
      Tingkat: 'X',
      Jurusan: 'Fase E Umum',
      Ruang: 'R. 101',
      'Wali Kelas': 'Dra. Siti Aminah',
    },
    {
      'Nama Kelas': 'X-2',
      Tingkat: 'X',
      Jurusan: 'Fase E Umum',
      Ruang: 'R. 102',
      'Wali Kelas': 'Ahmad Fauzi, S.Pd.',
    },
  ];

  const studentRows = [
    {
      'Nama Kelas': 'X-1',
      NIS: '261001',
      'Nama Lengkap': 'Aditya Pratama',
      'L/P': 'L',
    },
    {
      'Nama Kelas': 'X-1',
      NIS: '261002',
      'Nama Lengkap': 'Aulia Rahmawati',
      'L/P': 'P',
    },
    {
      'Nama Kelas': 'X-2',
      NIS: '261003',
      'Nama Lengkap': 'Bagus Setiawan',
      'L/P': 'L',
    },
    {
      'Nama Kelas': 'X-2',
      NIS: '261004',
      'Nama Lengkap': 'Citra Lestari',
      'L/P': 'P',
    },
  ];

  const wsSubjects = XLSX.utils.json_to_sheet(subjectRows);
  wsSubjects['!cols'] = [
    { wch: 14 },
    { wch: 28 },
    { wch: 16 },
    { wch: 8 },
    { wch: 12 },
    { wch: 48 },
  ];

  const wsClasses = XLSX.utils.json_to_sheet(classRows);
  wsClasses['!cols'] = [
    { wch: 14 },
    { wch: 10 },
    { wch: 18 },
    { wch: 12 },
    { wch: 24 },
  ];

  const wsStudents = XLSX.utils.json_to_sheet(studentRows);
  wsStudents['!cols'] = [
    { wch: 14 },
    { wch: 14 },
    { wch: 28 },
    { wch: 8 },
  ];

  XLSX.utils.book_append_sheet(wb, wsSubjects, 'Mata Pelajaran');
  XLSX.utils.book_append_sheet(wb, wsClasses, 'Kelas');
  XLSX.utils.book_append_sheet(wb, wsStudents, 'Siswa');

  XLSX.writeFile(wb, 'Template-Pelajaran-Kelas-SIGAP.xlsx');
}

export function exportSubjectsClassesToExcel(
  subjects: Subject[],
  classes: Classroom[]
): void {
  const wb = XLSX.utils.book_new();

  const subjectRows = subjects.map((s) => ({
    'Kode Guru': s.code,
    'Nama Mata Pelajaran': s.name,
    'Tingkat / Fase': s.gradeLevel,
    KKTP: s.kktp,
    'JP/Minggu': s.weeklyHours,
    Deskripsi: s.description,
  }));

  const classRows = classes.map((c) => ({
    'Nama Kelas': c.name,
    Tingkat: c.grade,
    Jurusan: c.major,
    Ruang: c.room,
    'Wali Kelas': c.homeroomTeacher ?? '',
  }));

  const studentRows = classes.flatMap((c) =>
    c.students.map((st) => ({
      'Nama Kelas': c.name,
      NIS: st.nis,
      'Nama Lengkap': st.name,
      'L/P': st.gender,
    }))
  );

  const wsSubjects = XLSX.utils.json_to_sheet(
    subjectRows.length > 0
      ? subjectRows
      : [
          {
            'Kode Guru': '',
            'Nama Mata Pelajaran': '',
            'Tingkat / Fase': '',
            KKTP: 75,
            'JP/Minggu': 2,
            Deskripsi: '',
          },
        ]
  );
  const wsClasses = XLSX.utils.json_to_sheet(
    classRows.length > 0
      ? classRows
      : [
          {
            'Nama Kelas': '',
            Tingkat: '',
            Jurusan: '',
            Ruang: '',
            'Wali Kelas': '',
          },
        ]
  );
  const wsStudents = XLSX.utils.json_to_sheet(
    studentRows.length > 0
      ? studentRows
      : [
          {
            'Nama Kelas': '',
            NIS: '',
            'Nama Lengkap': '',
            'L/P': '',
          },
        ]
  );

  XLSX.utils.book_append_sheet(wb, wsSubjects, 'Mata Pelajaran');
  XLSX.utils.book_append_sheet(wb, wsClasses, 'Kelas');
  XLSX.utils.book_append_sheet(wb, wsStudents, 'Siswa');

  XLSX.writeFile(
    wb,
    `Data-Pelajaran-Kelas-SIGAP-${new Date().toISOString().slice(0, 10)}.xlsx`
  );
}
