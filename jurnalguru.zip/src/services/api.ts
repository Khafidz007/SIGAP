import {
  CalendarReminder,
  JournalState,
  UserAccount,
  UserRole,
} from '../types/journal';

const TOKEN_STORAGE_KEY = 'jurnalguru_auth_token_v1';

export function getAuthToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setAuthToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_STORAGE_KEY, token);
  } catch {
    // ignore storage errors
  }
}

export function clearAuthToken(): void {
  try {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  } catch {
    // ignore
  }
}

async function apiRequest<T>(
  url: string,
  options: RequestInit = {},
  withAuth = true
): Promise<T> {
  const headers = new Headers(options.headers);
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (withAuth) {
    const token = getAuthToken();
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }
  }

  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message =
      (data as { error?: string })?.error ||
      `Permintaan gagal (${res.status})`;
    throw new Error(message);
  }
  return data as T;
}

export interface PublicOverviewResponse {
  schoolName: string;
  schoolLogoUrl: string;
  activeTeachers: number;
  schoolReminders: CalendarReminder[];
}

export function fetchPublicOverview(): Promise<PublicOverviewResponse> {
  return apiRequest<PublicOverviewResponse>('/api/public/overview', {}, false);
}

export function loginWithCredentials(
  username: string,
  password: string
): Promise<{ token: string; user: UserAccount }> {
  return apiRequest<{ token: string; user: UserAccount }>(
    '/api/auth/login',
    {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    },
    false
  );
}

export function fetchCurrentUser(): Promise<{ user: UserAccount }> {
  return apiRequest<{ user: UserAccount }>('/api/auth/me');
}

export function changeMyPassword(
  currentPassword: string,
  newPassword: string
): Promise<{ ok: boolean }> {
  return apiRequest<{ ok: boolean }>('/api/auth/change-password', {
    method: 'POST',
    body: JSON.stringify({ currentPassword, newPassword }),
  });
}

export function fetchUserJournal(): Promise<{ journal: JournalState }> {
  return apiRequest<{ journal: JournalState }>('/api/journal');
}

export function saveUserJournal(journal: JournalState): Promise<{ ok: boolean }> {
  return apiRequest<{ ok: boolean }>('/api/journal', {
    method: 'PUT',
    body: JSON.stringify({ journal }),
  });
}

export function fetchCalendarEvents(): Promise<{ events: CalendarReminder[] }> {
  return apiRequest<{ events: CalendarReminder[] }>('/api/calendar');
}

export function createCalendarEvent(payload: {
  date: string;
  time?: string;
  title: string;
  description: string;
  scope: 'sekolah' | 'pribadi';
  category: CalendarReminder['category'];
}): Promise<{ event: CalendarReminder }> {
  return apiRequest<{ event: CalendarReminder }>('/api/calendar', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function deleteCalendarEvent(id: string): Promise<{ ok: boolean }> {
  return apiRequest<{ ok: boolean }>(`/api/calendar/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
}

export function fetchUsers(): Promise<{ users: UserAccount[] }> {
  return apiRequest<{ users: UserAccount[] }>('/api/users');
}

export function createUserAccount(payload: {
  username: string;
  password: string;
  name: string;
  nip: string;
  subject: string;
  role: UserRole;
}): Promise<{ user: UserAccount }> {
  return apiRequest<{ user: UserAccount }>('/api/users', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function updateUserAccount(
  id: string,
  patch: {
    name?: string;
    nip?: string;
    subject?: string;
    role?: UserRole;
    active?: boolean;
    newPassword?: string;
  }
): Promise<{ user: UserAccount }> {
  return apiRequest<{ user: UserAccount }>(
    `/api/users/${encodeURIComponent(id)}`,
    {
      method: 'PATCH',
      body: JSON.stringify(patch),
    }
  );
}

export function deleteUserAccount(id: string): Promise<{ ok: boolean }> {
  return apiRequest<{ ok: boolean }>(`/api/users/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
}
