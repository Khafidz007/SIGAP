import React, { useMemo, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  Search,
  BookOpenCheck,
  Download,
  X,
} from 'lucide-react';
import {
  AtpItem,
  AtpStatus,
  LessonNote,
  Subject,
} from '../types/journal';
import { getTodayIsoDate } from '../data/seedData';
import { downloadCsv } from '../utils/exportCsv';

interface AtpMaterialsViewProps {
  subjects: Subject[];
  atpItems: AtpItem[];
  lessonNotes: LessonNote[];
  defaultSemester: 'Ganjil' | 'Genap';
  onAddAtp: (payload: Omit<AtpItem, 'id'>) => string;
  onUpdateAtp: (id: string, patch: Partial<Omit<AtpItem, 'id'>>) => void;
  onDeleteAtp: (id: string) => void;
  onCreateJournalFromAtp: (atp: AtpItem) => void;
}

const ATP_STATUSES: AtpStatus[] = [
  'Belum Diajarkan',
  'Sedang Berjalan',
  'Tercapai',
];

export function AtpMaterialsView({
  subjects,
  atpItems,
  lessonNotes,
  defaultSemester,
  onAddAtp,
  onUpdateAtp,
  onDeleteAtp,
  onCreateJournalFromAtp,
}: AtpMaterialsViewProps) {
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [semesterFilter, setSemesterFilter] = useState<'Semua' | 'Ganjil' | 'Genap'>('Semua');
  const [statusFilter, setStatusFilter] = useState<'Semua' | AtpStatus>('Semua');
  const [searchQuery, setSearchQuery] = useState('');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<AtpItem | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [form, setForm] = useState<{
    subjectId: string;
    subjectName: string;
    gradeLevel: string;
    semester: 'Ganjil' | 'Genap';
    code: string;
    element: string;
    objective: string;
    materialsText: string;
    allocatedHours: number;
    status: AtpStatus;
    order: number;
  }>({
    subjectId: subjects[0]?.id ?? '',
    subjectName: subjects[0]?.name ?? '',
    gradeLevel: 'X',
    semester: defaultSemester,
    code: 'TP.1',
    element: '',
    objective: '',
    materialsText: '',
    allocatedHours: 6,
    status: 'Belum Diajarkan',
    order: 1,
  });

  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, s])),
    [subjects]
  );

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return [...atpItems]
      .filter((a) => (subjectFilter === 'ALL' ? true : a.subjectId === subjectFilter))
      .filter((a) => (semesterFilter === 'Semua' ? true : a.semester === semesterFilter))
      .filter((a) => (statusFilter === 'Semua' ? true : a.status === statusFilter))
      .filter((a) => {
        if (!q) return true;
        return (
          a.code.toLowerCase().includes(q) ||
          a.element.toLowerCase().includes(q) ||
          a.objective.toLowerCase().includes(q) ||
          a.subjectName.toLowerCase().includes(q) ||
          a.materials.some((m) => m.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => a.subjectName.localeCompare(b.subjectName) || a.order - b.order);
  }, [atpItems, subjectFilter, semesterFilter, statusFilter, searchQuery]);

  const stats = useMemo(() => {
    const total = filteredItems.length;
    const achieved = filteredItems.filter((a) => a.status === 'Tercapai').length;
    const active = filteredItems.filter((a) => a.status === 'Sedang Berjalan').length;
    const totalJp = filteredItems.reduce((sum, a) => sum + (a.allocatedHours || 0), 0);
    return { total, achieved, active, totalJp };
  }, [filteredItems]);

  const openCreateModal = () => {
    const chosenSubj =
      (subjectFilter !== 'ALL' ? subjectMap.get(subjectFilter) : undefined) ??
      subjects[0];
    const existingCount = atpItems.filter(
      (a) => a.subjectId === (chosenSubj?.id ?? '')
    ).length;

    setEditingItem(null);
    setForm({
      subjectId: chosenSubj?.id ?? '',
      subjectName: chosenSubj?.name ?? '',
      gradeLevel: chosenSubj?.gradeLevel.split(' ')[0] || 'X',
      semester: defaultSemester,
      code: `TP.${existingCount + 1}`,
      element: '',
      objective: '',
      materialsText: '',
      allocatedHours: 6,
      status: 'Belum Diajarkan',
      order: existingCount + 1,
    });
    setModalOpen(true);
  };

  const openEditModal = (item: AtpItem) => {
    setEditingItem(item);
    setForm({
      subjectId: item.subjectId,
      subjectName: item.subjectName,
      gradeLevel: item.gradeLevel,
      semester: item.semester,
      code: item.code,
      element: item.element,
      objective: item.objective,
      materialsText: item.materials.join('\n'),
      allocatedHours: item.allocatedHours,
      status: item.status,
      order: item.order,
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.code.trim() || !form.objective.trim()) return;
    const subj = subjectMap.get(form.subjectId);
    const materials = form.materialsText
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);

    const payload: Omit<AtpItem, 'id'> = {
      subjectId: form.subjectId,
      subjectName: subj?.name || form.subjectName || 'Mata Pelajaran',
      gradeLevel: form.gradeLevel.trim() || 'X',
      semester: form.semester,
      code: form.code.trim(),
      element: form.element.trim() || 'Umum',
      objective: form.objective.trim(),
      materials,
      allocatedHours: Math.max(1, form.allocatedHours || 1),
      status: form.status,
      order: Math.max(1, form.order || 1),
    };

    if (editingItem) {
      onUpdateAtp(editingItem.id, payload);
    } else {
      onAddAtp(payload);
    }
    setModalOpen(false);
  };

  const handleExportCsv = () => {
    const headers = [
      'Urutan',
      'Kode TP',
      'Mata Pelajaran',
      'Tingkat',
      'Semester',
      'Elemen / Bab',
      'Tujuan Pembelajaran (TP)',
      'Materi Pokok',
      'Alokasi JP',
      'Status',
    ];
    const rows = filteredItems.map((a) => [
      a.order,
      a.code,
      a.subjectName,
      a.gradeLevel,
      a.semester,
      a.element,
      a.objective,
      a.materials.join('; '),
      a.allocatedHours,
      a.status,
    ]);
    downloadCsv(`atp-dan-materi-${getTodayIsoDate()}.csv`, headers, rows);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl">
        <div className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-200 border-b border-slate-200">
          <div className="px-5 py-4">
            <p className="text-xs text-slate-500">Total Tujuan Pembelajaran</p>
            <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
              {stats.total} <span className="text-sm font-normal text-slate-500">TP</span>
            </p>
          </div>
          <div className="px-5 py-4 border-l border-slate-200 lg:border-l-0">
            <p className="text-xs text-slate-500">Tercapai</p>
            <p className="mt-1 font-display text-2xl font-semibold text-emerald-700 tabular-nums">
              {stats.achieved} <span className="text-sm font-normal text-slate-500">TP</span>
            </p>
          </div>
          <div className="px-5 py-4">
            <p className="text-xs text-slate-500">Sedang Berjalan</p>
            <p className="mt-1 font-display text-2xl font-semibold text-blue-700 tabular-nums">
              {stats.active} <span className="text-sm font-normal text-slate-500">TP</span>
            </p>
          </div>
          <div className="px-5 py-4 border-l border-slate-200 lg:border-l-0">
            <p className="text-xs text-slate-500">Total Alokasi Waktu</p>
            <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
              {stats.totalJp} <span className="text-sm font-normal text-slate-500">JP</span>
            </p>
          </div>
        </div>

        <div className="p-4 sm:p-5 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 flex-1">
            <div className="relative flex-1 min-w-[200px] max-w-xs">
              <Search className="h-3.5 w-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari kode TP, elemen, atau materi..."
                className="w-full pl-8 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
            </div>

            <select
              aria-label="Filter mata pelajaran"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-blue-600"
            >
              <option value="ALL">Semua Mata Pelajaran</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter semester"
              value={semesterFilter}
              onChange={(e) =>
                setSemesterFilter(e.target.value as 'Semua' | 'Ganjil' | 'Genap')
              }
              className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-blue-600"
            >
              <option value="Semua">Semua Semester</option>
              <option value="Ganjil">Semester Ganjil</option>
              <option value="Genap">Semester Genap</option>
            </select>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
              {(['Semua', ...ATP_STATUSES] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    statusFilter === st
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleExportCsv}
              disabled={filteredItems.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              Ekspor CSV
            </button>
            <button
              type="button"
              onClick={openCreateModal}
              disabled={subjects.length === 0}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 rounded-lg whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              Tambah ATP / Materi
            </button>
          </div>
        </div>
      </div>

      {subjects.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
          <p className="text-sm font-medium text-slate-900">
            Belum ada mata pelajaran terdaftar.
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Tambahkan mata pelajaran terlebih dahulu di menu Pelajaran & Kelas sebelum menyusun ATP dan Materi.
          </p>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <p className="text-sm font-medium text-slate-900">
            Belum ada Alur Tujuan Pembelajaran (ATP) yang sesuai.
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Susun TP dan daftar materi pokok per mata pelajaran agar dapat langsung ditautkan ke jurnal mengajar.
          </p>
          <button
            type="button"
            onClick={openCreateModal}
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
          >
            <Plus className="h-3.5 w-3.5" />
            Tambah ATP Pertama
          </button>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
          {filteredItems.map((item) => {
            const relatedNotesCount = lessonNotes.filter(
              (n) => n.atpId === item.id || n.atpCode === item.code
            ).length;

            const statusColor =
              item.status === 'Tercapai'
                ? 'text-emerald-700'
                : item.status === 'Sedang Berjalan'
                ? 'text-blue-700'
                : 'text-slate-500';

            return (
              <div key={item.id} className="p-6 space-y-3">
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div className="space-y-1.5 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                      <span className="font-mono font-semibold text-blue-700">
                        {item.code}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-slate-800">
                        {item.subjectName}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Kelas {item.gradeLevel}</span>
                      <span aria-hidden="true">·</span>
                      <span>Semester {item.semester}</span>
                      <span aria-hidden="true">·</span>
                      <span>Elemen: {item.element}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">{item.allocatedHours} JP</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        {relatedNotesCount} pertemuan tercatat
                      </span>
                    </div>

                    <p className="text-sm font-medium text-slate-900 leading-relaxed">
                      {item.objective}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <select
                      aria-label={`Ubah status ${item.code}`}
                      value={item.status}
                      onChange={(e) =>
                        onUpdateAtp(item.id, {
                          status: e.target.value as AtpStatus,
                        })
                      }
                      className={`px-2.5 py-1.5 text-xs font-semibold border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600 ${statusColor}`}
                    >
                      {ATP_STATUSES.map((st) => (
                        <option key={st} value={st} className="text-slate-800">
                          {st}
                        </option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onClick={() => onCreateJournalFromAtp(item)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg whitespace-nowrap shrink-0"
                    >
                      <BookOpenCheck className="h-3.5 w-3.5" />
                      Catat ke Jurnal
                    </button>

                    <button
                      type="button"
                      onClick={() => openEditModal(item)}
                      aria-label={`Edit ${item.code}`}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(item.id)}
                      aria-label={`Hapus ${item.code}`}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {confirmDeleteId === item.id && (
                  <div className="flex items-center justify-between gap-2 bg-red-50 border border-red-200 px-3.5 py-2.5 rounded-lg">
                    <span className="text-xs text-red-800">
                      Hapus {item.code} ({item.element}) dari daftar ATP?
                    </span>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-2.5 py-1 text-xs font-medium text-slate-600"
                      >
                        Batal
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteAtp(item.id);
                          setConfirmDeleteId(null);
                        }}
                        className="px-2.5 py-1 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded"
                      >
                        Hapus
                      </button>
                    </div>
                  </div>
                )}

                {item.materials.length > 0 && (
                  <div className="pt-1">
                    <p className="text-[11px] font-semibold text-slate-500 mb-1.5">
                      Materi Pokok / Topik Bahasan:
                    </p>
                    <ol className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1 text-xs text-slate-700 list-decimal list-inside">
                      {item.materials.map((mat, idx) => (
                        <li key={idx} className="leading-relaxed">
                          {mat}
                        </li>
                      ))}
                    </ol>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="atp-modal-title"
        >
          <div className="w-full max-w-xl bg-white border border-slate-200 rounded-xl shadow-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h2
                id="atp-modal-title"
                className="font-display text-base font-semibold text-slate-900"
              >
                {editingItem ? 'Edit ATP & Materi' : 'Tambah ATP & Materi Baru'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                aria-label="Tutup modal ATP"
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Mata Pelajaran
                  </label>
                  <select
                    required
                    value={form.subjectId}
                    onChange={(e) => {
                      const s = subjectMap.get(e.target.value);
                      setForm({
                        ...form,
                        subjectId: e.target.value,
                        subjectName: s?.name ?? '',
                        gradeLevel: s?.gradeLevel.split(' ')[0] || form.gradeLevel,
                      });
                    }}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Kode TP
                    </label>
                    <input
                      type="text"
                      required
                      value={form.code}
                      onChange={(e) => setForm({ ...form, code: e.target.value })}
                      placeholder="TP.10.1"
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Urutan Alur
                    </label>
                    <input
                      type="number"
                      min={1}
                      required
                      value={form.order}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          order: Math.max(1, Number(e.target.value) || 1),
                        })
                      }
                      className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Tingkat / Fase
                  </label>
                  <input
                    type="text"
                    required
                    value={form.gradeLevel}
                    onChange={(e) =>
                      setForm({ ...form, gradeLevel: e.target.value })
                    }
                    placeholder="X / XI / XII"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Semester
                  </label>
                  <select
                    value={form.semester}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        semester: e.target.value as 'Ganjil' | 'Genap',
                      })
                    }
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Alokasi JP
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={form.allocatedHours}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        allocatedHours: Math.max(1, Number(e.target.value) || 1),
                      })
                    }
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Elemen / Bab / Lingkup Materi
                </label>
                <input
                  type="text"
                  required
                  value={form.element}
                  onChange={(e) => setForm({ ...form, element: e.target.value })}
                  placeholder="Contoh: Aljabar dan Fungsi"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Rumusan Tujuan Pembelajaran (TP)
                </label>
                <textarea
                  rows={3}
                  required
                  value={form.objective}
                  onChange={(e) =>
                    setForm({ ...form, objective: e.target.value })
                  }
                  placeholder="Peserta didik mampu..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Daftar Materi Pokok (Satu topik per baris)
                </label>
                <textarea
                  rows={4}
                  value={form.materialsText}
                  onChange={(e) =>
                    setForm({ ...form, materialsText: e.target.value })
                  }
                  placeholder={
                    'Konsep dasar SPtLDV\nPenentuan daerah himpunan penyelesaian\nPemodelan masalah kontekstual'
                  }
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Status Ketercapaian
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {ATP_STATUSES.map((st) => {
                    const active = form.status === st;
                    return (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setForm({ ...form, status: st })}
                        className={`py-2 px-2.5 text-xs font-medium rounded-lg border transition-colors ${
                          active
                            ? 'bg-blue-700 border-blue-700 text-white'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {st}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
                >
                  {editingItem ? 'Simpan Perubahan' : 'Simpan ATP'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
