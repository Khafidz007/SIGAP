import { AtpItem, DayOfWeek, JournalState, Subject } from '../types/journal';

export const DAYS_OF_WEEK: DayOfWeek[] = [
  'Senin',
  'Selasa',
  'Rabu',
  'Kamis',
  'Jumat',
  'Sabtu',
];

export const TEACHER_AVATAR_URL =
  '/src/assets/images/avatar_teacher_profile_1794839809299.jpg';

export const SCHOOL_LOGO_URL =
  '/assets/aistudio/1622767670852-Logo__PNG-1080p__-_SMAN1PGB_5dbdc145.png';

export function getTodayIsoDate(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getOffsetIsoDate(offsetDays: number): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getDayOfWeekFromIso(isoDate: string): DayOfWeek {
  const [y, m, d] = isoDate.split('-').map(Number);
  const dateObj = new Date(y, (m || 1) - 1, d || 1);
  const jsDay = dateObj.getDay();
  const map: Record<number, DayOfWeek> = {
    0: 'Senin',
    1: 'Senin',
    2: 'Selasa',
    3: 'Rabu',
    4: 'Kamis',
    5: 'Jumat',
    6: 'Sabtu',
  };
  return map[jsDay] ?? 'Senin';
}

export function formatIndonesianDate(isoDate: string): string {
  if (!isoDate) return '-';
  const [y, m, d] = isoDate.split('-').map(Number);
  const dateObj = new Date(y, (m || 1) - 1, d || 1);
  return new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(dateObj);
}

export function formatShortDate(isoDate: string): string {
  if (!isoDate) return '-';
  const [y, m, d] = isoDate.split('-').map(Number);
  const dateObj = new Date(y, (m || 1) - 1, d || 1);
  return new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(dateObj);
}

export const SEED_SUBJECTS: Subject[] = [
  {
    id: 'subj-mtk-wajib',
    code: 'MTK-W',
    name: 'Matematika Wajib',
    gradeLevel: 'X / XI / XII',
    kktp: 75,
    weeklyHours: 4,
    description:
      'Capaian pembelajaran matematika umum mencakup aljabar, sistem pertidaksamaan, fungsi, dan statistika.',
  },
  {
    id: 'subj-mtk-lanjut',
    code: 'MTK-TL',
    name: 'Matematika Tingkat Lanjut',
    gradeLevel: 'XI (Fase F)',
    kktp: 78,
    weeklyHours: 4,
    description:
      'Pendalaman aljabar polinomial, matriks, transformasi geometri, dan fungsi kompleks.',
  },
  {
    id: 'subj-mtk-peminatan',
    code: 'MTK-P',
    name: 'Matematika Peminatan',
    gradeLevel: 'XII (Fase F+)',
    kktp: 78,
    weeklyHours: 4,
    description:
      'Limit fungsi trigonometri, turunan fungsi trigonometri, serta aplikasinya pada kurva dan laju perubahan.',
  },
  {
    id: 'subj-p5-numerasi',
    code: 'P5-NUM',
    name: 'Projek Penguatan Numerasi',
    gradeLevel: 'X (Fase E)',
    kktp: 75,
    weeklyHours: 2,
    description:
      'Projek kontekstual literasi numerasi berbasis pemecahan masalah data lingkungan sekolah.',
  },
];

export const SEED_ATP_ITEMS: AtpItem[] = [
  {
    id: 'atp-1',
    subjectId: 'subj-mtk-wajib',
    subjectName: 'Matematika Wajib',
    gradeLevel: 'X',
    semester: 'Ganjil',
    code: 'TP.10.1',
    element: 'Bilangan & Aljabar',
    objective:
      'Peserta didik mampu menggeneralisasi sifat-sifat eksponen dan logaritma serta menerapkannya dalam pemodelan pertumbuhan.',
    materials: [
      'Sifat-sifat bilangan berpangkat (eksponen)',
      'Fungsi eksponen dan grafik pertumbuhan',
      'Konsep dasar dan sifat logaritma',
    ],
    allocatedHours: 8,
    status: 'Tercapai',
    order: 1,
  },
  {
    id: 'atp-2',
    subjectId: 'subj-mtk-wajib',
    subjectName: 'Matematika Wajib',
    gradeLevel: 'X',
    semester: 'Ganjil',
    code: 'TP.10.2',
    element: 'Aljabar dan Fungsi',
    objective:
      'Peserta didik mampu menyelesaikan masalah kontekstual yang berkaitan dengan sistem persamaan dan pertidaksamaan linear dua variabel.',
    materials: [
      'Sistem Persamaan Linear Tiga Variabel (SPLTV)',
      'Sistem Pertidaksamaan Linear Dua Variabel (SPtLDV)',
      'Penentuan daerah himpunan penyelesaian & model optimum',
    ],
    allocatedHours: 10,
    status: 'Sedang Berjalan',
    order: 2,
  },
  {
    id: 'atp-3',
    subjectId: 'subj-mtk-lanjut',
    subjectName: 'Matematika Tingkat Lanjut',
    gradeLevel: 'XI',
    semester: 'Ganjil',
    code: 'TP.11.1',
    element: 'Aljabar dan Fungsi',
    objective:
      'Peserta didik mampu melakukan operasi aritmetika pada polinomial serta menggunakan Teorema Sisa dan Teorema Faktor untuk pemfaktoran.',
    materials: [
      'Pengertian, derajat, dan operasi polinomial',
      'Pembagian bersusun dan skema Horner',
      'Teorema Sisa dan Teorema Faktor',
    ],
    allocatedHours: 12,
    status: 'Tercapai',
    order: 1,
  },
  {
    id: 'atp-4',
    subjectId: 'subj-mtk-lanjut',
    subjectName: 'Matematika Tingkat Lanjut',
    gradeLevel: 'XI',
    semester: 'Ganjil',
    code: 'TP.11.2',
    element: 'Aljabar & Matriks',
    objective:
      'Peserta didik mampu menyatakan data dalam bentuk matriks, melakukan operasi matriks, dan menentukan invers matriks berordo 2x2 dan 3x3.',
    materials: [
      'Jenis-jenis matriks dan kesamaan matriks',
      'Operasi penjumlahan, pengurangan, dan perkalian matriks',
      'Determinan dan invers matriks untuk menyelesaikan SPL',
    ],
    allocatedHours: 10,
    status: 'Belum Diajarkan',
    order: 2,
  },
  {
    id: 'atp-5',
    subjectId: 'subj-mtk-peminatan',
    subjectName: 'Matematika Peminatan',
    gradeLevel: 'XII',
    semester: 'Ganjil',
    code: 'TP.12.1',
    element: 'Kalkulus',
    objective:
      'Peserta didik dapat menentukan turunan pertama fungsi komposisi trigonometri menggunakan aturan rantai serta mengaplikasikannya pada garis singgung.',
    materials: [
      'Turunan dasar fungsi sinus, kosinus, dan tangen',
      'Aturan rantai pada fungsi komposisi trigonometri',
      'Aplikasi gradien garis singgung dan titik stasioner',
    ],
    allocatedHours: 10,
    status: 'Sedang Berjalan',
    order: 1,
  },
];

export function createSeedData(): JournalState {
  const today = getTodayIsoDate();
  const yesterday3 = getOffsetIsoDate(-3);
  const yesterday4 = getOffsetIsoDate(-4);
  const lastWeek = getOffsetIsoDate(-7);

  return {
    profile: {
      name: 'Ratna Dewi, S.Pd.',
      nip: '19890415 201503 2 004',
      subject: 'Matematika',
      school: 'SMA Negeri 1 Pagerbarang',
      schoolLogoUrl: SCHOOL_LOGO_URL,
      academicYear: '2026/2027',
      semester: 'Ganjil',
      avatarUrl: TEACHER_AVATAR_URL,
    },
    subjects: SEED_SUBJECTS,
    atpItems: SEED_ATP_ITEMS,
    classes: [
      {
        id: 'cls-xa',
        name: 'X-A',
        grade: 'X',
        major: 'Fase E (Umum)',
        room: 'Ruang 104',
        homeroomTeacher: 'Ratna Dewi, S.Pd.',
        students: [
          { id: 'st-xa-1', nis: '261001', name: 'Aditya Pratama Wijaya', gender: 'L' },
          { id: 'st-xa-2', nis: '261002', name: 'Aisyah Putri Ramadhani', gender: 'P' },
          { id: 'st-xa-3', nis: '261003', name: 'Bagas Kurniawan', gender: 'L' },
          { id: 'st-xa-4', nis: '261004', name: 'Clarissa Natania', gender: 'P' },
          { id: 'st-xa-5', nis: '261005', name: 'Dimas Arya Saputra', gender: 'L' },
          { id: 'st-xa-6', nis: '261006', name: 'Farah Salsabila', gender: 'P' },
          { id: 'st-xa-7', nis: '261007', name: 'Gilang Mahendra', gender: 'L' },
          { id: 'st-xa-8', nis: '261008', name: 'Hana Permata Sari', gender: 'P' },
          { id: 'st-xa-9', nis: '261009', name: 'Irfan Hakim Nugroho', gender: 'L' },
          { id: 'st-xa-10', nis: '261010', name: 'Keisha Azzahra', gender: 'P' },
        ],
      },
      {
        id: 'cls-xi1',
        name: 'XI-IPA-1',
        grade: 'XI',
        major: 'MIPA',
        room: 'Ruang 203',
        homeroomTeacher: 'Drs. Hendra Wijaya',
        students: [
          { id: 'st-xi-1', nis: '251011', name: 'Alvin Hendrawan', gender: 'L' },
          { id: 'st-xi-2', nis: '251012', name: 'Bella Puspita Dewi', gender: 'P' },
          { id: 'st-xi-3', nis: '251013', name: 'Candra Setiawan', gender: 'L' },
          { id: 'st-xi-4', nis: '251014', name: 'Dina Safitri', gender: 'P' },
          { id: 'st-xi-5', nis: '251015', name: 'Evan Ramadhan', gender: 'L' },
          { id: 'st-xi-6', nis: '251016', name: 'Firda Aulia Rahma', gender: 'P' },
          { id: 'st-xi-7', nis: '251017', name: 'Galih Wicaksono', gender: 'L' },
          { id: 'st-xi-8', nis: '251018', name: 'Intan Kusuma Wardani', gender: 'P' },
          { id: 'st-xi-9', nis: '251019', name: 'Jovan Nicholas', gender: 'L' },
          { id: 'st-xi-10', nis: '251020', name: 'Larasati Ningrum', gender: 'P' },
        ],
      },
      {
        id: 'cls-xii2',
        name: 'XII-IPA-2',
        grade: 'XII',
        major: 'MIPA',
        room: 'Ruang 301',
        homeroomTeacher: 'Siti Aminah, M.Pd.',
        students: [
          { id: 'st-xii-1', nis: '241021', name: 'Arif Rahman Hakim', gender: 'L' },
          { id: 'st-xii-2', nis: '241022', name: 'Bunga Citra Lestari', gender: 'P' },
          { id: 'st-xii-3', nis: '241023', name: 'Daffa Alfarizi', gender: 'L' },
          { id: 'st-xii-4', nis: '241024', name: 'Eka Putri Maharani', gender: 'P' },
          { id: 'st-xii-5', nis: '241025', name: 'Fajar Sidik Purnomo', gender: 'L' },
          { id: 'st-xii-6', nis: '241026', name: 'Gita Anggraini', gender: 'P' },
          { id: 'st-xii-7', nis: '241027', name: 'Hendra Gunawan', gender: 'L' },
          { id: 'st-xii-8', nis: '241028', name: 'Maya Oktaviani', gender: 'P' },
          { id: 'st-xii-9', nis: '241029', name: 'Naufal Azhar', gender: 'L' },
          { id: 'st-xii-10', nis: '241030', name: 'Putri Melati', gender: 'P' },
        ],
      },
    ],
    schedules: [
      {
        id: 'sch-1',
        day: 'Senin',
        startTime: '07:15',
        endTime: '08:45',
        classId: 'cls-xa',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 104',
        lessonHours: 2,
      },
      {
        id: 'sch-2',
        day: 'Senin',
        startTime: '09:00',
        endTime: '10:30',
        classId: 'cls-xi1',
        subjectId: 'subj-mtk-lanjut',
        subject: 'Matematika Tingkat Lanjut',
        room: 'Ruang 203',
        lessonHours: 2,
      },
      {
        id: 'sch-3',
        day: 'Senin',
        startTime: '11:00',
        endTime: '12:30',
        classId: 'cls-xii2',
        subjectId: 'subj-mtk-peminatan',
        subject: 'Matematika Peminatan',
        room: 'Ruang 301',
        lessonHours: 2,
      },
      {
        id: 'sch-4',
        day: 'Selasa',
        startTime: '07:00',
        endTime: '08:30',
        classId: 'cls-xi1',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 203',
        lessonHours: 2,
      },
      {
        id: 'sch-5',
        day: 'Selasa',
        startTime: '10:15',
        endTime: '11:45',
        classId: 'cls-xii2',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 301',
        lessonHours: 2,
      },
      {
        id: 'sch-6',
        day: 'Rabu',
        startTime: '07:00',
        endTime: '08:30',
        classId: 'cls-xa',
        subjectId: 'subj-mtk-wajib',
        subject: 'Matematika Wajib',
        room: 'Ruang 104',
        lessonHours: 2,
      },
      {
        id: 'sch-7',
        day: 'Rabu',
        startTime: '09:45',
        endTime: '11:15',
        classId: 'cls-xii2',
        subjectId: 'subj-mtk-peminatan',
        subject: 'Matematika Peminatan',
        room: 'Ruang 301',
        lessonHours: 2,
      },
      {
        id: 'sch-8',
        day: 'Kamis',
        startTime: '08:30',
        endTime: '10:00',
        classId: 'cls-xi1',
        subjectId: 'subj-mtk-lanjut',
        subject: 'Matematika Tingkat Lanjut',
        room: 'Ruang 203',
        lessonHours: 2,
      },
      {
        id: 'sch-9',
        day: 'Jumat',
        startTime: '07:30',
        endTime: '09:00',
        classId: 'cls-xa',
        subjectId: 'subj-p5-numerasi',
        subject: 'Projek Penguatan Numerasi',
        room: 'Lab Komputer 1',
        lessonHours: 2,
      },
    ],
    attendanceSessions: [
      {
        id: `att-${today}-sch-1`,
        date: today,
        scheduleSlotId: 'sch-1',
        classId: 'cls-xa',
        subject: 'Matematika Wajib',
        updatedAt: `${today}T07:25:00`,
        records: {
          'st-xa-1': { studentId: 'st-xa-1', status: 'H' },
          'st-xa-2': { studentId: 'st-xa-2', status: 'H' },
          'st-xa-3': { studentId: 'st-xa-3', status: 'S', note: 'Surat izin orang tua (demam)' },
          'st-xa-4': { studentId: 'st-xa-4', status: 'H' },
          'st-xa-5': { studentId: 'st-xa-5', status: 'H' },
          'st-xa-6': { studentId: 'st-xa-6', status: 'H' },
          'st-xa-7': { studentId: 'st-xa-7', status: 'I', note: 'Mengikuti lomba debat kota' },
          'st-xa-8': { studentId: 'st-xa-8', status: 'H' },
          'st-xa-9': { studentId: 'st-xa-9', status: 'H' },
          'st-xa-10': { studentId: 'st-xa-10', status: 'H' },
        },
      },
      {
        id: `att-${lastWeek}-sch-1`,
        date: lastWeek,
        scheduleSlotId: 'sch-1',
        classId: 'cls-xa',
        subject: 'Matematika Wajib',
        updatedAt: `${lastWeek}T07:20:00`,
        records: {
          'st-xa-1': { studentId: 'st-xa-1', status: 'H' },
          'st-xa-2': { studentId: 'st-xa-2', status: 'H' },
          'st-xa-3': { studentId: 'st-xa-3', status: 'H' },
          'st-xa-4': { studentId: 'st-xa-4', status: 'H' },
          'st-xa-5': { studentId: 'st-xa-5', status: 'A', note: 'Tanpa keterangan' },
          'st-xa-6': { studentId: 'st-xa-6', status: 'H' },
          'st-xa-7': { studentId: 'st-xa-7', status: 'H' },
          'st-xa-8': { studentId: 'st-xa-8', status: 'H' },
          'st-xa-9': { studentId: 'st-xa-9', status: 'H' },
          'st-xa-10': { studentId: 'st-xa-10', status: 'H' },
        },
      },
      {
        id: `att-${yesterday3}-sch-8`,
        date: yesterday3,
        scheduleSlotId: 'sch-8',
        classId: 'cls-xi1',
        subject: 'Matematika Tingkat Lanjut',
        updatedAt: `${yesterday3}T08:40:00`,
        records: {
          'st-xi-1': { studentId: 'st-xi-1', status: 'H' },
          'st-xi-2': { studentId: 'st-xi-2', status: 'H' },
          'st-xi-3': { studentId: 'st-xi-3', status: 'H' },
          'st-xi-4': { studentId: 'st-xi-4', status: 'S', note: 'Izin UKS' },
          'st-xi-5': { studentId: 'st-xi-5', status: 'H' },
          'st-xi-6': { studentId: 'st-xi-6', status: 'H' },
          'st-xi-7': { studentId: 'st-xi-7', status: 'H' },
          'st-xi-8': { studentId: 'st-xi-8', status: 'H' },
          'st-xi-9': { studentId: 'st-xi-9', status: 'H' },
          'st-xi-10': { studentId: 'st-xi-10', status: 'H' },
        },
      },
    ],
    lessonNotes: [
      {
        id: 'note-1',
        date: today,
        scheduleSlotId: 'sch-1',
        classId: 'cls-xa',
        subject: 'Matematika Wajib',
        atpId: 'atp-2',
        atpCode: 'TP.10.2',
        meetingNumber: 14,
        topic: 'Sistem Pertidaksamaan Linear Dua Variabel (SPtLDV)',
        learningObjective:
          'Siswa mampu menentukan daerah himpunan penyelesaian sistem pertidaksamaan linear dua variabel dan memodelkan masalah kontekstual.',
        activitySummary:
          'Diskusi kelompok kecil menggunakan LKPD 4.2. Siswa memetakan garis batas dan menguji titik (0,0) pada koordinat Kartesius.',
        homework: 'Latihan Buku Paket Hal. 118 No. 1–5 (dikumpulkan Rabu).',
        reflection:
          'Sebagian besar siswa sudah lancar menggambar garis batas, namun 3 kelompok masih tertukar tanda arsiran untuk koefisien y negatif. Perlu penguatan 10 menit di awal pertemuan berikutnya.',
        status: 'Berlanjut',
        updatedAt: `${today}T08:42:00`,
      },
      {
        id: 'note-2',
        date: yesterday3,
        scheduleSlotId: 'sch-8',
        classId: 'cls-xi1',
        subject: 'Matematika Tingkat Lanjut',
        atpId: 'atp-3',
        atpCode: 'TP.11.1',
        meetingNumber: 12,
        topic: 'Polinomial: Teorema Sisa dan Teorema Faktor',
        learningObjective:
          'Siswa mampu menentukan sisa pembagian suku banyak menggunakan skema Horner dan membuktikan faktor linear.',
        activitySummary:
          'Demonstrasi pembagian bersusun vs metode Horner di papan tulis, dilanjutkan latihan berpasangan mencari akar rasional persamaan berderajat 3.',
        homework: 'Kuis mandiri 4 soal teorema faktor di lembar kerja.',
        reflection:
          'Kelas sangat aktif saat membandingkan efisiensi skema Horner. Materi tuntas sesuai alokasi waktu.',
        status: 'Tuntas',
        updatedAt: `${yesterday3}T10:05:00`,
      },
      {
        id: 'note-3',
        date: yesterday4,
        scheduleSlotId: 'sch-7',
        classId: 'cls-xii2',
        subject: 'Matematika Peminatan',
        atpId: 'atp-5',
        atpCode: 'TP.12.1',
        meetingNumber: 15,
        topic: 'Turunan Fungsi Trigonometri & Aturan Rantai',
        learningObjective:
          'Siswa dapat menentukan turunan pertama fungsi komposisi trigonometri menggunakan aturan rantai.',
        activitySummary:
          'Review turunan dasar sin x dan cos x, kemudian penurunan bertahap untuk bentuk sin(ax + b) dan sin^n(x).',
        homework: 'Membuat 3 soal variasi aturan rantai beserta pembahasannya.',
        reflection:
          'Waktu sempat terpotong pengumuman OSIS 15 menit sehingga bagian aplikasi garis singgung kurva ditunda ke pertemuan hari Senin.',
        status: 'Tertunda',
        updatedAt: `${yesterday4}T11:20:00`,
      },
    ],
  };
}

export function createEmptyData(): JournalState {
  return {
    profile: {
      name: 'Guru Pengajar',
      nip: '-',
      subject: 'Mata Pelajaran',
      school: 'SMA Negeri 1 Pagerbarang',
      schoolLogoUrl: SCHOOL_LOGO_URL,
      academicYear: '2026/2027',
      semester: 'Ganjil',
      avatarUrl: TEACHER_AVATAR_URL,
    },
    subjects: [],
    atpItems: [],
    classes: [],
    schedules: [],
    attendanceSessions: [],
    lessonNotes: [],
  };
}
