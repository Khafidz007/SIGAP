import React, { useRef, useState } from 'react';
import {
  ArrowRight,
  CalendarClock,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  User,
} from 'lucide-react';
import { CalendarReminder, UserAccount } from '../types/journal';
import { formatIndonesianDate, SCHOOL_LOGO_URL } from '../data/seedData';
import { loginWithCredentials } from '../services/api';
import { RunningCalendarBar } from './RunningCalendarBar';

interface LandingPageProps {
  schoolName: string;
  schoolLogoUrl: string;
  activeTeachers: number;
  schoolReminders: CalendarReminder[];
  onLoginSuccess: (token: string, user: UserAccount) => void;
}

const DEMO_ACCOUNTS = [
  {
    username: 'ratna',
    password: 'guru123',
    label: 'Guru Matematika (Ratna Dewi, S.Pd.)',
  },
  {
    username: 'hendra',
    password: 'guru123',
    label: 'Guru Fisika (Drs. Hendra Wijaya)',
  },
  {
    username: 'admin',
    password: 'admin123',
    label: 'Admin Kurikulum (Kelola Akun & Kalender)',
  },
];

export function LandingPage({
  schoolName,
  schoolLogoUrl,
  activeTeachers,
  schoolReminders,
  onLoginSuccess,
}: LandingPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showDemoList, setShowDemoList] = useState(false);

  const usernameInputRef = useRef<HTMLInputElement | null>(null);

  const focusLoginForm = () => {
    const el = document.getElementById('masuk-guru');
    el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    window.setTimeout(() => {
      usernameInputRef.current?.focus();
    }, 250);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);
    try {
      const res = await loginWithCredentials(username.trim(), password);
      onLoginSuccess(res.token, res.user);
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Gagal masuk ke aplikasi.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-8">
          <a
            href="#beranda"
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            SIGAP
          </a>

          <nav
            aria-label="Navigasi landing page"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600"
          >
            <a
              href="#beranda"
              className="hover:text-slate-900 hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Beranda
            </a>
            <a
              href="#fitur"
              className="hover:text-slate-900 hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Fitur Utama
            </a>
            <a
              href="#kalender-harian"
              className="hover:text-slate-900 hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Kalender Harian
            </a>
            <a
              href="#masuk-guru"
              className="hover:text-slate-900 hover:underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Akses Guru
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={focusLoginForm}
              className="px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Masuk Aplikasi
            </button>
          </div>
        </div>
      </header>

      <RunningCalendarBar reminders={schoolReminders} />

      <main className="flex-1">
        <section
          id="beranda"
          className="max-w-[1280px] mx-auto px-4 sm:px-8 py-12 lg:py-16"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="flex items-center gap-3.5">
                <img
                  src={schoolLogoUrl || SCHOOL_LOGO_URL}
                  alt={`Logo ${schoolName}`}
                  referrerPolicy="no-referrer"
                  className="h-14 w-14 object-contain shrink-0"
                />
                <div className="min-w-0">
                  <p className="font-display text-sm font-bold text-slate-900 leading-snug">
                    SIGAP : Sistem Informasi Guru dan Administrasi
                  </p>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {schoolName} · Tahun Ajaran 2026/2027
                  </p>
                </div>
              </div>

              <h1
                className="font-display font-bold tracking-tight text-slate-900 text-balance"
                style={{ fontSize: 'clamp(2.1rem, 3.6vw, 3.25rem)', lineHeight: 1.12 }}
              >
                Jurnal Mengajar, Presensi, dan ATP Terstruktur untuk Setiap Guru
              </h1>

              <p className="text-base text-slate-600 leading-relaxed max-w-2xl">
                Catat jadwal mengajar mingguan, presensi siswa per pertemuan, Alur
                Tujuan Pembelajaran (ATP), serta riwayat jurnal pembelajaran dalam
                satu ruang kerja pribadi yang terpisah untuk masing-masing akun guru.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-1">
                <button
                  type="button"
                  onClick={focusLoginForm}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Masuk ke Ruang Kerja Guru
                  <ArrowRight className="h-4 w-4" />
                </button>
                <a
                  href="#fitur"
                  className="text-sm font-medium text-slate-700 hover:text-slate-900 underline-offset-4 hover:underline whitespace-nowrap shrink-0"
                >
                  Pelajari alur kerja
                </a>
              </div>
            </div>

            <div className="lg:col-span-5 flex items-stretch">
              <div
                id="masuk-guru"
                className="w-full bg-white border border-slate-200 rounded-xl p-6 sm:p-7 flex flex-col justify-between"
              >
                <div className="space-y-5">
                  <div>
                    <p className="text-xs font-medium text-blue-700">
                      Portal Masuk Pengguna
                    </p>
                    <h2 className="font-display text-xl font-semibold text-slate-900 mt-1">
                      Masuk dengan Akun Anda
                    </h2>
                    <p className="text-xs text-slate-500 mt-1">
                      Gunakan username dan password yang diberikan admin sekolah untuk
                      mengakses data mengajar pribadi Anda.
                    </p>
                  </div>

                  {errorMsg && (
                    <div
                      role="alert"
                      className="text-xs font-medium text-red-700 bg-red-50 border border-red-200 px-3.5 py-2.5 rounded-lg"
                    >
                      {errorMsg}
                    </div>
                  )}

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label
                        htmlFor="login-username"
                        className="block text-xs font-medium text-slate-700 mb-1.5"
                      >
                        Username
                      </label>
                      <div className="relative">
                        <User className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          ref={usernameInputRef}
                          id="login-username"
                          type="text"
                          required
                          autoComplete="username"
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          placeholder="Masukkan username guru"
                          className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="login-password"
                        className="block text-xs font-medium text-slate-700 mb-1.5"
                      >
                        Password
                      </label>
                      <div className="relative">
                        <Lock className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          id="login-password"
                          type={showPassword ? 'text' : 'password'}
                          required
                          autoComplete="current-password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Masukkan password"
                          className="w-full pl-9 pr-10 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword((s) => !s)}
                          aria-label={
                            showPassword
                              ? 'Sembunyikan password'
                              : 'Tampilkan password'
                          }
                          className="p-1.5 text-slate-400 hover:text-slate-700 absolute right-2 top-1/2 -translate-y-1/2 rounded"
                        >
                          {showPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-2.5 px-4 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 rounded-lg transition-colors whitespace-nowrap"
                    >
                      {submitting ? 'Memeriksa akun...' : 'Masuk Aplikasi'}
                    </button>
                  </form>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => setShowDemoList((prev) => !prev)}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-blue-700"
                  >
                    <KeyRound className="h-3.5 w-3.5" />
                    {showDemoList
                      ? 'Sembunyikan daftar akun awal'
                      : 'Lihat akun awal untuk uji akses per guru'}
                  </button>

                  {showDemoList && (
                    <div className="mt-3 space-y-1.5">
                      {DEMO_ACCOUNTS.map((acc) => (
                        <button
                          key={acc.username}
                          type="button"
                          onClick={() => {
                            setUsername(acc.username);
                            setPassword(acc.password);
                            setErrorMsg(null);
                          }}
                          className="w-full text-left px-3 py-2 text-xs bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-lg flex items-center justify-between gap-2 transition-colors"
                        >
                          <span className="font-medium text-slate-800 truncate">
                            {acc.label}
                          </span>
                          <span className="font-mono text-[11px] text-blue-700 shrink-0">
                            {acc.username} / {acc.password}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-10 bg-white border border-slate-200 rounded-xl grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
            <div className="px-6 py-5">
              <p className="text-xs text-slate-500">Pengguna Terdaftar</p>
              <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
                {activeTeachers}{' '}
                <span className="text-sm font-normal text-slate-500">akun aktif</span>
              </p>
            </div>
            <div className="px-6 py-5 border-l border-slate-200 lg:border-l-0">
              <p className="text-xs text-slate-500">Modul Mengajar</p>
              <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
                6 <span className="text-sm font-normal text-slate-500">bagian terpadu</span>
              </p>
            </div>
            <div className="px-6 py-5">
              <p className="text-xs text-slate-500">Pengingat Aktif</p>
              <p className="mt-1 font-display text-2xl font-semibold text-slate-900 tabular-nums">
                {schoolReminders.length}{' '}
                <span className="text-sm font-normal text-slate-500">agenda sekolah</span>
              </p>
            </div>
            <div className="px-6 py-5 border-l border-slate-200 lg:border-l-0">
              <p className="text-xs text-slate-500">Format Laporan</p>
              <p className="mt-1 font-display text-2xl font-semibold text-slate-900">
                CSV & Cetak
              </p>
            </div>
          </div>
        </section>

        <section
          id="fitur"
          className="border-t border-slate-200 bg-white py-14"
        >
          <div className="max-w-[1280px] mx-auto px-4 sm:px-8 space-y-8">
            <div className="max-w-2xl">
              <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 text-balance">
                Alur Administrasi Mengajar dalam Satu Tempat
              </h2>
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                Setiap akun guru memiliki ruang data tersendiri untuk jadwal, kelas,
                daftar siswa, ATP, presensi, dan riwayat jurnal harian.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-slate-50 border border-slate-200 rounded-xl p-6 sm:p-7 space-y-3">
                <h3 className="font-display text-lg font-semibold text-slate-900">
                  01. Jadwal Mengajar & Ringkasan Harian
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Kelola jadwal mengajar mingguan dalam tampilan per hari maupun
                  matriks jam pelajaran. Setiap sesi hari ini langsung menampilkan
                  status kelengkapan presensi dan jurnal materi agar tidak ada jam
                  mengajar yang terlewat.
                </p>
                <div className="pt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                  <span>Tampilan Per Hari & Matriks Mingguan</span>
                  <span aria-hidden="true">·</span>
                  <span>Pintasan Presensi & Jurnal</span>
                  <span aria-hidden="true">·</span>
                  <span>Hitungan Total JP Mingguan</span>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 sm:p-7 space-y-3">
                <h3 className="font-display text-lg font-semibold text-slate-900">
                  02. Presensi Siswa & Rekap Otomatis
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Catat kehadiran Hadir, Izin, Sakit, atau Alpa beserta keterangan
                  per siswa. Rekap persentase kehadiran per kelas dihitung otomatis
                  dan siap diunduh ke Excel (CSV).
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 sm:p-7 space-y-3">
                <h3 className="font-display text-lg font-semibold text-slate-900">
                  03. ATP, Materi & Riwayat Jurnal
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Susun Alur Tujuan Pembelajaran (ATP) dan daftar materi pokok per
                  semester, lalu tautkan langsung ke catatan jurnal pertemuan untuk
                  memantau ketercapaian materi.
                </p>
              </div>

              <div className="lg:col-span-2 bg-slate-50 border border-slate-200 rounded-xl p-6 sm:p-7 space-y-3">
                <h3 className="font-display text-lg font-semibold text-slate-900">
                  04. Manajemen Pelajaran, Kelas, & Akses Per User
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Admin kurikulum sekolah dapat membuat dan mengatur akun username
                  serta password untuk seluruh Bapak/Ibu guru, serta menerbitkan
                  agenda kalender sekolah yang tampil pada running kalender harian.
                </p>
                <div className="pt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                  <span>Data Terisolasi Per Akun Guru</span>
                  <span aria-hidden="true">·</span>
                  <span>Impor Daftar Siswa dari Excel</span>
                  <span aria-hidden="true">·</span>
                  <span>Cetak Laporan Jurnal Resmi Sekolah</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section
          id="kalender-harian"
          className="border-t border-slate-200 bg-slate-50 py-14"
        >
          <div className="max-w-[1280px] mx-auto px-4 sm:px-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900">
                  Kalender & Pengingat Sekolah Terdekat
                </h2>
                <p className="text-sm text-slate-600 mt-1">
                  Agenda resmi {schoolName} yang ditampilkan pada running kalender setiap hari.
                </p>
              </div>
              <button
                type="button"
                onClick={focusLoginForm}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 hover:text-blue-800 whitespace-nowrap shrink-0 self-start sm:self-auto"
              >
                <CalendarClock className="h-3.5 w-3.5" />
                Masuk untuk tambah pengingat pribadi
              </button>
            </div>

            {schoolReminders.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
                Belum ada agenda kalender sekolah yang dijadwalkan.
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-xl divide-y divide-slate-200">
                {schoolReminders.slice(0, 5).map((ev) => (
                  <div
                    key={ev.id}
                    className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                        <span className="font-semibold text-blue-700">
                          {ev.category}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-medium text-slate-800">
                          {formatIndonesianDate(ev.date)}
                        </span>
                        {ev.time && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">
                              Pukul {ev.time}
                            </span>
                          </>
                        )}
                      </div>
                      <p className="text-sm font-semibold text-slate-900">
                        {ev.title}
                      </p>
                      {ev.description && (
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {ev.description}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      <footer className="bg-white border-t border-slate-200 py-8">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-3">
            <img
              src={schoolLogoUrl || SCHOOL_LOGO_URL}
              alt={`Logo ${schoolName}`}
              referrerPolicy="no-referrer"
              className="h-7 w-7 object-contain shrink-0"
            />
            <span className="font-medium text-slate-800">
              SIGAP : Sistem Informasi Guru dan Administrasi · {schoolName}
            </span>
          </div>
          <div className="flex items-center gap-5">
            <a href="#beranda" className="hover:text-slate-900">
              Beranda
            </a>
            <a href="#fitur" className="hover:text-slate-900">
              Fitur Utama
            </a>
            <a href="#kalender-harian" className="hover:text-slate-900">
              Kalender Harian
            </a>
            <button
              type="button"
              onClick={focusLoginForm}
              className="text-blue-700 hover:underline font-medium"
            >
              Masuk Guru
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
