import React, { useMemo, useState } from 'react';
import {
  Plus,
  Pencil,
  Trash2,
  ClipboardCheck,
  BookOpenText,
  X,
} from 'lucide-react';
import { Classroom, DayOfWeek, ScheduleSlot, Subject } from '../types/journal';
import { DAYS_OF_WEEK, getTodayIsoDate } from '../data/seedData';

interface ScheduleViewProps {
  classes: Classroom[];
  subjects: Subject[];
  schedules: ScheduleSlot[];
  defaultSubject: string;
  onAddSchedule: (payload: Omit<ScheduleSlot, 'id'>) => void;
  onUpdateSchedule: (id: string, patch: Partial<Omit<ScheduleSlot, 'id'>>) => void;
  onDeleteSchedule: (id: string) => void;
  onOpenAttendance: (slot: ScheduleSlot, date: string) => void;
  onOpenNote: (slot: ScheduleSlot, date: string) => void;
}

export function ScheduleView({
  classes,
  subjects,
  schedules,
  defaultSubject,
  onAddSchedule,
  onUpdateSchedule,
  onDeleteSchedule,
  onOpenAttendance,
  onOpenNote,
}: ScheduleViewProps) {
  const [viewMode, setViewMode] = useState<'harian' | 'matriks'>('harian');
  const [selectedDay, setSelectedDay] = useState<'Semua' | DayOfWeek>('Semua');
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingSlot, setEditingSlot] = useState<ScheduleSlot | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [form, setForm] = useState<Omit<ScheduleSlot, 'id'>>({
    day: 'Senin',
    startTime: '07:00',
    endTime: '08:30',
    classId: classes[0]?.id ?? '',
    subjectId: subjects[0]?.id,
    subject: subjects[0]?.name ?? defaultSubject,
    room: classes[0]?.room ?? '',
    lessonHours: 2,
  });

  const classMap = useMemo(
    () => new Map(classes.map((c) => [c.id, c])),
    [classes]
  );

  const subjectMap = useMemo(
    () => new Map(subjects.map((s) => [s.id, s])),
    [subjects]
  );

  const todayIso = getTodayIsoDate();

  const openCreateModal = (day?: DayOfWeek) => {
    const firstClass = classes[0];
    const firstSubject = subjects[0];
    setEditingSlot(null);
    setForm({
      day: day ?? 'Senin',
      startTime: '07:00',
      endTime: '08:30',
      classId: firstClass?.id ?? '',
      subjectId: firstSubject?.id,
      subject: firstSubject?.name ?? defaultSubject,
      room: firstClass?.room ?? '',
      lessonHours: 2,
    });
    setModalOpen(true);
  };

  const openEditModal = (slot: ScheduleSlot) => {
    setEditingSlot(slot);
    setForm({
      day: slot.day,
      startTime: slot.startTime,
      endTime: slot.endTime,
      classId: slot.classId,
      subjectId: slot.subjectId,
      subject: slot.subject,
      room: slot.room,
      lessonHours: slot.lessonHours,
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.classId) return;
    if (editingSlot) {
      onUpdateSchedule(editingSlot.id, form);
    } else {
      onAddSchedule(form);
    }
    setModalOpen(false);
  };

  const daysToDisplay =
    selectedDay === 'Semua' ? DAYS_OF_WEEK : [selectedDay];

  const filteredSchedules = useMemo(() => {
    return schedules.filter((s) =>
      selectedClassFilter === 'ALL' ? true : s.classId === selectedClassFilter
    );
  }, [schedules, selectedClassFilter]);

  const totalWeeklyJp = filteredSchedules.reduce(
    (sum, s) => sum + (s.lessonHours || 0),
    0
  );

  const uniqueTimeRanges = useMemo(() => {
    const times = new Set<string>();
    for (const s of filteredSchedules) {
      times.add(`${s.startTime}-${s.endTime}`);
    }
    return Array.from(times).sort();
  }, [filteredSchedules]);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setViewMode('harian')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                viewMode === 'harian'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Per Hari
            </button>
            <button
              type="button"
              onClick={() => setViewMode('matriks')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                viewMode === 'matriks'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Matriks Mingguan
            </button>
          </div>

          {viewMode === 'harian' && (
            <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
              <button
                type="button"
                onClick={() => setSelectedDay('Semua')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  selectedDay === 'Semua'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semua Hari
              </button>
              {DAYS_OF_WEEK.map((day) => (
                <button
                  key={day}
                  type="button"
                  onClick={() => setSelectedDay(day)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    selectedDay === day
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {day}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Filter berdasarkan kelas"
            value={selectedClassFilter}
            onChange={(e) => setSelectedClassFilter(e.target.value)}
            className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-blue-600"
          >
            <option value="ALL">Semua Kelas</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.id}>
                Kelas {cls.name}
              </option>
            ))}
          </select>

          <span className="text-xs text-slate-500 tabular-nums whitespace-nowrap">
            Total: {filteredSchedules.length} sesi · {totalWeeklyJp} JP
          </span>

          <button
            type="button"
            disabled={classes.length === 0}
            onClick={() =>
              openCreateModal(selectedDay === 'Semua' ? 'Senin' : selectedDay)
            }
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 disabled:cursor-not-allowed rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="h-3.5 w-3.5" />
            Tambah Jadwal
          </button>
        </div>
      </div>

      {classes.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
          <p className="text-sm font-medium text-slate-900">
            Belum ada data kelas yang terdaftar.
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Silakan buat kelas terlebih dahulu di menu Pelajaran & Kelas sebelum menambahkan jadwal mengajar.
          </p>
        </div>
      ) : viewMode === 'matriks' ? (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {uniqueTimeRanges.length === 0 ? (
            <div className="px-6 py-12 text-center text-xs text-slate-500">
              Belum ada jadwal mengajar yang tercatat.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-600">
                    <th className="py-3 pl-5 pr-3 w-32">Jam</th>
                    {DAYS_OF_WEEK.map((d) => (
                      <th key={d} className="py-3 px-3 min-w-[155px]">
                        {d}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs">
                  {uniqueTimeRanges.map((range) => {
                    const [startTime, endTime] = range.split('-');
                    return (
                      <tr key={range} className="align-top">
                        <td className="py-3 pl-5 pr-3 font-mono font-medium text-slate-700 tabular-nums whitespace-nowrap bg-slate-50/40">
                          {startTime}–{endTime}
                        </td>
                        {DAYS_OF_WEEK.map((d) => {
                          const slots = filteredSchedules.filter(
                            (s) =>
                              s.day === d &&
                              s.startTime === startTime &&
                              s.endTime === endTime
                          );
                          return (
                            <td key={d} className="py-2.5 px-3 border-l border-slate-100">
                              {slots.length === 0 ? (
                                <span className="text-slate-300">—</span>
                              ) : (
                                <div className="space-y-2">
                                  {slots.map((slot) => {
                                    const cls = classMap.get(slot.classId);
                                    return (
                                      <div
                                        key={slot.id}
                                        className="p-2.5 rounded-lg border border-slate-200 bg-slate-50/60 space-y-1.5"
                                      >
                                        <p className="font-display font-semibold text-slate-900">
                                          {cls?.name ?? 'Kelas'}
                                        </p>
                                        <p className="text-[11px] text-slate-700 leading-snug">
                                          {slot.subject}
                                        </p>
                                        <p className="text-[11px] text-slate-500 tabular-nums">
                                          {slot.room || cls?.room} · {slot.lessonHours} JP
                                        </p>
                                        <div className="flex items-center gap-2 pt-0.5">
                                          <button
                                            type="button"
                                            onClick={() => onOpenAttendance(slot, todayIso)}
                                            className="text-[11px] font-medium text-blue-700 hover:underline"
                                          >
                                            Presensi
                                          </button>
                                          <span className="text-slate-300" aria-hidden="true">
                                            ·
                                          </span>
                                          <button
                                            type="button"
                                            onClick={() => onOpenNote(slot, todayIso)}
                                            className="text-[11px] font-medium text-slate-700 hover:underline"
                                          >
                                            Jurnal
                                          </button>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {daysToDisplay.map((day) => {
            const daySlots = filteredSchedules
              .filter((s) => s.day === day)
              .sort((a, b) => a.startTime.localeCompare(b.startTime));

            return (
              <section
                key={day}
                className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col"
              >
                <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/60">
                  <div className="flex items-baseline gap-2">
                    <h3 className="font-display text-sm font-semibold text-slate-900">
                      {day}
                    </h3>
                    <span className="text-xs text-slate-500 tabular-nums">
                      · {daySlots.length} sesi
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => openCreateModal(day)}
                    className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:text-blue-800 whitespace-nowrap shrink-0"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Tambah
                  </button>
                </div>

                {daySlots.length === 0 ? (
                  <div className="px-5 py-8 text-center text-xs text-slate-400">
                    Belum ada jam mengajar di hari {day}.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-200">
                    {daySlots.map((slot) => {
                      const cls = classMap.get(slot.classId);
                      return (
                        <div
                          key={slot.id}
                          className="px-5 py-4 flex flex-col gap-3 hover:bg-slate-50/70 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                                <span className="font-mono text-xs font-semibold text-blue-700 tabular-nums">
                                  {slot.startTime}–{slot.endTime}
                                </span>
                                <span className="text-slate-300" aria-hidden="true">
                                  ·
                                </span>
                                <span className="font-display text-sm font-semibold text-slate-900">
                                  {cls?.name ?? 'Kelas dihapus'}
                                </span>
                                <span className="text-slate-300" aria-hidden="true">
                                  ·
                                </span>
                                <span className="text-sm text-slate-700">
                                  {slot.subject}
                                </span>
                              </div>
                              <p className="mt-1 text-xs text-slate-500 tabular-nums">
                                {slot.room || cls?.room || 'Ruang kelas'} · {slot.lessonHours} JP
                              </p>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => openEditModal(slot)}
                                aria-label="Edit jadwal"
                                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md"
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(slot.id)}
                                aria-label="Hapus jadwal"
                                className="p-1.5 text-slate-400 hover:text-red-600 rounded-md"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>

                          {confirmDeleteId === slot.id ? (
                            <div className="flex items-center justify-between gap-2 bg-red-50 border border-red-200 px-3 py-2 rounded-lg">
                              <span className="text-xs text-red-800">
                                Hapus slot jadwal ini?
                              </span>
                              <div className="flex items-center gap-2 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteId(null)}
                                  className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900"
                                >
                                  Batal
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    onDeleteSchedule(slot.id);
                                    setConfirmDeleteId(null);
                                  }}
                                  className="px-2.5 py-1 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded"
                                >
                                  Hapus
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-wrap items-center gap-2">
                              <button
                                type="button"
                                onClick={() => onOpenAttendance(slot, todayIso)}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md whitespace-nowrap shrink-0"
                              >
                                <ClipboardCheck className="h-3.5 w-3.5 text-blue-700" />
                                Presensi
                              </button>
                              <button
                                type="button"
                                onClick={() => onOpenNote(slot, todayIso)}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md whitespace-nowrap shrink-0"
                              >
                                <BookOpenText className="h-3.5 w-3.5 text-blue-700" />
                                Catat Materi
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>
            );
          })}
        </div>
      )}

      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="schedule-modal-title"
        >
          <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h2
                id="schedule-modal-title"
                className="font-display text-base font-semibold text-slate-900"
              >
                {editingSlot ? 'Ubah Jadwal Mengajar' : 'Tambah Jadwal Mengajar'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                aria-label="Tutup modal jadwal"
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Hari
                  </label>
                  <select
                    value={form.day}
                    onChange={(e) =>
                      setForm({ ...form, day: e.target.value as DayOfWeek })
                    }
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    {DAYS_OF_WEEK.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Kelas
                  </label>
                  <select
                    required
                    value={form.classId}
                    onChange={(e) => {
                      const cls = classMap.get(e.target.value);
                      setForm({
                        ...form,
                        classId: e.target.value,
                        room: cls?.room || form.room,
                      });
                    }}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {subjects.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Pilih dari Mata Pelajaran Guru
                  </label>
                  <select
                    value={form.subjectId ?? ''}
                    onChange={(e) => {
                      const subjId = e.target.value || undefined;
                      const subj = subjId ? subjectMap.get(subjId) : undefined;
                      setForm({
                        ...form,
                        subjectId: subjId,
                        subject: subj ? subj.name : form.subject,
                      });
                    }}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                  >
                    <option value="">Ketik nama mata pelajaran manual</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} · {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Nama Mata Pelajaran
                </label>
                <input
                  type="text"
                  required
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  placeholder="Contoh: Matematika Wajib"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Jam Mulai
                  </label>
                  <input
                    type="time"
                    required
                    value={form.startTime}
                    onChange={(e) =>
                      setForm({ ...form, startTime: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Jam Selesai
                  </label>
                  <input
                    type="time"
                    required
                    value={form.endTime}
                    onChange={(e) => setForm({ ...form, endTime: e.target.value })}
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Ruangan
                  </label>
                  <input
                    type="text"
                    value={form.room}
                    onChange={(e) => setForm({ ...form, room: e.target.value })}
                    placeholder="Ruang 104"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Jumlah JP
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={8}
                    required
                    value={form.lessonHours}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        lessonHours: Math.max(1, Number(e.target.value) || 1),
                      })
                    }
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
                >
                  {editingSlot ? 'Simpan Perubahan' : 'Tambah Jadwal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
